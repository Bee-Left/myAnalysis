import wx
import os
import sys
import chardet
import wx.grid as grid

# ============ 版本记录
first_ver  = 'Ver: 1.0.24.624'
latest_ver = 'Ver: 1.0.24.804'
app_name   = 'ME_motor'

# ============ 常量
max_case     = 10
max_variable = 25

def get_encoding(file):
    with open(file, 'rb') as f:
        tmp = chardet.detect(f.read())
        # print(tmp)                # -> {'encoding': 'UTF-8-SIG', 'confidence': 1.0, 'language': ''}
        return tmp['encoding']      # -> 模块chardet会把UTF-8-BOM读成'UTF-8-SIG', UTF-8读成'ascii', ANSI读成'CP949'.

class GUI(wx.Frame):
    
    def __init__(self, *args, **kw):
        
        super().__init__(*args, **kw)
        self.btn_bgc = (0,128,0)
        self.btn_fgc = (255,255,255)
        self.Bind(event=wx.EVT_CLOSE, handler=self.OnExit_GUI)
        self.InitUI()
        self.Centre()
        self.Show()
        
    def InitUI(self):
        
        self.pnl = wx.Panel(self)
        self.pnl.SetBackgroundColour('#A7CAF0') # 即 UTS2 bgc
        
        # ------------ staticBox_1
        self.widget_vbs = wx.TextCtrl(self.pnl, style=wx.TE_READONLY|wx.BORDER_STATIC)
        #self.widget_vbs.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        self.widget_vbs.SetFocus()
        btn_open = wx.Button(self.pnl, label='Select', style=0)
        btn_open.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        btn_open.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        btn_open.Bind(wx.EVT_BUTTON, self.btn_open_FCT)
        staticBox_1      = wx.StaticBox(self.pnl, label='Step-1: Select one *.vbs')
        staticBoxSizer_1 = wx.StaticBoxSizer(box=staticBox_1, orient=wx.HORIZONTAL)
        staticBoxSizer_1.Add(window=self.widget_vbs, proportion=5, flag=wx.ALL|wx.EXPAND,           border=5)
        staticBoxSizer_1.Add(window=btn_open,        proportion=0, flag=wx.TOP|wx.BOTTOM|wx.EXPAND, border=5)
        
        # ------------ staticBox_2
        self.widget_case = wx.RadioBox(self.pnl, label='Step-2: Test case selection', choices=['Dummy Case '+str(n) for n in range(1,max_case+1,1)], majorDimension=1, style=wx.RA_SPECIFY_COLS)
        self.widget_case.Disable()
        self.widget_case.Bind(wx.EVT_RADIOBOX, self.RadioBox_FCT)
        
        # ------------ staticBox_3
        # ------------ 创建表格
        self.widget_grid = grid.Grid(self.pnl)
        table_fieldnames = ['Line', 'Variable', 'Value']
        self.widget_grid.CreateGrid(numRows=max_variable, numCols=len(table_fieldnames))
        self.widget_grid.Bind(grid.EVT_GRID_LABEL_RIGHT_CLICK, self.OnLabelRightClick)
        
        # ------------ 设置标签Label
        self.widget_grid.SetGridLineColour((171,171,171))
        self.widget_grid.SetColLabelSize(height=25) # 设置列标签的高度, 而列标签的宽度随单元格的宽度
        self.widget_grid.SetRowLabelSize(width=40)  # 设置行标签的宽度，而行标签的高度随单元格的高度
        self.widget_grid.SetCornerLabelValue('No.')
        self.widget_grid.SetLabelTextColour(colour='blue')                                     # 设置标签的字体颜色
        #self.widget_grid.SetGridCursor(row=0, col=1)                                          # 设置网格光标在指定的单元格
        self.widget_grid.SetCornerLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)    # 设置Corner标签左右以及上下对齐方式：靠左左对齐，下沉
        self.widget_grid.SetColLabelAlignment(horiz=wx.ALIGN_CENTER, vert=wx.ALIGN_BOTTOM)     # 设置column标签左右以及上下对齐方式：居中对齐，下沉
        self.widget_grid.SetRowLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)       # 设置row标签左右以及上下对齐方式：   靠左对齐，下沉
        self.widget_grid.SetLabelFont(font=wx.Font(pointSize=12, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        
        for n, per_fieldname in enumerate(table_fieldnames, 0):
            self.widget_grid.SetColLabelValue(col=n, value=per_fieldname)
        
        # ------------ 设置单元格cell
        for m in range(0, max_variable, 1):
            self.widget_grid.SetRowSize(row=m, height=25)
            self.widget_grid.SetReadOnly(row=m, col=0, isReadOnly=True)
            self.widget_grid.SetReadOnly(row=m, col=1, isReadOnly=True)
            self.widget_grid.SetCellFont(row=m, col=0, font=wx.Font(12, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            self.widget_grid.SetCellFont(row=m, col=1, font=wx.Font(12, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            self.widget_grid.SetCellFont(row=m, col=2, font=wx.Font(12, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            
        self.widget_grid.SetColSize(col=0, width=50)
        self.widget_grid.SetColSize(col=1, width=250)
        self.widget_grid.SetColSize(col=2, width=250)

        self.staticBox_3 = wx.StaticBox(self.pnl, label='Step-3: Variable and Value')
        staticBoxSizer_3 = wx.StaticBoxSizer(box=self.staticBox_3, orient=wx.HORIZONTAL)
        staticBoxSizer_3.Add(window=self.widget_grid, proportion=1, flag=wx.ALL|wx.EXPAND, border=5)
        
        # ------------ staticBox_4
        self.btn_read = wx.Button(self.pnl, label='Read', style=0)
        self.btn_read.SetBackgroundColour(self.btn_bgc)
        self.btn_read.SetForegroundColour(self.btn_fgc)
        self.btn_read.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        self.btn_read.SetFont(font=wx.Font(pointSize=24, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        self.btn_read.Disable()
        self.btn_read.Bind(wx.EVT_BUTTON, self.btn_read_FCT)
        
        self.btn_write = wx.Button(self.pnl, label='Write', style=0)
        self.btn_write.SetBackgroundColour((0,0,128))
        self.btn_write.SetForegroundColour(self.btn_fgc)
        self.btn_write.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        self.btn_write.SetFont(font=wx.Font(pointSize=24, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        self.btn_write.Disable()
        self.btn_write.Bind(wx.EVT_BUTTON, self.btn_write_FCT)
        
        staticBox_4      = wx.StaticBox(self.pnl, label='Step-4: Read and Write')
        staticBoxSizer_4 = wx.StaticBoxSizer(box=staticBox_4, orient=wx.HORIZONTAL)
        staticBoxSizer_4.Add(window=self.btn_read,  proportion=1, flag=wx.ALL|wx.EXPAND,border=5)
        staticBoxSizer_4.Add(window=self.btn_write, proportion=1, flag=wx.TOP|wx.BOTTOM|wx.LEFT|wx.EXPAND, border=5)
        
        vbox = wx.BoxSizer(orient=wx.VERTICAL)
        vbox.Add(sizer=staticBoxSizer_1,  proportion=0, flag=wx.ALL|wx.EXPAND, border=5)
        vbox.Add(window=self.widget_case, proportion=0, flag=wx.ALL|wx.EXPAND, border=5)
        vbox.Add(sizer=staticBoxSizer_3,  proportion=1, flag=wx.ALL|wx.EXPAND, border=5)
        vbox.Add(sizer=staticBoxSizer_4,  proportion=0, flag=wx.ALL|wx.EXPAND, border=5)
        self.pnl.SetSizer(sizer=vbox)
        
    def btn_open_FCT(self, evt):
        dlg = wx.FileDialog(parent=self, message='Please select your vbs script', defaultDir='', defaultFile='', wildcard='*.vbs', style=wx.FD_OPEN|wx.FD_FILE_MUST_EXIST)
        res = dlg.ShowModal()
        if res == wx.ID_OK:
            # ------------ 清除上次界面缓存
            for m in range(0,max_case,1):
                self.widget_case.SetString(n=m, string='Dummy Case '+str(m+1))
                self.widget_case.EnableItem(n=m, enable=False)
            self.widget_case.SetSelection(n=0)
            for i in range(0, max_variable, 1):
                self.widget_grid.SetCellValue(row=i, col=0, s='')
                self.widget_grid.SetCellValue(row=i, col=1, s='')
                self.widget_grid.SetCellValue(row=i, col=2, s='')
            self.btn_read.Disable()
            self.btn_write.Disable()
            self.btn_read.SetToolTip(tipString='')
            self.btn_write.SetToolTip(tipString='')
            
            vbs_list = dlg.GetPaths()   # list
            # print(vbs_list)
            self.original_vbs = vbs_list[0]
            # print(self.original_vbs)
            self.widget_vbs.SetValue(self.original_vbs)
            self.widget_vbs.SetToolTip(tipString=self.original_vbs)
            self.original_encoding = get_encoding(self.original_vbs)
            # print(self.original_encoding)
            
            self.original_lines = None
            with open(file=self.original_vbs, mode='r', encoding=self.original_encoding) as readObj:
                self.original_lines = readObj.readlines()
            # print(self.original_lines)    # list
            self.all_cases = self.collect_cases(content=self.original_lines)
            # print(self.all_cases)
            
            if self.all_cases:              
                for m in range(0,max_case,1):
                    if m < len(self.all_cases):
                        self.widget_case.SetString(n=m, string=self.all_cases[m])
                        self.widget_case.EnableItem(n=m, enable=True)
                self.btn_read.Enable()
                self.btn_write.Enable()
                self.btn_read.SetToolTip(tipString=f'Read from "{os.path.basename(self.original_vbs)}"')
                self.btn_write.SetToolTip(tipString=f'Write into "{os.path.basename(self.original_vbs)}"')
            else:
                return
                
            self.all_variable_value = self.collect_variable(context=self.original_lines)
            # print(self.all_variable_value)
            
            for m, (var, (row, value)) in enumerate(self.all_variable_value[self.all_cases[0]].items(), 0):
                if m < max_variable:
                    self.widget_grid.SetCellValue(row=m, col=0, s=str(row))
                    self.widget_grid.SetCellValue(row=m, col=1, s=var)
                    self.widget_grid.SetCellValue(row=m, col=2, s=value)
                    
        elif res == wx.ID_CANCEL:
            print('用户点击了取消按钮,放弃了选择文件.')
        
        dlg.Destroy()
        self.widget_case.Refresh()
        self.widget_grid.Refresh()
    
    def collect_cases(self, content:list):
        n_target     = None
        cases_target = []
        for n_target, each_line in enumerate(content, 0):
            if each_line.lstrip().startswith('TestCaseStr = InputBox'):
                break
                
        if not n_target:
            return None
            
        for every_line in content[n_target+1:]:
            if len(every_line.split(' - ')) >= 2 and every_line.split(' - ')[0].strip(' "') in [str(i) for i in range(1,max_case+1,1)]:
                cases_target.append(every_line.split('"')[1])
            elif every_line.strip().startswith("'"):
                continue
            else:
                break
        return cases_target
        
    def collect_variable(self, context:list):
        m_target                = None
        variable_value_original = {}    # {'1 - keyboard standard click':{ModeOfOperation:(127,1),ProfileVelocity:(128,100)}, '2 - mouse standard click':{}, ...}
        for i, each_case in enumerate(self.all_cases, 1):
            variable_value_original[each_case] = {}
            for m_target, each_line in enumerate(context, 0):
                if each_line.lstrip().startswith('Case ' + each_case.split(' - ')[0]):
                    break
            if not m_target:
                return None
            row_num = m_target+2
            for every_line in context[m_target+1:]:
                if len(every_line.split(' = ')) >= 2 and len(every_line.split()) >= 3:
                    variable_value_original[each_case][every_line.split()[0]] = (row_num, every_line.split()[2])
                    row_num += 1
                elif every_line.strip().startswith("'"):
                    row_num += 1
                    continue
                else:
                    break
        return variable_value_original
    
    def RadioBox_FCT(self, evt):
        # ------------ 清除上次界面缓存
        for i in range(0, max_variable, 1):
            self.widget_grid.SetCellValue(row=i, col=0, s='')
            self.widget_grid.SetCellValue(row=i, col=1, s='')
            self.widget_grid.SetCellValue(row=i, col=2, s='')
        rb_obj = evt.GetEventObject()
        for m, (var, (row, value)) in enumerate(self.all_variable_value[rb_obj.GetStringSelection()].items(), 0):
            if m < max_variable:
                self.widget_grid.SetCellValue(row=m, col=0, s=str(row))
                self.widget_grid.SetCellValue(row=m, col=1, s=var)
                self.widget_grid.SetCellValue(row=m, col=2, s=value)
        self.widget_grid.Refresh()
        
    def OnLabelRightClick(self, evt):
        col_clicked  = evt.GetCol()
        print('右单击(列)标签:', col_clicked)
        
        if col_clicked == 2:
            the_colLabel = self.widget_grid.GetColLabelValue(col=col_clicked)
            print('右单击(列)标签的内容为:', the_colLabel, end='\n\n')            
            dlg_clear = wx.MessageDialog(parent=self.widget_grid, message=f'Do you want to clear all "{the_colLabel}"?', caption='Tip', style=wx.YES_NO|wx.ICON_QUESTION)
            res = dlg_clear.ShowModal()
            if res == wx.ID_YES:
                for i in range(0, max_variable, 1):
                    self.widget_grid.SetCellValue(row=i, col=col_clicked, s='')
            elif res == wx.ID_NO:
                pass
            dlg_clear.Destroy()
        self.widget_grid.Refresh()
            
    def btn_read_FCT(self, evt):
        # ------------ 清除上次界面缓存
        for m in range(0,max_case,1):
            self.widget_case.SetString(n=m, string='Dummy Case '+str(m+1))
            self.widget_case.EnableItem(n=m, enable=False)
        # self.widget_case.SetSelection(n=0)
        for i in range(0, max_variable, 1):
            self.widget_grid.SetCellValue(row=i, col=0, s='')
            self.widget_grid.SetCellValue(row=i, col=1, s='')
            self.widget_grid.SetCellValue(row=i, col=2, s='')
        self.btn_write.Disable()
        
        self.original_encoding = get_encoding(self.original_vbs)
        # print(self.original_encoding)
        
        self.original_lines = None
        with open(file=self.original_vbs, mode='r', encoding=self.original_encoding) as readObj:
            self.original_lines = readObj.readlines()
        # print(self.original_lines)    # list
        self.all_cases = self.collect_cases(content=self.original_lines)
        # print(self.all_cases)
        
        if self.all_cases:              
            for m in range(0,max_case,1):
                if m < len(self.all_cases):
                    self.widget_case.SetString(n=m, string=self.all_cases[m])
                    self.widget_case.EnableItem(n=m, enable=True)
            self.btn_read.Enable()
            self.btn_write.Enable()
        else:
            return
            
        self.all_variable_value = self.collect_variable(context=self.original_lines)
        # print(self.all_variable_value)
        
        if self.widget_case.GetStringSelection() in self.all_cases:
            the_case = self.widget_case.GetStringSelection()
        else:
            self.widget_case.SetSelection(n=0)
            the_case = self.all_cases[0]
        for m, (var, (row, value)) in enumerate(self.all_variable_value[the_case].items(), 0):
            if m < max_variable:
                self.widget_grid.SetCellValue(row=m, col=0, s=str(row))
                self.widget_grid.SetCellValue(row=m, col=1, s=var)
                self.widget_grid.SetCellValue(row=m, col=2, s=value)
                
        self.widget_case.Refresh()
        self.widget_grid.Refresh()
        
    def btn_write_FCT(self, evt):
        latest_value_list = []
        for n in range(0, max_variable, 1):
            latest_value_list.append([self.widget_grid.GetCellValue(row=n, col=0),
                                    self.widget_grid.GetCellValue(row=n, col=1),
                                    self.widget_grid.GetCellValue(row=n, col=2)])
        print(latest_value_list) # [['127', 'ModeOfOperation', '1'], ['128', 'ProfileVelocity', '100'],...]
        
        if not latest_value_list:
                return None
        
        for each_row_data in latest_value_list:
            if each_row_data[0]: # 非空行
                the_index          = int(each_row_data[0])-1
                the_var            = self.original_lines[the_index].split()[0]
                the_original_value = self.original_lines[the_index].split()[2]
                the_new_value      = each_row_data[2].strip()
                if not the_new_value:
                    wx.MessageBox(message=f'Line {each_row_data[0]}\n\n{each_row_data[1]} value cannot be empty', caption='myWarning', style=wx.ICON_WARNING, parent=self)
                    return None
                if the_var == each_row_data[1]:
                    self.original_lines[the_index] = self.original_lines[the_index].replace(the_original_value, the_new_value, 1) 
            else:
                break
        
        self.all_variable_value = self.collect_variable(context=self.original_lines) # 服务于 RadioBox_FCT(), 确保保持最新值
        # print(self.all_variable_value)
        
        with open(file=self.original_vbs, mode='w', encoding=self.original_encoding) as writeObj:
            writeObj.writelines(self.original_lines)
        wx.MessageBox(message=f'Write Done', caption='Success', style=wx.ICON_INFORMATION, parent=self)

    def OnExit_GUI(self, event):
        self.Destroy()
        sys.exit()
       
if __name__ == '__main__':
    
    app = wx.App()
    screen_W, screen_H = wx.DisplaySize()    # 确认最新屏幕的分辨率
    GUI(None, title=f'{app_name}({latest_ver})', size=(660,screen_H-60))
    app.MainLoop()
    
