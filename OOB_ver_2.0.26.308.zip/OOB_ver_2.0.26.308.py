import wx
import os
import configparser
import win32api
import keyboard
import ctypes
import ctypes.wintypes
import time
import threading
import pygetwindow as gw
import wx.lib.agw.pybusyinfo as PBI
from wx.lib.embeddedimage import PyEmbeddedImage

# ======================== 版本记录
first_ver  = 'Ver: 1.0.25.508'
latest_ver = 'Ver: 2.0.26.308'
app_name   = 'logi OOB'


#捕捉标题: 
#titles = gw.getAllTitles() 
#titles = list(filter(None, titles))   # filter()函数可以用来过滤掉列表中的空值
#
#特别注意:
#uts2 和 logi_photoviewer 抓取对应的窗口标题分别是: 'UTS' 和 ' - Windows 照片查看器'
#'OOB_Excel.xlsx - Excel'
#'Logitech.jpg - 画图(英文系统:Paint)
#'OOB_PPT.pptx - PowerPoint'
#'01.jpg - Windows 照片查看器'(英文系统:Windows Photo Viewer)
#'OOB_Notepad.txt - Notepad'
#'UTS(1)' or ' (1)Kaluga_Dagger-ROM_Paring_001.tpm'
#
#默认应用:
#r'C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE'
#r'C:\Windows\System32\mspaint.exe'(不知何故,无法找到.)
#r'C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE'
#r'C:\Windows\System32\rundll32.exe shimgvw.dll,ImageView_Fullscreen'
#r'C:\Windows\System32\notepad.exe'
#r'C:\UTS2.0\exe\UTS2.0.exe & C:\Logitech\UTS\UTS.exe'

def on_key_event(evt):
    global count_pressed, index_Title_dict
    
    # ======================== 检查防呆
    if not index_Title_dict:            # 用户设置不放任何图标
        return
    if not os.path.isfile(VBS_script):  # vbs脚本文件不存在了
        return
    
    key_pressed = evt.name
    #print(f'key {key_pressed} pressed')
    if key_pressed == Monitoring_key:       
        count_pressed += 1
        if count_pressed < len(index_Title_dict):
            pass
        else:
            count_pressed = 0
        #print('count_pressed:', count_pressed)
        
        now_title = index_Title_dict[count_pressed]
        #print(f'now_title: {now_title}')
        
        
        if now_title == QIS_title:  # 设置所有按钮的背景颜色为初始化时的未点击背景色
            for each_btn in GUI.title_btn_dict.values():
                each_btn.SetBackgroundColour(Unclicked_button_RGB)
        
        if now_title == Bluetooth_title:
            win32api.ShellExecute(0, 'open', VBS_script, f'1 "{Bluetooth_cpl}"', '', 1)
            GUI.title_btn_dict[now_title].SetBackgroundColour(Clicked_button_RGB)
            return
  
        # ======================== 调用vbs脚本文件
        current_all_titles = gw.getAllTitles()
        current_all_titles = list(filter(None, current_all_titles))   # filter()函数可以用来过滤掉列表中的空值
        for per_title in current_all_titles:
            if now_title == 'UTS': # 这里是为了兼容 UTS1
                if any([per_title.startswith('UTS'), '.tpm' in per_title]):
                    win32api.ShellExecute(0, 'open', VBS_script, f'2 "{per_title}"', '', 1)
                    GUI.title_btn_dict[now_title].SetBackgroundColour(Clicked_button_RGB)
                    break
            elif now_title in per_title:
                win32api.ShellExecute(0, 'open', VBS_script, f'2 "{per_title}"', '', 1)
                GUI.title_btn_dict[now_title].SetBackgroundColour(Clicked_button_RGB)
                break
        else:
            pass
            #wx.MessageBox(message=f'未找到包含如下指定标题的窗口:\n\n{now_title}', caption='myWarning', style=wx.ICON_WARNING)

def Auto_open_close_WindowsAPP(user_dialog):
    global count_pressed, index_Title_dict
    
    # ======================== 根据用户输入的产品名称,先看相关必要的文件(夹)是否存在, 再看是否已打开
    the_dlg   = user_dialog
    busy_info = PBI.PyBusyInfo(message=f'正在为您准备: {the_dlg.user_input_actual}', parent=None, title='info.', icon=wx.NullBitmap)
    current_window_titles = gw.getAllTitles()                           # 提示: 在获取当前窗口时, 结果的列表里会有一些空元素.
    current_window_titles = list(filter(None, current_window_titles))   # filter()函数可以用来过滤掉列表中的空值
    #print('current_window_titles:', current_window_titles, sep='\n', end='\n\n')
    
    icons_actual_needed = Project_Icon_dict[the_dlg.user_input]
    icons_actual_needed = list(filter(None, icons_actual_needed))       # filter()函数可以用来过滤掉列表中的空值
    
    if 'QIS' in icons_actual_needed:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_qis'] in per_title:
                break
        else: # 自动打开
            if QIS_website:
                win32api.ShellExecute(0, 'open', QIS_website, '', '', 1)
    else:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_qis'] in per_title:
                hWnd = ctypes.windll.user32.FindWindowW(None, per_title)
                if hWnd: # 自动关闭(这里暂且执行语句pass,先不自动关闭)
                    pass 
                    #result = user32.PostMessageA(hWnd,16,0,0) # 缺点是: 会把浏览器的全部页面关闭掉(即浏览器直接关闭掉了) 返回值: True or False
                break
                
    if 'Excel' in icons_actual_needed:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_excel'] in per_title:
                break
        else:
            if os.path.isfile(Excel_filename): # 自动打开
                win32api.ShellExecute(0, 'open', 'excel', f'"{Excel_filename}"', '', 1)
            else:
                wx.MessageBox(message=f'Find no below file:\n\n{Excel_filename}', caption='myWarning', style=wx.ICON_WARNING)
    else:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_excel'] in per_title:
                hWnd = ctypes.windll.user32.FindWindowW(None, per_title)
                if hWnd: # 自动关闭
                    result = user32.PostMessageA(hWnd,16,0,0) # 返回值: True or False
                break
            
    if 'Paint' in icons_actual_needed:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_mspaint'] in per_title:
                break
        else:
            if os.path.isfile(Paint_filename): # 自动打开
                win32api.ShellExecute(0, 'open', 'mspaint', f'"{Paint_filename}"', '', 1)
            else:
                wx.MessageBox(message=f'Find no below file:\n\n{Paint_filename}', caption='myWarning', style=wx.ICON_WARNING)
    else:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_mspaint'] in per_title:
                hWnd = ctypes.windll.user32.FindWindowW(None, per_title)
                if hWnd: # 自动关闭
                    result = user32.PostMessageA(hWnd,16,0,0) # 返回值: True or False
                break
    
    if 'PPT' in icons_actual_needed:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_powerpnt'] in per_title:
                break
        else:
            if os.path.isfile(PPT_filename): # 自动打开
                win32api.ShellExecute(0, 'open', 'powerpnt', f'"{PPT_filename}"', '', 1)
            else:
                wx.MessageBox(message=f'Find no below file:\n\n{PPT_filename}', caption='myWarning', style=wx.ICON_WARNING)         
    else:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_powerpnt'] in per_title:
                hWnd = ctypes.windll.user32.FindWindowW(None, per_title)
                if hWnd: # 自动关闭
                    result = user32.PostMessageA(hWnd,16,0,0) # 返回值: True or False
                break
                
    if 'PhotoViewer' in icons_actual_needed:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_photoviewer'] in per_title:
                break
        else:
            if os.path.isdir(PhotoViewer_foldername): # 自动打开
                win32api.ShellExecute(0, 'open', 'rundll32.exe', f'shimgvw.dll,ImageView_Fullscreen {PhotoViewer_foldername}', '', 1)
            else:
                wx.MessageBox(message=f'Find no below folder:\n\n{PhotoViewer_foldername}', caption='myWarning', style=wx.ICON_WARNING)
    else:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_photoviewer'] in per_title:
                hWnd = ctypes.windll.user32.FindWindowW(None, per_title)
                if hWnd: # 自动关闭
                    result = user32.PostMessageA(hWnd,16,0,0) # 返回值: True or False
                break
    
    if 'Notepad' in icons_actual_needed:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_notepad'] in per_title:
                break
        else:
            if os.path.isfile(Notepad_filename): # 自动打开
                win32api.ShellExecute(0, 'open', 'notepad', f'"{Notepad_filename}"', '', 1)
            else:
                wx.MessageBox(message=f'Find no below file:\n\n{Notepad_filename}', caption='myWarning', style=wx.ICON_WARNING)
    else:
        for per_title in current_window_titles:
            if Windows_Title_dict['logi_notepad'] in per_title:
                hWnd = ctypes.windll.user32.FindWindowW(None, per_title)
                if hWnd: # 自动关闭
                    result = user32.PostMessageA(hWnd,16,0,0) # 返回值: True or False
                break
                
    if 'Bluetooth' in icons_actual_needed: # 自动打开蓝牙, 有点特殊，记住这里需要用到Windows的control.exe bthprops.cpl
        # 特别注意: 若不写control, 则会报错: pywintypes.error: (31, 'ShellExecute', '连到系统上的设备没有发挥作用。')
        win32api.ShellExecute(0, 'open', 'control', Bluetooth_cpl, '', 1)
        
    # 强制关闭已打开的Test Plan
    os.system('tasklist|find /i "UTS.exe"&&taskkill /f /im UTS.exe /t')
    os.system('tasklist|find /i "UTS2.0.exe"&&taskkill /f /im UTS2.0.exe /t')
    
    # 自动打开对应的Test Plan
    if Project_TestPlan_dict[the_dlg.user_input]:
        if os.path.isfile(Project_TestPlan_dict[the_dlg.user_input]):
            wx.MilliSleep(milliseconds=200) # 延时200毫秒
            win32api.ShellExecute(0, 'open', os.path.basename(Project_TestPlan_dict[the_dlg.user_input]), '', os.path.dirname(Project_TestPlan_dict[the_dlg.user_input]), 1)
        else:
            wx.MessageBox(f'Test Plan does not exist\n\n{Project_TestPlan_dict[the_dlg.user_input]}', 'myWarning', wx.ICON_EXCLAMATION)
 
    # 更新这些全局变量: count_pressed, index_Title_dict 
    n                = -1
    count_pressed    = -1
    index_Title_dict = {}
    for per_section in all_sections:
        if per_section in icons_actual_needed:
            n +=1
            index_Title_dict[n] = Section_Title_dict[per_section]
    print(f'{"#"*50} {the_dlg.user_input_actual} 的 index_Title_dict:', index_Title_dict, sep='\n', end='\n\n')
    
    # 刷新标题, 图标以及其背景色, 产品图片, 板面尺寸大小
    GUI.SetTitle(title=f'{app_name} ({latest_ver})    Product_Name: {the_dlg.user_input_actual}    8L_PN: {the_dlg.user_select_8L}')
    for each_button in GUI.section_btn_dict.values():
        each_button.Hide()
        each_button.SetBackgroundColour(Unclicked_button_RGB)
    for each_icon in icons_actual_needed:
        GUI.section_btn_dict[each_icon].Show()
    GUI.img_show_correct.SetBitmap(label=the_dlg.the_bitmap)
    GUI.img_show_correct.Layout()
    GUI.vboxSizer.Layout()
    GUI.SetSize(width=80*(len(index_Title_dict)+1)+100, height=130)
    GUI.Refresh()
    del busy_info
    
class Cfg(configparser.ConfigParser):
    '''在子类(即Cfg)中重写父类(即configparser.ConfigParser)的方法(即optionxform)'''
    def optionxform(self, optionstr):
        return optionstr

class MyDialog(wx.Dialog):
    def __init__(self, *args, **kw):
        super().__init__(None, title=f'{app_name} ({latest_ver})', size=(1000,750), style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER) #wx.STAY_ON_TOP:
    
    def InitDialog(self):
        self.SetFont(font=wx.Font(pointSize=16, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        self.comboBox_select_initial = wx.ComboBox(self, value='', choices=all_project, style=wx.CB_DROPDOWN|wx.TE_PROCESS_ENTER)
        self.comboBox_select_initial.SetToolTip('Step-1: 请输入产品名称, 注意输入不需要区分大小写')
        self.comboBox_select_initial.AutoComplete(choices=self.comboBox_select_initial.GetItems())
        self.comboBox_select_initial.Bind(event=wx.EVT_TEXT_ENTER, handler=self.ComboBox_ENTER_FCT)
        self.comboBox_select_initial.Bind(wx.EVT_TEXT, self.ComboBox_text_FCT)
        self.choice_select_initial = wx.Choice(self, choices=[])
        self.choice_select_initial.SetToolTip(tipString='Step-2: 请选择8L_PN')
        self.choice_select_initial.Bind(wx.EVT_CHOICE, self.Choice_FCT)
        self.default_bitmap = PyEmbeddedImage(data=default_img_str.encode()).GetBitmap()
        self.img_show = wx.StaticBitmap(self, bitmap=self.default_bitmap)#wx.NullBitmap
        self.img_show.SetToolTip(tipString='Step-3: 自动显示产品图片')
        btn_confirm = wx.Button(self, label='确定')
        btn_confirm.SetToolTip(tipString='Step-4: 人工确认')
        btn_confirm.Bind(event=wx.EVT_BUTTON, handler=self.ComboBox_ENTER_FCT)
        
        v_boxSizer = wx.BoxSizer(orient=wx.VERTICAL)
        v_boxSizer.Add(self.comboBox_select_initial, 0, wx.EXPAND, 0)
        v_boxSizer.Add(self.choice_select_initial,   0, wx.EXPAND, 0)
        v_boxSizer.Add(self.img_show,                1, wx.EXPAND, 0)
        
        self.h_boxSizer = wx.BoxSizer(orient=wx.HORIZONTAL) # wx.VERTICAL
        self.h_boxSizer.Add(v_boxSizer,  1, wx.EXPAND, 0)
        self.h_boxSizer.Add(btn_confirm, 0, wx.EXPAND, 0)
        self.SetSizer(self.h_boxSizer)
        self.Centre()
        self.Maximize(maximize=True)
        
    def ComboBox_ENTER_FCT(self, evt):
        self.user_input_actual =self.comboBox_select_initial.GetValue().strip()
        self.user_input        = self.user_input_actual.lower()
        print(f'1.用户输入名称: {self.user_input_actual}')
        
        self.user_select_8L = self.choice_select_initial.GetStringSelection()
        print(f'2.用户选择8L_PN: {self.user_select_8L}')
        
        if self.user_input:
            if self.user_input in Project_Icon_dict.keys(): # 即用户输入的产品名称必须是在配置档中存在
                if self.user_select_8L:
                    dlg_confirm = wx.MessageDialog(None, message=f'请确认如下信息正确\n\n1.产品名称: {self.user_input_actual}\
                                                                \n2.8L_PN: {self.user_select_8L}\
                                                                \n3.产品图片', 
                                                                caption='确认|取消', style=wx.OK|wx.CANCEL)
                    res = dlg_confirm.ShowModal()
                    if res == wx.ID_OK:
                        self.EndModal(retCode=88)
                        self.Destroy()
                    elif res == wx.ID_CANCEL:
                        pass
                    dlg_confirm.Destroy() # 只能Destroy一次
                else:
                    wx.MessageBox('您还没有选择8L_PN\n\n请选择8L_PN', 'myWarning', wx.ICON_EXCLAMATION)    
            else:
                wx.MessageBox(f'{self.user_input_actual}, 该产品名称不存在.\n\n{cfg_file}', 'myWarning', wx.ICON_EXCLAMATION)
        else:
            wx.MessageBox('您还没有输入产品名称\n\n请输入产品名称', 'myWarning', wx.ICON_EXCLAMATION)
            self.comboBox_select_initial.SetValue('')
        self.comboBox_select_initial.SetFocus()
        
    def ComboBox_text_FCT(self, evt):
        self.img_show.SetBitmap(label=self.default_bitmap) # wx.NullBitmap
        self.img_show.Layout()
        self.h_boxSizer.Layout()
        
        the_project = self.comboBox_select_initial.GetValue().strip()
        self.choice_select_initial.Clear()
        all_8L = []
        if the_project.lower() in Project_PictureFolder_dict:
            the_folder_path = Project_PictureFolder_dict[the_project.lower()]
            all_file_folder = os.listdir(path=the_folder_path)
            for each_file in all_file_folder:
                if os.path.isfile(os.path.join(the_folder_path,each_file)):
                    all_8L.append(os.path.splitext(each_file)[0])
            all_8L.sort()
            for each_8L in all_8L:
                self.choice_select_initial.Append(each_8L)
    
    def Choice_FCT(self, evt):
        the_project = self.comboBox_select_initial.GetValue()
        the_8L      = self.choice_select_initial.GetStringSelection()
        the_folder_path = Project_PictureFolder_dict[the_project.lower()]
        the_img_path    = os.path.join(the_folder_path,f'{the_8L}.jpg')
        if os.path.isfile(the_img_path):
            self.the_bitmap = wx.Bitmap(name=the_img_path)
            self.img_show.SetBitmap(label=self.the_bitmap)
        else:
            self.the_bitmap = self.default_bitmap
            self.img_show.SetBitmap(label=self.default_bitmap) # wx.NullBitmap
        self.img_show.Layout()
        self.h_boxSizer.Layout()
                
class MyGUI(wx.Frame):
    
    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        logi_icon_str    = '/9j/4AAQSkZJRgABAQEAeAB4AAD/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAeACgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2bXv2ndI8O/tS6H8J5bK/k1rXtHfWIbpdn2aOJTKCrchtxMLY4P3hXpZI7cV8Mfti/FFfgn/wU20PxY1sLz/hHfhbqGorASQJ3iGoMqFhyASAM9s1ynhj4c/tDfF39nib47p8a9T0vWJLSbXbHw1AjLprW0W8iNlDeWHKKcBonx8oY5JK/cvMZRqTgleSbt6H+TUvCPB4zK8BmaxUMLCrTppynzS56027JJJ2VkrvZH6JN0znPasvxz4qj8D+CdX1uW3ubyPR7Ka9eC2TfNMsUbOURe7ELgDuSK+E9c/bQ+I37YS/Bz4e+CtVi8Ca58QtHm1XXtZt0O+2WCW4hcQDO5cm0lYBSGy6LuC7s5viyH4w/siftTeGPCuu/GHxD4r8L67o+oXlpNOgEsksNrMRHIrOzD955WH3t97p2olmqcbwTcdE/VhlfgTiliqeFzHFUoYh801RfNeVOErS96MWlezst7an2b+yt+0La/tR/BbTfGFlpV/o0N+8sQtbrBIMblMqw+8OOvY8UVyH/BNz4ka58W/2PvC+v+JdTuNX1m9ku/PupyDJLsupkGfooUf8Borvwc5VaMZt7o/JeO8spZbxBi8BQgoRpzklFNySSe3M0m/Vq5V+L/7Gcnxh/bB0vx1qVxp83hSHwjc+F9Q02TeLi4E/2oMVOCu3ZcYPzA8HivF0/wCCcfxu8L+CLv4aeH/jLY2vwpvnljaC4sM6jDbStl4FOzJBB+YLKoOT0DMK+5wu4ZzQnLAY68VlPLqU5c/V/qfT5X4v5/gMNTwdJwlTpxjGMZU4yScL8slzJ+8r6SPhn9o79m7wp4Q+I3wd+H3gDxXd+Afir4W05j4a1Se18221CHMrSxzOBje8izNtCkHznUqRIAKGg/BnVNJ/azsY/jR8Qrfxl8V/E/h67sPDFhpdls07SI5IpUa4chE2jb5uDs/vMdxAK/Tn7VX7GnhH9rrQtNt/Ef8AaFlqOjSG403VdNmEN3ZMSudpYMCpYISpH8PDKea579l//gn14S/Zm8XXfitdS1/xb4t1GEW7axrVz508MZxlUGOMhQCSS2MgEKSp4Z5fUVW8Y+7dPfTTTVdX2Z+p5d4rYCPD6rYjFzeLUJx5fZxc3OUnL3a7V40m9ZQ30aTSZ0P7F3wG1b9mb9n7w/4L1K60+/m0kXLS3Fqz7C0lw8qhQyqdu1+cgfMOM0V6yY+etFetRhGnBQWyP5vz3Oq+bY6pmOMa9pUblKysrs//2Q=='
        logi_icon_bitmap = PyEmbeddedImage(data=logi_icon_str.encode()).GetBitmap() # 原图: 40*30
        self.SetIcon(icon=wx.Icon(bmp=logi_icon_bitmap))
        
        self.Bind(event=wx.EVT_CLOSE,  handler=self.OnExit_GUI)
        self.Bind(event=wx.EVT_BUTTON, handler=self.Button_FCT)
        self.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        self.InitUI()
        self.Center()
        self.Show()
        #wx.MilliSleep(milliseconds=500) # 延时500毫秒
        #self.Refresh()
        #self.SetFocus()
            
    def InitUI(self):
        pnl = wx.Panel(self)
        
        img_str_qis         = 'iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsAAAA7AAWrWiQkAABIQSURBVHhe7VsJlBXVmb5V9bbu1/vezdLQIAp0A3ZEQEERQdzB5ShRJidx4ihmIhNn1ElM4jFGY+IK4q5x9GjcogZjjGZmiAY0ExwFFBARUdam9/X167dVzffdrtfWe+8+up1EPWemvnO+rle37n9v1X///7//vVUtXLhw4cKFCxcuXLhw4cKFCxcuXLhw4cKFCxcuXLhw4cKFCxcuXPyfhmVZxpYD0XkPvRN+wjTN77Bs3e6BJcuf79nx7qHYElzXZMUvEP+bPrpMs+T5reHLlj3fHU6Y5q0su/D5nq2XvtTz9r5uc1Z6mxv2xJb0DJiT7VOJv+rB7vvv/u+veqvvhoSleQ1NE2dOCYqfzfcPeD16zqTVreh/sB47mT3W1/zY0oJxmqYNDJZmBwRzG+5tb4vErRy7aFjo6OSsI/2JW0/JL0cfnXZxBqi00x7t2treG6+yUNGA4I0n5Ykzj/K+F9e1RcesaW827fv268JaNj1vw3XzAqdf8puuFzYfMhfdtDBPnDbRVwzRLtbRZc3PibveCt16xF2t1h0bQjcnTM1bkqOLxUcExKUzvMLQRSNHbkKRMTg6uBkq8s97opVzH2kPv7Q9/J5s5DBY9VZoB24+h7IjYXWeIU4a5xPL6nMM9P1TlGYA5fqMe9v6Z65ub2/rTVRbmq6NKfSIcycHxNyxHitg6EebA2LCgjq/KAwYst1IQmiPvds3b9Kqtt4Ne+KLPHgg9MVeewZb/ZwW2G2apbPXtLYkzM8UH/Dq4qJpuWLFzFyR77NO1HX9Tyzf3BR9YeUrPec09SZkvSR8hiZ+eFJB97L6QJFdlAGEgdrntoV33rK+3xeKmnapGrno/8aFhWL+OI8V9Ipvo/9f2peG0GlZRXNWt3aaSZcAGqoD4grc87yxRtyji2mQ+4Dl4aj53bU7Y6tW/TmktYdism4SFXke8do3iqJBn+G3i0ZugW0hc/TMu9vanMojxhQaYvFEnyjwi8lJ5REzqn3nrpiZc7N9OoRowqIFF77fHMtqiWhnz4UNQb9hJZ0pO04/MgDrM6x8P6QUyqM3pCuvLKiL5dP84oSxxgGfR/dCTiqPyPHpdy+r9+t3nhp800eTc6AwxxA5Hq3FPpUYkQI5gsc91LJPWLQG3shnHFOgi/pyow8xYQcKUtAxYA76Qho7+mPiJ3/sbcDDzUBBVvTF6SGZ8k42VsmHugknSkxedShhpt33aNzzzBqPQKwezToqzB7jn/uto3PtQR6Um48wAbzDP0mMSIGz72zqkIEsjYixIs+nM+49aFdNweq3Qteq5Mh9XTGxvy+xwa6agb29kQa4slLWyYBXE5i/nrDFUrD82fY3YMNaugwNy2+IYSezq44LzkBYGJKbWIyYp2n/NHh1EMMqcMbdTSZnK/s0BR7Es1GF7EHEZYEDsK7A4Mir0R2xxD0bY0HUg5VmAq3irg8Pw+MROV4pnlEX7Xo3HoieYJ+moDNsio864kNxLBvw2Nakcr+cbamCccVeHj+VF20cVoHXvtr1ejhuQtTEMGYS8RsxUDaxWQo4EApZxRh6pRxpwbpC/WE+6DO2SAq6o1qhSs7J0UFLlOXQArXdttgQntwSWqmSIT/pjIk1/9Wn7e+O/7NdPSuq86w2yjAeTirRMwYqqwLxYNraD0InyrHNQh8Gv75c5wM8jZIUHIzGJ6lkkkT7mFB4zLRe4pZ1PY+p5JycWukR1fmy/4w2blvfc7NKhuTctOlAVPz9Cx23PbUl9O8ozYpSvxajzJzRXli7ts8uHkJWBd6/se+nfMiM3h3MgQYnlBhxPAALUvDC++HLVDJOtoXiYndX/GycpAD9+jYejE9Ir5/OKuR/+X5NGScw29tRQE2Gl087o+Km17sWznvwkLX2g/57aDS4mIIVs4PXrZiVL25YUMDTRbLQgawKXLWh6/v2z6wYW6AJhEFl1v/4lv4L7Z9ZEU5ooidqZKw2dnfGFycSSsNMQQBuhTAylIIkQUUMDv7wiCGtasF0f83vO66YvuaQ+eDbfevtSxJlQe+LV87Ju6QyT69AurPTLh6CUoF72yP1CBaIfXIKy8qyPDmth6VQGsw4FkYKGSd9CCk5HlvAgdIcY7uqfgphKwamfxz222JDoEcoZYZhNBYXd6zvnHvCQ83Wtubo1XZzzEsfBVvt0xQoFfjwu6GVDE7DsbFazsAZ+Z90BUX9dJYEaMW48zTofiyVFPWdrM7TxdRyLBc18ZwtlgLpiwq5kbClJyIuerrlFze/0TmsGygVuHZ778VoCb8ORyEWjPdydBbLEwcYwzLrZ5LLwFyv9jZOUrD6jc77VfWd5ApoWpXXQv+PoCADCPj4q5YdCSPxhPj1eyHjrje7WZAVGQpE8uof3AXJbNRJTTdERVBPXejaePa9vqtUMk5y9yQg1+XiQ/5x4pn3+5eqZJxkCpXn1dbhRInaYk9IJfd52B+Niyc29YgNe0JRFCiRocDNByPzOHbDsaFcoxKa8TMDmEC+oZJxkttf+bnqXDYeM6lfpVySfsxeyM0y0ookfn1RZTHWx0rZz8NQJCHWfRzxwrDkNJyODAV+2Br7WnpMULE0T8a/jBmQ2N8ZqVPJOJkL8VMmIggK8YAUckC3EgmVTJJcQubI7kWH/KsAJpLYf3579NTaIo+sr2pnpNzWNCD641bGRgWRocCYaR42f0ry6FEy+1AqMBZPDBsD81HjmGoPY9ibKEgFJ1GFTJKMbyeOl/0/zD/ZUBDQt9+7tHzNKZOCIghrVLU1Eu5oi3ObKyPWExkKHIS6oSSZQiys83GUV6IgBZhARjQA40r9AsvYQzhJAXd+sFDAfanlyABSnxPqckwoXzmATtSV+r97+xllgR+cVJKYPjqfpolSdbvZmEiYSLxFLk4ykKHAuCWMdBNOJ+NP0Acz0TJXAU9t6VmhknGSnd5+RjmrZ4zqdS82YQmnlkuSORvuQRl/d7ZEjp599yfmno7oH+0iZgqRc+vzPY9fUDr3xsWV5oRSOoi6bRVriwzhyWJqGcXRqJmXDKDZOLbYC+tRL6F6BxJBlYyTs8YF6cJb8GDv4zQF+7tjdSoZJ70+P3e2lbs4Sx/b927PQEJr7ovPt4uG4EO4OL8+13hx+ajzbj+z0pxSFeBzKPtwsqHKj4RfH9rGdyJDgVWFnm6oHb+ys6YACtTVL4faQ4lKlUySpUGP+NGCUrp/xgMS/TErTyXnZF0hHkwTWVKLwTrwpKzwevUXTp+cb/zq4prGC2YUWdxTdLbvJD1+YplPeD1CuWuUocA5owPrVGY8RODIci93YtrlSRo27uufr5QDPUhOLpheiAHQ34AC5T5bOlp7YzUqWSeXTIGOhXhICjjQ0W+NTdZ5ZXsvDkzos8Ov65t+uKBUXzAxL+vKZ1SBRxwzOsC0a2hp50SGAisLfW+hkNI4yyRH5KhyjIihLUeBxMGegckHOiON63b1XburNdyQTe6EuqA4ryFf+D2G0vq6u83SWMIcdgafXZvLuPYTnKTghj8cwqw8WGfttm4RTZivDV45PG47sxI2TaT2w1eeczHbjy/2JNBfL2ukI0OBxI2nVf6cRq1ioV8TRQEk0bq+njNuw607rUX379l+6iN73rlq7cFbsAxWJsF1pV7xzZlFoipPPx2nSjy5teMKlWw6C/yZ+3/Ens7o2GQdE9Pmxr3hE+WFEcDvscLOPki67rkNRQIJ+ZE4VUKpwKX1BdfnBJippo4Ime835BqW2NYcufLY2hz5XoLvL2A9Q/WcrETM/N6JlaKxxv8yFP97FCqR6xN9KnknNY+PlqFU4PgSDyalz+pe91qbhvsaIy8eBly+RtOWr4U5ulg2o1BMqfB+gnv+WFZUQKlAxKfoNfOKt+ZyqyktJlBJ6EzWq68K3L7mnJqnLp1V2uRjS2l1Sb5LvX5xjZg/PkDlnSUFsyA0YBWq2nCSKcxA1Ex9YWvj9Z09ZznrdvUNiGtePrQXnqKcsZM465e7NzvlKoKGuGxOuTi/oYCuW2dXU0KpQOKCo4sbljYUWXzrhlaHyJfNa7d2c9RkIpfjNS66/LjSGhgle0+pSxYGdATrOFccUnkcbR6dYNlt65ruu+/Nlh+r2nDSjEfFHevb8qEUuQ5MoqXPrI6aFtr+rG4CXvH6rh6xcm1TvDdiTpUVHfigKTx/5h07Bj5tjx41KCNE4+hc8S8nVYi/ayzoMwxdsVuZCrp6VuAmPc9s6oo88na7frArYpfybZwuzpleJn58culUKGb7hf/28batzQNT7MsZqC2G23l0M5Gw9PZ+U/z2kvH9FfneIK993BGde/bDu9bL0R8h4CFi4aR8ccfZo4a+hPi0bWDKGY98vK0oxyNqCn1id2dMDERsQ9V0UQ6ruue8MV1Tq3KKO8Pm+FMf2Lm7L5IMOUJuDp83rVicdlSeqCvxPmsYxrA76kRWCyRwo/FljcXG08vH/ek7cyugCDmdy6XNMTVeuvI9vb1mxTYojynKqZOLMSKZienezqj4pHVA398VE4uOCCLWfZYEd4XiX59SERATSkbOc2eUiavnI90U4iPZCNAVMUuYn163qEo8cP7o+G+/Wdv09cYyue2vWaZoD1uYfHQ52/7Hh11ncZeFq4u6soC4+uQa8eTFteKyWcUtE8v8+SNVHnFYC0wHLOjZg93Rpe8cjHihCDPoN4xw2Jzw6kc9u44fHxRlQaNl8/7+8L++0lTbG46LOGZCgukArfDy4yvE8eNyTY+h1cJyhrbi4cJwXfEPIJNzCtE9na7OgU66LPcg9zERB9sGi2Qb5TtbI4cmlftfQtvnsAwepENRmzbui0xr7o2KJVPzu3P9nqJdrdHLd3dG7zt2TIBK5YS0Hm2dDI7cDWx8LgVmA26+FDc9lFhHTLPhL7v7N7X0J7BQEqIcE8msMYEEcsebUY/K+tIBZfpAfgcTss/HQmF75cW/An8TBWYDbxgHLhsiuNl+WejChYu/Ib5QF1ZD5oHngxeD3FbmpgK3y/+AuQK5knkffm8fLGO8Ms/A7zNBfoG1EJwLOvOzTeCj4AUgU6OfQ64Zcufh97fAn+ExN4LIaczrcZ6U55dhq1G3FcGmCuS33U754yGzEuUvouylwXvJxGHTmC8I08GlIG5M+x64BcTNilrc9CwcSefu7xywHuQs/Cr4A9T/EY7d4DHgAZyX4sh1LwcEM6lFBR0HNuIa385hNSEHhn3zY3IoTvDbRCjLrMb1Gvx2yEvgusVPOdiWcu+T+CoUSAUdAUJhFh5erALvAveATMbpFQdxSL4yxQPKz0daUPYujlshxw8jJ4GwSu05nFO5VCI/iKTCuEpinU/xmyuAU0AOwt2oz53qV8C/gLTucWAF6JCXgFUK5qsfQCbrt4RfgQI1bgvxhq8A7wSX4CExQ9N9pVJoAVRscsNgLAg300guLWgtl+A3Z3W+VGc+WQKWgVTUTbgGtxXH4shvWZgF0LoYFqB8tiH7Yh8cLMoxK6f7og7bNdGexk0IfgsIS8+eH34VFvgyyM1QpDgav4BgXkgl0ooaQCqY+Rks0KQVUTmISVbSMlaAtF62wVcCdHdaNF36d2jzN7jGl01wPQvhQWI8iFWL5nwNykGkLAeCGwb89gWWTmVpuGZRqbtA5bc/SXwVFsjVA90WMcrid4VcXsG9LCiFliBfFkFZctTp7rAS+VUojiYnHk4or4MM7LAki0oYBfIjS5ZzbcwBgAVrVDAV79xn44HuycGiVfI6lcWPx+1BkspjHX4PrXwXksSXrEAL8cbkrgzcRqO7IIjLB+foJx+O2/BUFi2PLokVjkVF8IH5fTLOtadAexmnJRWIuEnrlf+cQ4uDNVlcHTF+UlFfwzknDNY/FXK0boQA+dU9XZlJP/Qhr2PykSEE8VLrwzErKPglggq0MIvKuMMYxCMf/HHcCt0OriyuRR26Hmc/uJKGdMZiqkLlIfbJyYYv4/lgVDo3aDmzYjLRfoEiWvSNIBSkXYnjPpTxW2m+06BCKZcPcjKBu/NcW4w6/4jfTSBdmpPQayiHh2gMDVnxJSuQYEphwWKSOzLWh/jNGdaedU2kJpp8a4RrtA7uBlOZE1FezNI07EA9zqSYTLhBIfPMCfKKlJVuDuuyKE/XBKRlIr7pdnxj/JXXOaAEc1NcP7z1uXDhwoULFy5cuPj/CiH+Bx2mAcUIW9XhAAAAAElFTkSuQmCC'
        img_str_mes         = 'iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAAXNSR0IB2cksfwAAAAlwSFlzAAAOxAAADsQBlSsOGwAAE6BJREFUeJztWnl8VNW9F8srkNkSskJWyCQQQggkmX0mmcySTBJCJiQhCY1kTGa7986dJTtbSNgVUQoU9ZUiaoviVvux9uOrvqofpb7X19bne1q3KihucWERFYok951z7jI3yQww1P/e/X0+53NnOed3zvme337uTTcJJJBAAgkkkEACCSSQQAIJJJBAAgkkkEACCSSQQAIJJJBAAgn0/4rcwd0p+SbcLrfi9sXVXvuSGtxeWOe1L63D7MvqCXvRStyubPJrY+Vb0ewvWF4XAOP99mUNQXvRqqB9sS1gX1IdsOdZffa8KszuWb83tX5dn7zQhtsLasFc9QH70nqffQn4XFCDgbX4wdMP1kKC/0kwHq6NtBcDfsWrQohv4UrwH1izoiloj7YW77ZDycWNwW65zX8kx+x7fn4F+VJmue/fcy3BYwU2smc1uXPxDQN44Oi/zUrTe94TlTopUZmLEpW6KTF4wiZROCmJsptK0TrPDe9/UBQLX7mFeFGi8FBi0ERKD+ADm5d5egBP9+k77//tHHv3lpwkdddlNJeim5Iqu0BzUjLQV6bEqHgVDhp4quF3NyVVeMF3F93ULtRXUtpFzdNjl6auof+nD0iWNfQcSNJ6vpOqPGAsBtYD1gAb4CkF/GQqJ5WowSh5deg567oNy24IxILawG4IYFyZGwFIg+gGE4EFggniQdO09Fmul5934C5Zmtb5NQRKCkFTecETY5oHNQDw3bDvsydenbGgEntJDAAUK1z0nBAopRc1GQBQpsTBOujvcPOIh4rmIwEASsFhp6id5/lrWE3skhY29D4Qr/FcFpd5aNBAk6m943P1vm/j1RiPDzgUtYfKqHC/pm8fVMcMoN0zWiwqcyJJEUGpKfNwJwUnkYGTlluJB66Xn6I+1CEFgKCxcONwsWocPWXg5GXgd92aARPbv7A22AvBozfqpvughlNp5eSFRDX233NV2GvJWuLtJA3+yVw1dgVKJpRGFpz0cuwMyw/fcseP5dXkcchTpICCANYB+mQYfScKG/rqC1etVxat7A2k6Lxn4aEicMGhwcNI0Xs+aQneWRoTgA/97uWZqXrvuAhslgNQGf4sUYIT1nafwTbul1wPv1yL7xkoSbRE0byQygAQZaAlgFP/2fE/pLD9lQ2BGlFZF2M23Bx4sC2u63+spM4Xr2nqmVvTtW1+6arQoqW1PVX5Vt/BFK3nA3hIkH+awXua5VdU471VXNY1EceZIjeVqvV+3IjvnMdfp6p5wAMlUQJUW8KsUQLmzDEHXzryxIs3xwRippG8DAFENotpSKWRHYNq1U0tq/W3XouPc3BverLG/Q8xGutGkixmbI5MQ1DxoCVpceqtLy5L2THVHcMV4tJutFGJipZaFkCwmaPR5jK0DS7MtwXuiFe7z88rx9+Fvx359fP/km5wvh0HbTrPnucYvfdOHb/17kdmzTfgpyTARKADhlKtIqC9nTC2D62ICcCsSvIKrcJeDsCwNEJb4aJyLf77r8VHvbqnVcKoI79BSYQSGK/1Uck6gvrb2KV4doypdYNWXEqPgSpFA0ir8UJzT1QAIT35zMs/Wlrr788x4f8Fv3cP7M2NB85IXErPC00TtK+ZBudIpPGZ5fgjYiVro1kgPVRhFbY2JgDTyonvxKrp4LEeC25qnt59fseBY3FX45Njwp6YCh7dXDQ4agigj3r/3ATHR9sYUolKXMhx0SCyQGLg0K4OIEsDu+7JhU91Y6hdWubi1k7P7aayje79kcYtsoW2ihgzgPqjSMFLKex9nTHAd9NNGZWB75EKK72T7B9rD2mP5aZKVwWjqvH6vUcSk7XuS5PGMirE8oEAJgEpfPeLS2J2XNVPRvSiEjfnKWlVxpC9zKvqvy4AWVpWTfaLFe5p88/Xe9+M1H9pba+Lr3licHDJevKjobseTonUPyplWXooDsCpG2cMMQQx0+j5TTQepSsDbqQ2kQAE40VQPbTABup91Mmz43PYcbbOHUZa8mjwpGov53DyqwaPxrKPpRb/eknZdAAloGmaNzRP7V/SONARpyDA2ggqQYd/J68OHGn0bZ8fE3iQsi09E3HKsPrCRaCFIInwcACm6Fxjm/ZHVuOFJvyRsPq7UbjCxndiECaIoZeDTkRPUh99Tc1kx9U4dhhRqAFsj4RxICyAi6qHYgKwyIp7pWVhaabNAt0yjb4/NhE7xPz+quZ+e6Le99e82oF7i+yDdS3k7oSYwUMAVvWOx4EFsyqcb/Gfh6ChLIJRKxTXASDUzX2NU8e7N+9LTNJ5vqG9tpuaq3FeyjGRZ9nFs2ECVOFEHUl9eJ6axY6td+420sEsmyFgPAmMTYUr2/srpIy9ZQGkvbEHBeh5VeQ9I/t/xUl/q3eDeN3AbtkNgcYnAOBEnJqgJKjBk/cfi1c4v6cDXDcHIHzmmIjHpo5fvpJ0xancyJZAaVtgwp5K0xOn0IEoeM6IAfADHoA1t+4w0KBhnPOA4YQMfF9UPXA0ln0M7Do8J03nOStR8s1R2CGCuG+iqK7nYGffnXOuzS0GyrL2fC8G6gVjNYkGp3JtPXsyDM6XxTAM4Lwa3ZI0nm/bAruS+OOzzfhLNIB0rqtuGWpL1RMfsBKNshooVRofNVeHU6e+npjNjq1xbDNIURCLMdlPGMDFttgkEFKelbgXhl6sNIedE50OgkB+Ir/af7SB+AEkj6VMS89lqQZuEEcAyqtC+xaZPVvFZd3UZK9Gq0LxSnIVO3bDniOyJJ37IpsKgtTrMjn6i9T55cSnYjZEgJ4c8kcSiFMnz/OcyLpRg4QvqWij+DUBJIYPZK3BhjKn/l51y+ZyEItO8AHkpBCuBRYmNF5qxeqhXR9+Tc34QQDMMgMAUb5KT5BrDuyr7xzKiwcpkYi3MdqeuaisCuxxdmxxHdElgnmnkq68LLQEfgd/X2gJnmNVGIHIAJgEAumTF6gwgB0jeukkz003qMry6t4TKxp6HUvrAo68KhzPs2Aj2UbsofQK7O8JMKxqCDki7SffjB3kr5s7GOCgJBBUxlTkVwfv3/urp2ZF4hETZVT2/APaPpgLwnBDbgnug7+n611/RAAoaCmiPzupJGX3xb7bjiA1BkHqi2IGPPi/smVgDfw91xI6C6WAjQEhfykwEckgjDl1geJUWG8fUEv4gTuvSMDlxWoCORUpo+astGpa1kcEcOOuQ7MyK7FXJEqeWZjyGTa4r2wT8YKj765/Tp3TK0OXWAcCm9zagwAssvr8XGzHeFJoE+NKu6gltSTWHrotH9bmUPANAEzSec8eeuiZ2QyA5zgAoRNi8uEkkInwnYgNBNLIWyvYmiHfZmF0KQuBT0sPF+iDz+rmDeui7am9Z3dymt77P6zkwYMImyG+bfRQ6QbPf7b6b0+8YQAzTFACaQcCYzV5VS8CsL5z81JZmWucDyD0xHElIL+swJ4orAsQqGjAbCrL7H+a5ZlrDdDekEmn4KJhLgxV+P0zVzgVrmgeUkuYUEfM855wcwka/AqI0y4mGchLiQbyCuTBxZoKmHINdFxtX0W1gYoUHTFG57jYJOnmAyhTuYFjCf68zb9n9tX4RaV0U+CihHEg8LTzqmkAX/nrezMyDa4/TSouoNjKCbyZ6+LC6uDbrDTABSqa17ezPBeYfWdhfo0aE8YgAIEKv/X5RU5lah3bKiQMwEhilWGPmWMJPV3UMKguWNmvXlzbb1jetLlpUU1oKNNIPJ6sw99TNvZfs0JkWLtJl2YgTtL2mG4iplrOzgVz/QQ1PpFX1bPn6JMvxFbKgpRhIsfFwOuJmeIn9MLsf8uqiUD41N10VqEIR/iongbCjlQDeWbDvke5MlV2JfGFBPJkihRsSQsC+O6Xl7mMoKZz1EjHmUwogySQ3li0YsKfXj81w3TLcJa5vS8p0v/TQGzdUJhe4X2NNjXhXJ990vEnDsttl1c09rXEDGBmpZ9mrKaLinJLGMBb/HvmJWo8FzkVZqSEs0UKWvqA9/3XSTyN2Cewvifi2VAZ40Te+fwSV5yt6dxqlLJ3JpwToVVLbu2LCOCNkM2xMSvb5HsRBvtxCmZdTN7M2Vuw/3l67IPOoUOxOZVMcwhICvDAYINiIE25Zv8+/v/ZRvI/WPD4ALIgws2WNvY28ceAVG4MlspZG8lJILCBb45d5OqBK7u2G2FsybdLIsbrx5qJXIts60YKU3X46ThGjeO4ElrYM0Nzom7euDomxhmmXpTGSUGmANtUAEvqB/xSVdgDshLFtlTgfY88+YdJBji3kvwClsBQHxh/wVBES6Jiwsmz4Xpgg2u3kb1I4nJuWFAAm8m7gUzkWmTuGMpKNWDvxylwEE2wAjA5Xsyu9D0XE9MsSxjAeJ2fyrOGJgHo3XBvahLIMKIBKLf6757KM8dIfC5lCwQojSOoBK2fSjb4qNPnqB+z/VZ20dUYVgLYcj5si2p/WAlkqa5764IkLf6pqAxonQKbFsQnalzf33n4+FWLx5MI5MLjEkb6EoCE5FoC+6b2WWDyP8mpLQwnUExG278m8nbD1P4LK0NnWJWnsxxopIEEagnq719+z90zW38ybGS9LnRIyJjDyyewlkW2Gwfwz++cnmkntxsXVeHb15LDqVP/r1yzCRYxrsQpJ0sfOkhwoIYm//LrnizL2juBQhgtlEAflWPyTQOwqC6Es0k6spcoJvNSaSDn7dtz37T4KUPv+3TSjRy6VAIAgnlOfTXOBdIrHduN7PUne7kDQUwA/QtqBu+LATNEds9oUklTf5vcRjw6z4ifTNJgV1Z7RvOm9tt024MzM4z4M2wdlAVPxlyZltaT04QiKmVZ+5ADgSDG60gq20hMAxCkOynJKuCNofry7KG8yj+tL6Q0HXGavvHCpwH49mcXuTCmHqiwTIlxqRqtvgR6yq29027Trkblrf2l6eXYqwkaz7hMRdvSBGCaVmO7IkqToW2oAr4VIVJ4eOYD4ADWXdkxbLzuiTPNfdQcFQ2gDKhYVgUeEZQFRvzXKJBm8l6pwj1hXTdSFqlvtin4pUgJi7Q0MLQK+4B9wak3Pv6G88K1DhDGRLGB6QbfT697E4AWVnjvEZUxeTdnNnBKF+XNikPHfj8zTecZo8twTBkNmRCM6uy5M/+6J4YAilS0DYQAppd7IwJYbPM1iJn7Ymj4QUbwxguvfvijSH2zTaFzIiYkQa9qqOmiwFwNRr0zdokLuCGAtBPxTgMwxxSa5pwikcW5LaOma5s+x0geQQDy7C50ZEtshC/a2Kxy/C9ojBLnAEyv8H2569DDEfcVkTLNPSj+kzJF1SyT72eR+nX4ts1NVMGLc7o6nW+LrL5oYabgOe6OhSmowpYANvS3j7/hAtXqdSOcF+aDh7xwdf8vrrX2WzcfXJhrCz5dUNe/Kd8a2AkDZD6AsK4ot5BRTUFWBfmaGL2dAPYPhAjOm1sVfPZa806itHI/Hatp6JJTri10NFrfBSb8cXRpBABswHdG9VSZRv9ZMVd68qCNIJUCtunEGx9xKmzu2GQUK9yTjTijznJLz+Fo/Dt6d80vaug9kKTDLkH1W2QiSUPLgFXCvtvDFBDod2x8Xw3d8bB4Ko8tB45LUrTERTGy1T6QysJGUKrW9VFfl5tG9z36XIJM6QIDaQCh/ci29jwdrb++uc8KrwnTjcSJq/FN07m/5ZfS2dpePAB/4Pb7uLBC09hTL2ZsKgsiOy6vqu/Ih99Rsz64QM166Lk/z23y71yx3B5y5VrJ3yRpscsSHt9lNv/aZ15+/eZMg+d/ESDqcHYBPXvhqsFpl+uFtcE9MI8XowbSWTVJLa4fjC2IrmjttaDigIouJsDJ55X7xt787OuIVYlTZ8dn5FUFHixt6quNxpMYPpgnLeum+IVSujCKow1rW/qq2L4FNeQQm+RzpSamLgh/hzYzEah9Anqfz8O8wxJ2OAnAs0PnpKgP1EF+uqa+4mQt9o2MH99B+woLxdbgI8X1vnrVmqFmuTXwMAyfoKMTAfDiVAEqozL0lnP4cHJMABbY8C0i5Fkx+nIdBrNK74Sprb8o2pia7uGUFv/WqLUzbUv/uvCdbLjigewSTNGqye1s32wz8SSMxVB+yqgfGyJx7ywqwpdaXHCuhN6SQA3abUPbgBHye+D4szcX1pC9yRrsgoRf+1OifY3P1eCfpBj8Y+AwJ6CwiIDtm6MkqTRj6D2jY5s5JvD8g9vF87SOk+htJlSh8KKNwIXnmvFfxsSMoXsfPD4z1+h8Ja4EvvHqQrVDEfv2FZIyDGQjno/W9u6NvyWwvSBe2f3d7FIPBdscABacO45xPnPA+NklTvp3pqHUS4Ejr4lK9ir6paDVvu3cgf/l3c9mqJoGzRl64veJauwCzJjiwDhRGXzSoMGoQwSjAi358ULb4M9NnTsWxLzZ4Z37k81r+12K5o0O1ZoRh7JlxKFoG3UowOeKdaPtp8bOxHxrdfjYY3Ms7QNdijVbHKq2rc4VTcMOVfsoaor2rQ51x25HWevWWz2bD85vcPQvLm4YcBQ3bXEsWbUJPctAH7qNOkoAj5I1o44VYF3LV28Cn0dA24Zaaes2h2ItaG2gb9uww799/7TXkDtDt81eUd+rXFLf3zff6L8/vTL0bJoh8Dx4Pg2yr4PLWjbdqmzemP/UiddjL6LyaeyrM9fuJJBAAgkkkEACCSSQQAIJJJBAAgkkkEACCSSQQALdIH3+xVcxXVn8Hx7/TwozSxdIAAAAAElFTkSuQmCC'
        img_str_excel       = 'iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAmCSURBVHhe7VwJbBzVGX4ze3hDQkNwHAcKDTYk4XKIIDSyUpJwhASL0gOoINwSSsMlDpG4CCFomsihCBAgFA5xCQVSCGrTSmkTQKWiAYG4QjiEDG2UFDCQw+aw13sN3/e/N+uxY3PYb8beMl/y+b33z5vxzjf/8XZn1ipGjBgxYsSIESPGDxKOaSPBrs5dk+asu2lzVyE3xpiUpzzPcV3PwT/X8byS58hrEkOphIEeV9ftX3KU63kKzQDAbEeVPDc4Z864KaVbDj+r2XXdW43JKiIVsHFt8/a2rt0HmOH3wr51Pza9749NM5pVJpMJ5Vxd00aCT7vaJ5pupMhms/BzL5RzjVTAkvKSphspcrkcBUyZoVVEKuAw40emtYpIBXSR4k13OBDK745UwJSbypnucCBvWquIVMDqxOg2L1dUAzKviaUI1zdWgRVOKB5orbSve+f5Gxb/7bZlemVnzh4te67ySlzWFbxSosfui8T5uvXnJ6uq1KgJNcpJ4vrqZeCQljF/n3KJGj9+fAZrwW5jsgZrAh5w868KBc+DQFoIQuvCn0YkEYjbZYOZ1nu73y9+3qmcDIp2QgfJuKmTpR0MXpq/XNXU1CThhXBvu7AWwkW8AxAxRCQ27GPhwrH0aWfL/8bGhU1we4Ayr6jtNhCGeIS9HNjr5P1+f3akorLNbEfOo71nHvoFzCtyrhx9xMKagDj1gDC6v2DyTHXtcQvVEvCI2rqyne1vZ/5SLZ19jrSyt2wLiFiyJx6OZ+lIe8KagCwUWgQKACHwb3v7J2rJbAgIoZafvKgsTtPURrVi/mK1dO552iZV1xfO75sDj3DYC2GFZQJPnG4jGnhqS9v7as3mp2XrrEnTwAaxL4d4xKatm9U9Lz4lNhHPtNKvEFgVMCgCW/L6DfeojuyXMmPpnHPV2dPnqZ/sUyvj69bfbeYiXCUPmv2MF1YCQioiPbmsvfML9cfnHpUpsw46Sq1YcIn0V8HztnzU2ns/XzjSLqwf0Ie9IiInbYTTMWxsnhar7QOZNzYzRm1rb1M3P/uw6CRzZJrZh54oQsr0EQ9rC+mJy5u688VCWmsniogmogQ6b1yzGqGrPw5kSE+75SzV0YXQNsLJNP1DxsmtX6kkrq+bxmLadVT2oL1k38HgvSvWeLW1tRbTVQ/sHbSoHL2eEwV0a0K5+fjzRTwKR9ILW5ouD1RcM59jWb7oY1QC7IUwaghPWpYwEMEXpaG2HgJeIHNWbVqrVj7zsPQXHrNAzao7SoerEZKU/fShKgIWc6AWTYsgBuHdv26W7dt2t6lV/34SfEL6xMqfX1GeRxF7iVkhsCagQ90ogghCL/TU4sbTVcN+h8j2lc88pDpQkbm95ekHxdaw/2T1u3kXic0XX8gwrhBY9EAtHAXoEUMLR65+Zb22Q9jHXl6vWjY+oFo2PCCilnMfQ58XgWPOrQBYq8ITbjwp253PV+ncRQHYUEzdlgURW892Td8uE6Sf/jinki7q8A+mCisX7oOGKhgv0p5kqmrAXs5zhhS07MFmO4fR3rUeHKwJmFJOQYehL4ZhWZC+9kC4mv1o18WopJyc1Y/vcPBwYO0aX/z4sh1PvL6xuic0afVF8226XxZSpvh2ztVjpyOvqj5XKjG6SrmphITwULD51r+GFsLWBCwWixtLpdJJZuhDJCHb29vdg5tmfMtJOHIfxB2VUskxGWmD90UGCwhYhICh3NS3nmXgXbxxxOd8KFwvTJw/LZsr5KrMcE/w1bj67ZtblVROOqEcc09kKICABQhYGU8m8N5Df+IJRiWSCXhWv9zb7yNsM/A8hK4zxNANoP/XYwGh5IWBkBid9hiW/RKiCcueB/GGGLo+EokEqlQ4iFRAlYBvIqd9IxGy4nmWxCOQVv4/BPT4vOTwILTfG6mAbmJ4Hi7C6iC0x+oiFXDuoTOxuosWjYdMV+l0OpQHi4hIQ2rnzp1LWltbWwqFgn/hPNd1ZZ0IL/GQIbUVQJ8DB3YxcvFtbN+KwDyvurq6VF9f/1AqlVoEs/Vq/J1ekC1AhLH5fL6hu7t7EipjAeMCzSD7Rdi60XZxLk42jYZC8zWyHTBajGB7nAuPj2N2JpPJVkzZAVp/vCNqASnKXqYlgidEDxQPwXZfkLKNfUMi+LodzHcxT/Ir+2g45twixlyXZsFQnk2MVEACJ8SEzpOTEw4IFCNGjBgxYsSIESNGjBgxYkSBMN8L8z3vfuA4cKBPUnaBH4KhfAmmD/hgdgbko2HWvvIVpoDV4LXgKWAW7E+k9eAdoH4KPVxcCk4F+fv+Q4MNhCngBHAFeBi4GtwB9sVW8A0wtE+MA7gOPBJcBr5Hw0gHBbwf/BN4IA3DDArIC0kvtIYBP+WNEHxS4QbwKfBnIHPnKJAnfDt4KEjQe/4A/gXcCHLbsaD/xAHn3QiuBf8B3gbOAQf/XNx3gP7+bjgYDZ4I8hFVpgpe+ekBTgH58X07+AV4Gsi8+TbI/c4Bnwc3gfuCN4H05H+Bb4IzQYr2FsiLsBSsA18EXzH9k0GmiW3gcSCjgvvvBK0gCgF/CtaDFG1GgPwCMJM5T5CVkZ7UBLJq/wbcAvKJ9E/Bs0E+uHQfSE99DWThmQ2+AzaCFGsV+GeQeZXHPR6kR3M+BbcuYBRFhF7DcNJPlveAN5Q+BumB/FifSx6GID2Roi0CXwVZvdeA/Mr6hSBF53xeIHrZRyCFZojfCX4CcjtDl18FpXfTO88HrReRKHJgB/guyLALkp6zG/TviXAev85ET/wfSC/xb8QztD8DO0F//lcgw5dryb0NKf55IMU6E9wH5MUIbZ05EoqIj4NBFgWGH3MbQ5ZeRlAE5kGO/aihYCwS9ELesKdX/R68DOSa72rwLnADSC8MBSNFQL5DoOfwdier63PgL0CGHHPYP0GGJMd+1T0CvBKkjVWZx2DaYEgz/3E+c+fhoO+11hFFETkGnAQy4c/rQ9oZrvQkhh0LwDqQBWQhyL82xDzI8VzwBJBFhgWJX/vkvV7uw0rNQnIqyLdsLFpXgfTax8FWkEukiqrCXFowFJn8a0D+1ba+5Fu87eAZIN8TPwIy1zE3Elz6/BekAMyZ/LN5vCDTQIrKqkw78yHzLD24ATwaZIG6F3wBpNA8FiPuJZD51grCrMK8OEziPOmBfg/Xgcxf9CpWZXqGn/D9wsAqzeLB440F6dnscxlDIfy3gbTRY7mdYc+Lw335wQFDmPtSYNqieOsYI0aMGDFixIgxcqHU12of7/j4UhWUAAAAAElFTkSuQmCC'
        img_str_mspaint     = 'iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAA33SURBVHhe7VwJlBTVFX1V3T09awMzDNtAZEBBHFRAATVGGVSCmiggSE6IB5eYoCFC9JgQxRONBjXLccGERIMYxIgLKkg80USNZkEJoEIExzCKsu/M2mtV5d5fv3u6RyCY09UDJ30Pl//716/q+rffe//9WkbyyCOPPPLII488jk0Yujwq4TiO/9OYjG+0nIGW4wSrCszVFT5nhWmaO3WXDsdRJ+DrLfbMZc321zeGnWGOmD6IKLbtQEwIytJGp4TljAqZu6d2982sCvqfdPfsGBwVAr4Ztq9/dL8ze59t9GwTyhWLArKOf25b2nYb27sFRG7v4//5SaHAzfpwOUWHCvh21L58zm4HFmSYSWFsqGInLNRtEG04RccBWSoBXWEzrdKRU4vEmVtT3APuvUsfPifoEAEhgjluqx0XA8KlrEzEiidkZPRZGWc9RGWkKR6SZ6PXytriMWL4g65gSQFV6daTbf0LRebWFF3dJehfoL/Kc+RcwHVhe8zsfcbL7qDTBLAcOSn8ivzMuBh1tMVhcZrTD/xaNvSYBBEDrojpAqZZIev9igx5dGjx7GK//yf6Kz2FqcucYEWrPXn2XnmZ7mdDMEVdt+Jx+UbiLnGiEC1sgihbXU5MPCGJlma4Ntw7bR/FRFvdAj9stOS777bchR/lC/prPUXOBFzZYk+Ys9tebMXiYsViEMzCoLUgirb0i70vNoRzabolBCyNhyFgq1iIja5QaUIyZupj0IpZrtqbkCWftGzSX+0pciLggv3W3Nu3hZfE6xdIYOOFEqy/SPz1k8Xe+3rKqmg9deGTUqK5hIjggeZCsRFtlFDo71B8iMmYqZhIYBs+s9THe7g+ZiQSidX6FDyD5wKujdgXPbM7Oj26YZGEIjeJGVslVusqSTS+KtZHl0t8z19cUTDTPhqdkRKtTURDFh04T4wAplm4K0VKwIIT4YhYkahYuoyzTutWIlqypTkhL2yODtOn4Rk8nUQQh8yLP45bsQMHpGjrePHZ6wQGIxgnSkPVreBoKTzxcSWgFY3IiZuXyJXhRyCWIY2xYnmiZbRsqJ4o/s6VapKgQE4UYsVjsDQID3IYKtXx+2ESBaAPTT6p7R6Uh84Iverz+c53zyj78FTASZtiB5piVqfIju1SsueLkoi3SEwLhzkDdYgcHC5lg59TA2buZ0URH1taJN7aiI2GmMUhMQoKlUA2xJtUXC8zq7a4VqgYVWWcdew7r/EUWWYPEfH5MVObsn5cebSgAAfwCJ658LaIPagpbnRSccs2pCVSLWHMsPA4xVZdRmMlsDbELTUhYEczIGZpSALlPcUHGkFsF59aidhQ/qqKTyQKgdvYKhGQZbS1VSZaK9CPMZLW6cjKPYmge0bewDMBr/40sd5NN2BcMICGfWNTorFUxIQR6DJFME53glBic5UBa4NoWAtDONTZprfN21SuhCIjrS2K0TQuah3sio3+nK2bYswPnW/p08o6PBFw7o7oS5xVOQi6nhEskmDfiRJuuUmiiRqJ2SeLZZwppVUPSlH3Wtc9df9kauOmJDpFgSIq4YawTzf2k5W7TFida33pXNNUJsudYcp1lYj4b/2+OEr7a/rUsg5PYuD566P40ZODZsnYhlgFq4k3Nah2X1GpGIXFCH0BlaJkrircwaeOwZJiIgZyouka2Sn3lSyXYAL5oY6FDVGRWTJF9hb1glkUiG0gGcfxZp5SJjecXLwPcbBCn15WkXUL3Bu1BycTWjdXY+Icx2DwVRAsUNFTAl0R20pCKt5ZdNdk/yQhnuv+6W0QFafrGH7Z4XSSp33jpKH/VNnac5LUdbpY5huXyG5/Jfpw8uAP4boxxQcwLXuDrAs4b3vst3RfJrhD3lsmtyyYKLc+NlFmPHmlDFiP3I9XWhzEN7qZtrQMobhvmutmbkd/uDtFNPxIVzIAcUnlukh39D5VxaYYhrFbd8o6si7g+2GrgrFrYN2bcuPS6TJo62oZsHWNDK1/Q25Zcq1Ur1oKi4yoWdIVJU0sPeiUBSu23+6K3rR6ruycP0R2PTZadi2aKM3rXkQ7rRni0e31Pr1L/WKaJvIkb5B1Abc12/3othP+dr+ygjiESoAsyS+vXaxWEUqYDOvSRBv3G1UZkPkjS2Xa8YVSgrN0LUrvA4GYI6ZDWZ7eTvGSVlxTgbTINGfrbllHVgVEvOliOYbJPKz3zg/SxKOQDuqOBCMI/OGwGmDSzdqEdNtqId6Dw0tlZGVQpg8qkbkjy1JWyVJd7lKhLQ065pHquDhmVbFPygKQ2jCQtnuDrAq4OZIYkRRlY6i/EkyJF9dComxwMCK4GgVMully4EnrubSPm/vqCUBGdivQorjxTfVrpyA/J4+VFHts3yJuor16hqwKuDNin6mEQArx1JCrlQW2d+HlPc8RCWACUCK6A00n2zbsxxovDZubEpYSJyX2Zy2Qn93tbZZ9YXUh3dfTKzJZFRCu4vDEaWF1A8fIHbX3yrouNbKuvEbe7jZcfnz6zVI/7DJxzKAK9G2CuPGKA6f1PPCvZllQ16qOuaXZkm+/sd/n9gNhgtzvoALqY3B7VYlPzu5TJD6f7wzdxRNkNZHe0pq4/NK3mp7iYFTii8mEV5KtaFilGGYAa/oCuBUvHHDA7EcxtCAsk+Icso2Xq+JROX/XwzJh7wPS0MTrhaa82P0Geaf6SnGQmHPtPOfccpk2rCyOBLp9vpNVZNUCuxSa/0hZFSyM+RqvppihrmKWliORLkGbT23LcF+9T9J6Uu3aMt229Lojn5gn6G91sau4v7sdLPUbMmVwmfj9/kF6s2fIqoAlprklOQg1UJArDVqEuqJipa06sO3SPgWy8JzO8tpFFfLvyd1keFcs69L3T9Y/0wYxaZJpULOz3v7DszpLWQEihWnW682eIasCEiNC/s2HHHSaKLNOLpG7Tyt1zuwRnN63U9CAtRiPj6qsdvfR1qbqbfu0tdGd9RdqJK16cGWhfGd4Z1pfD73JU2RdwGuOL3z+8NbjyJzTS+WqAVgXBwIhWMkv9a5SVGRsUn2Q+iT7ZizrUm3u53TQIMv8mP0n9ULd2YTj5uQGe9YFPKMyOKPE1IM9iJB3Dy+T8ccFHVoc0Kx3U9jcEDlB7ZO2XzKnc+mKmXTXdHCfe8b2kN5lpo0fplo3e46sC0gsr+1yZ8bySwtwD8S7rLqIlufXXVPY7zidT1u4tS4llhYyY7JJtrNsFwNnnNNLpg4rp+t20005gWf3RFpjidlPbGy9k1eEywKGjOldiNzMZF5WBMuL6G4KcDl/t7kfxWxkkql0BRU31rGuSyUesuhYVAoj2+SRpq+k0phpC7dLcaj8RrjuffqwOYGnN5UwGRQlEolPUfXB6mZBuIfdLZm44sVtr7z0UeQC93GNNgHVNT1V6nbWeXMdeaATbpQnW2tTAs58Lkzr83Q8B4MnLpwErCGMPLYSLD+UeMS7u+IDMlxVWdpB3JdtnKGxvVdZ5r0iHJ8CF+uPOYOnAh4p+pb4gqnYpmNmcqZNF4/kBHLLqB6y+uahem8XtE4gcxGdAxwVAt44stPbBxMqNQFRSHDKKSGp+94JctvoykRFSUGxI/4MwWCFMV3NGY4KAWury8ZNGxpKCUXRku5b07VAfnpBpeyc1V/mj+8h/SqCUxESAgwPpmN3+PnnPOgeCnDBTvV7wvuXf9hiNEQcOfsLhXJqz6CECgz6ZgsmiBEQbYPb28XSGeXW7t0NZtjuItct2tEhk8hRBwjZFzP3O5Zl/Qr1w1rYvq3r6hbf0M/ZvnGNE4vFMlKjPI4Q8Xi8HuI16o955JFHHnnkkUceeeSRRx555PHfcCxcvRgCTgDL1KcjxwvgG27VO3gtIB/s/gV4nPr0+cB7KXeAp4FTwCXgZpAYC/LZjsfBA2xIQxfwGvAP4Dw2eAmvBQyA/cH/5U0hXp7iG5dfBS8E7wXrwBNBCrsf/B0YBpPgI13kj8BV4G9AT+H1FV0+GconBDqD28EGcABItzwYo+AWkJZLYdpf4+sJTgdp0RZISxwHXgvyptVMkBaYM+TikngVeBXIpwX49uT1uq03OAscCHYF6XZfAvuAFORUMB3c5wcgBeKfPfkzyHvAj4F0Y/5Ay0H+SDlDLgTkOxolIJ9GoEvzRtBL4B9BWtFr4FJwL8h7lezH/uybjitAbr8HZP/rQMbHu8ERIC3wT2BOr0x3xE0ZxkO6Mck6YySf4+sEHg6cMBj7aG0fgHtA/qmTviCtkT9Ae9E9R0cIyHSkFjwXDIFngXyfl/HtUKDQ/cBkzDsPXAPeCj4Acvtk8JvgJWApmBN0hID7wN+D/ItDtJrnQc6mR/ow5D/BrSAFpZgrwPtBzrg7wJyiIwRk3GsC+Wgb6yx5U+hw73Iwrv0V5ITxHkjrewqkYHM1ac1Pg8vAjMfmvERHCNgLZCz7Pkghp4GcGI7k7xucDTIf5ITCUEAxF4OLwA/BnMOztxjTwEdtzwHfAumyLeBCkEutZ8FXwJUgE+O1IK1nNPguyBvpNSBXHX8HmarQhWmxp4OcgBg7+Tdi+MNsA3kjnjGS9WP/r3a0wzsggz5F+BjkSoOkcHRDuunhnm9hUs7+TH14HMY+kj8Ck/CcIxcXE7jCoMUx3rVftx4MfESNKc1t4DPgJJBLM1qu+/bN4cH3Qpi0Myw8yAYvkQsB+cIaB3SkL7zQFTm7ckJgfncByLUwrexIZllOJrx6Q5fnD/B/BybDfM45+bAkVyVc6h1pksy4zrX05738lUceeeSRRx55HEMQ+Q83rgNINxdahgAAAABJRU5ErkJggg=='
        img_str_powerpnt    = 'iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAA0TSURBVHhe7Zx5cFXVHcfPW/LeS0IWiElYDCirIi4jq6h1BcGxtVrUjtqp2mqnrVq3ynTaWq1TrUvFWm2tW+s+larjWK27IiIClcpUCi6VnQQQQhIISd579/X7uUt4yWQj3Jf4x/0O35zlnnvuOd/z+/3Ovfe9hwkQIECAAAECBAgQIECAPkfITb8SaF6z6uKWFe+fZX360RBrT2NRKB5vLKkaYWUSBdtNqiXfGnxwQ6iyamNmyKiFkeKBT4ZCoYx7ar+h3wXMZDKx2t/+cHVm05qD3ao2GDRqtJtrh3i+SU6cURudPGN0OBze4db2OfpNwO6E89CpgC4yEjI9edba6KRTRssi0251n6FfBGzZvH5y/a2XLQllMt1evzsBPVhlQ03owp+NkTV+7lb1CcJu2meof+KupxtuuXRpT8TbF4S3bzbm/us/a9pR8ze3qk/QpxZY96cb3kqtXHKSW+wRemqBHnDp5rOvXJ8/ePgItyqn6DMLrH/gplf3VbzeINS8x8Sfu2d4S339E25VTpEzAbVJhCzLGiSOrX3uwScali+c2ZRKm26ZtkyzmM5kTG/vURAx+sK9FyQt62y3Kmfw1YV3fbHqtNVXzXnJMlZYCoZsBSQEkKB22qZsZ53UlosywilNFBaYwcOGmsoxY0w41LthpqbMNnnHnpHTMOWrBa6+/vxnrUw6YiyJZyGII4ojlkPyHZbd9t6xPbt2mS27m01S1khVbxBZ8Y7ZXV+fdIs5ga8CppubCuzZujN2xLGcsp0ntQ/Y+Y7Le9OGlpRpkYAW5V7AduUVC6IKI3G3ynf4KqCCnu222WIAp2xn3DzH3LIsz2ubncciGxUTbQu0G/cOef9ZYPYk041u0Xf4Gh+WnD7WmSkC2EnGxCuGmfIZZ++VwM5kTGpXvdnx3mumuWajIxoH3GNOMWN2HjDUTD36cFOSiJm8SO/XumnWJSb/0Ik5iYX+Cjh7jCOBKyAiFB8x1Rx6+5NOuQN8ftt1Zusr85XbKxygj1oJOE0ClubH90vA5gnHGXPiuRsSeZHhbpVv8NWFbSNCAFcI8q1iChsf+714t9nw6N22BYLRc+80kcIi97y952Sdtv/YtsmkrPSBbslX+CpgexEcIZ1jYMOj88z6vyLgPFnetW6tMYWjxiv+Oee7XTjn+4T4ljUmnU7nxIV9tkBPODH7tsSFnfWO762223ji8ac17yPS2pByAf8tMEs4u5ylRMmRU03xkdPMwGNnmqqLrrLrcOVdn61UzmnvnO6e6yN0K+Pm/IWvZr341IPdeTvCkUe0w+Z1/oLk01uuNjUvP2Pnae8JR7IuVmhGFiVMcV7ERMP7N9QD/vymGVJe5rsb5yAG6r4t637O1cNG3UeLTd2/HW6a/5BZes40WzynqXNOdt5PcEOvPqNu0Tf4uiKLTh6hmStjT94Ro+SoaWbC3Y6FLTze3QgRyEn466aU2+Y3JIp8s8CKB982FYNK46FQqMWt8gX+biJ2ALNX2iZq2GkrnLJ7qG3ettq2ed9w0HgTi8XIpeyyj8jBLuymrhtnC0Ee8my7V7zO834hfOBIE4lEjKzP953E9xjYVgQ9RlVvMOseuUv8Xesx/LdtO3Zf5VvfOzj1fiFv7BEmHA776roefI2BC48fZutjAxGchL+tgmSLYzd2/jl1HLMPkM2Y6qKS/Y6BmUSBKb3jWVNZWfFaPBo5za32DT5boP3Xnjx5h1l5L7Zl5R1mn+NaIwUfkJk2yxQUFpq8cOhXbpWvyIELO6J0FeecY53Ut4udvXwZbQPryzvpmyYej+1W/FvtVvsKXwUsPW6WNHAE8NzQE4PUEYi8d8zZuK1Wa/RSY3ZoaPmRsP7uh4LTTzflB44w+fHYTSrVOZX+wtcY2JJOz7cyoTmSwS7z/Llu7Vrz/DUXmd2b1tl13UGWYhISrjwRNVWFcVMWj5r8aNhE9tEUM4OHmwFz7yP21eXH8qZrE/mve8hX+Cpge8iiEslkctKH77/3xsc3Xxm3mve4RzoHLhGXgEXaOEpjUaVhE1N5XwbKZ8OhK243QycclSkZUPgTif/HXH3tI6cCAkSsrat//OMFr8/Z9fAtxnQpYsgeEDtuXMQSY5HQPlmfJfFaLpxrqqZ+zZQOLHk4Hg7/VOLVuod9R84FBJZlVW2s3rJo/bJFVXlP3mF/2NMpNCKskI8yEQ7tejpILG/3t681g48+xlSWl9cmYtEz5boL3cM5QZ8ICCTihHUbNi3e9vmqAXnz7zGRrRvdI51jXwaXrqgyzedcbspGHmIqKisaE4n4jXmh0H2yvpx9oAT6TEAgEUdtq61bVlNdPbDlladM7MM3TbgHcbErYHWpKTNNeMZ5pqKiwhQVF+2Ox/LuiBpzv6xvi9ssZ+hTAYFELKpvbHyppmbrlJ3VG+OhD141+cvf6tqtOwDCNU08Rbcqs01p5VAzqKzMGlBYsD4aCd+pEPCMxNvmNs0p+lxAIBELUynrgrr6ugu27aid2NBQX2hWLjOR9Z8YU7POxDf/z23ZFs3DRptMZZVJDx9nzPhJpmhAsRk4aFCqpKh4ZSwWeVEB891oKLRUbpuTe76O0C8CAu3OIXFU0rKmJFtaRtftbDhhe+2O6Y1Ne+IZywqlkknaOI01ylgsbr9RiStNJBJWcXFR7YDCoi/j8egLCBcxZrmE2y7m5KVBZ+g3AT3IGvOVlKXTZlwmY41rTiaHp9LJYalkKpFOWQXakjPajTORvFhLNBptikSiLdIxGQ5FVur+ernOrZZoNUqblPr+vq879LuAQJbGnUuEe0alCFquu95hGtwg+7AecmRh25XfJJH4Qnmz2qYV55qV71d8JQRsD1dQ4I3PknCuPwcIECBAgAABAgQI0P9ofyPN76oGONlW8DMB7v6/dPP9DZ5U+IWn/V0NF9xk895vq9gg9uQbCMNEbtirxe4eAdGpyMmaXWJr/+0FfFrke8QMxPsMgW80UX5cfF/s85+UtsN4cZ6IaEwGMI888SPxQXGT2J2IvxR5dLxL5DGxK2BU54m8IntDbH1Jq0fMNrhc5PNTfmf2rviBuFY8VuSrVcvE3WJ/Ass5VXxRfEFkjP8SsaYLRV4sfCJ25y2IzkeFX4jdWWCp+H2RBVshtvbdXsCLxA/F58XPxPXip+JA8WTxbZFVqBIR+xfi10WslHf0TW4dLsb5XGiOeLHIxLBkzr1S5BjnjBGvEOeKZ4m8INggcpxrniPOEK8WsSrevE4UEe89kTGyyEyM38bxoxo+B2Ghp4tY2o/Fo0XGQDiinzNEFuNjcYJbZmzXiJeJo0SMiVDxA/FckevSdoloW7/30N4VMF8E3Cki0EHi9W76lLhIxLy/J9IW15oismqAyc8SGRAgPVQkFBAumGCJyNdY3xG/I35LLBQrxDNF+vqHyGe7Hb3vwxAqRVySWM0Y6ONGkdf6hCaud694oogoxPuxIq7P/Fjo74osxOsivyxFOPpcKvKWF6/EuIizNjoSkJU6X8QaISuPyyAUFjRVLBf58Qc/8CA2ckGEQlTiUJmIyxN4sUaug1gM9giRSWJ9DJi+/ikyuFdE3I9JDhEB7vWyiMAco0z/s0VvjJeKfPcFt8RLEP8bImN5SGScfxCJdVi5t7jZYKx/FzGKv4iEheNFBFwlYr18mRurb42BHQnIypwg4j6Q1WHwdI7ZIjCvzDFvOuIzV15sFoi8v2Ol6BcBcU9ciYsOFbHQw8U1Ij8UOUY8RPyR+Bvx1yLijRQPEAEui4uy6l7sKRYnid4YJ4tsHJyPe2G5zINFp55xEhbeEllQdvL2YFERivlwLeIjlsxcWDTcnhQPoN5GRwJiTTeLP3fJoFhFgi0nsnp0lP0yE2HpmP4YCG6DeMeJnIcL4KaHibgaA+V8JkK8ekR8wCXXvE6kDWDgbQYtIIrXFt4g3iISF1lc+oXkGSvgfDyItP3dB+AaXlvAdbOv2SE6EpAVwL1YMcimwWS9zhCEwXluwGBwN6yLAbB6WCECssHwn0CwoWCdBGLEpkxbb7LEnQUiMRA3YRGIt52BybJI3hgRlL6YNOB8SEjBBQEbHdYPvHb7jY4E7A5YEy5EDOL/JcCqThdxM4Rncuzc7Gi4GWIiOu7HLskxFokF4dvniM8mQ1/jRDYoYhqho7dgHIQVFpA4Rt+4+kxxsej8zqznQHDIWInZrXcvvRGQgRHs2aVuF3EhrIjAu1lEGE8wrILJYC1YCXENa/OCMJsDuxp93SreKBK/mCS7fm+BQI+JXJP4ept4ifimSDxv3UV7CNpze8c4uQXDm2y0jwVHidwnIUR2PGgPdjlWFUEQioGyS2F9gHsxgjgptx64I+0hAjJBLyTg+uzQ7Kxck0crSNhATGImLu+5NO3ph4VhgboC59M3GxzXxEtIsSbGhwGxodEnmxzHvQcFyswPj+HajI+wxBi5d+wqxAQIECBAgAABAgQIECBAzmDM/wFPYVwI1FDCtwAAAABJRU5ErkJggg=='
        img_str_photoviewer = 'iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAA3bSURBVHhe7Zx7rBxVHcd/M7OPe/feve/S3hYQYoH0BUYK8iqoLVj4QyUgPv6hERNISjUSFWKMxj9M/MMEJcZEBXxgxMQY1BASDMEIlAIxSguxtQXpg/K6pdxH797dnZ0Zv9/fOWd3uRQiyczWJvMr354zZ87M7Hz2+zvn7OwWySOPPPLII4888sgjjzzef3i2zCRufPDVV5443JycbUR6IS+h8FcSi8SJrSfio9CSB6F07aZ/rKVrN+I22lF4OI/rO9znyzmn9MmNlyxtbFw3fobnea/xlFlGJgCP1pLTz/n5Swc86dy0gJnbRgFoaEApsQWh7QaEO0bFExK2HtvVz7Yddx90y8YVcvOmFbuLxeJqniKrSB1gHMflyR/9p+4AdEPRur1pum4xAHfz6kS0c9u5kqCdU81xxpkqdx724zEoUJGf3bJG1p818sMgCL7KliwidYDX3X8g3nG4jnsyUBxI1hO4jkD0RgkR9YRgeCD7dENrO7NzjiSO5OylZbnpiklZMliQQ1M1+ekjh2VqpoW+6G378Rim+PqVw/KTrefGcGHAU2YR+lrTiiRJ+vZMNTw/iiRoQSyt/KglhSjWdt/uMyUAsmS77eu1Wtpu9rVse0tWDIjc/aXVsmnthKxaMSgbVo3KXVtWypmjnvZrH4P+vNaLB2YF46CPrLjYvsTUI1WAjLljoYVnb17BGEimbiC5/a6usscV6E7brw212ZTbrjldRgZK4vvwm0eJVMq+XH/RhAQhrsv+PKeFPj/XsK9Kzrdl6pE2wL42HJYtgrE3pZDMPrar65i+CpY33OnjKwykcEgYbEO/ZgNpG0i9GUqI9gj94HhmrSypAmZYV3DmHOgfGvA2fm/L1CNtgE0DjPBQss4bUmDGFc6Fus1+qOtNE5QFGtCBCoN90Q9AvVYoB197SxqNEBBb0gCgJhTh2NePzAuooo87tz0vx1SE7/uvayWDSHsMLBhoRgXnML0ZQkLJbb1BC0tLwsREAAja38HlMYSLsoBVz31/fl6mpufUhXWkdIh+M7Pzct8f/qH72ZfpH4BbAZMKy6wj1VkYACdWffOZKbNGMyf3cPO6JMGyQpcX2NZ25l571sQ+DmgA4BbZGObsWs/0jeHEqD4rw4Vp2XLteTIxVpE34LwHHt4rr08XpViqwmnEZq7L8/moPXTPVVIoFNiUSaR6Yq4B193+FNaA2OAnBZQKivDARQcsrKg91N3aT+GhnsClnbUdxjdCRG8uT8z52B8pWz8mUTiP/hgn/aIUSoOAN4A64fGPOcal1oP3Zgsw1RTGWNNw6aupaetcUvhYw2m7nVg0NXW7hZGzqbOsNOpQTZJ6DeWCeFTYwNjWlCIAFiSQvr6qVCpLZLA6KQODS6W/PCQlgvR8yJMiyiLKwNazjtSv0AFEOBaeHdfeDs4sTXSCwAzLWVQacFZtRvx+OLEvlBjb0lwAeDOJFOBUQiwXylC/lIKSFOG8AI6j/woJwLm6KvtI3drnb31U1xaaurZspzLEdNU6UpRpqILDYDHpv2ylVK44V6RUlKiVSOvIrDT/vk+Sx/agqSJBUMTaryCFAGhwisDH+8/z47oufXUsxT4dQ1Hef8/GkyeFGe2ZFS7TTx7Ocbb0sYZTR4ZIW6cglPGtV8ng5gskATxkuwJMqgPibzhPki0bJfbRD7B1KICIJAA8TV2go9tYuhmYbmSZdaQPkJCYroSk4Mxyhh/FFCgdg3T0MSEwNf1CS8a2XSP+8nGAw2wLcBGGgRh9CTFi28So1K/bILGHlI8gAqQDVQaiGfscTKuTcgxsu86MfVrHrBvo+ISSazrOxEhbvxjJ8LarDTwLjsBaLN12aOqtsRGZ/uSl0gJEOlHwJgQ4T4nQCBHAnPs4iXBCYT3rSB8g3YYb4s3QEWZQRzsGJu7zYyyYcfP48CrVbZvFnxw3oCy8GGU3TMJjG+vN0RGZuvoiCaUBBzOd8c7Q4YTIWRdjIkt9ozSFs4/UATK13PhThAFY+uoQTCBIWw8AE8AbgPM8wOukbad04rZLZbMvksbIiLy86UIDUcdEDBd8TIZJiR/d9Lq4LXVh+rf3jkgfoILDi4d8BckbM+OhIG0TTAYVOC/QtO04r+1CBcUx0LURomvjWhtOHB+R/RsvkCYh0tEcE3EdAw2vgW+cdWLWkT5A+8KNE5nKdB5SDQtipm3/lzeLB3gE01JYzmmmzocDHaDcNvWwVpe53XtldsczMr/jaZl/7RXZt+5UqSdYbMOJHh86qNOZviaFCTTryMSBmsLqQC5n8EmDziu2pLTtEyZtFZwZ60yKOli2zW3bfrU3p+XAI0/J9CvHJAxGJaksw9JnSKLSsBw89yxpRAtmLQmQ7WUMHMky60gdIMa9xMy2TFumF8Y8LFUKt15lnWeAdaeoA7W4JNzaEcB7Ypc0i0PS6h+TsDwsUbkqYXFAQnwaaYyMyf71q6WR1BUir8fJpeQHmgVZR+oAzQysK2FNLcILbr1SxKatE5cqHM/UjTZt3WzL/QRM5x3cvkviYlW8gVFpAVgTA0QTDm/GvoQoG7EntaGq7P/IWrQ3FKLPrwC5FrWvKcvIIIVxUkwYhBdjnZds3SSJpi2dZZynIrgQILvTVuFZ5705I/sf34lPJlXxAc8r9uPdATScv4F+Id4oLBG13sT7NV+tyosXr8W0YiDihDomZh2pA0zCKOFjp7gAgIBH57UnCFXcXigTlIJ021bzTNvHnwW8IfEHx/DZuKzw9HsQ/EEXhdak0VgnSLj52NCA7Lt4tdRjTCwJMgDKOtJPYQm9yG9IhLRNJscMHJei7VQFNNZZtmGatJ7nhPHETonhPG9gBJYuY8II+KhMv0Ti8wOCpAObXNJYeHQjNTc0KP++bI0sxHWck37NNlIHKFFdQsCLl49Z5wEQUpUpqssW1HW2dfssRMJbALxDGPPoPI55XsmkLb+FY3j8No71RRBxijbMJupzw4Oy+3I4MazpcVlG6gCbH1oh0fJRCwdyzqPLdNumrf2Myz6ESXicbSNMGP7gqPjlivjqPEBj6qr7DEBXerAjk5Tw8L6Y0jpxtjooB89eZl5UhpE6wOLHVh9VKARGeAqSoIzY3n5YQBcCKMe8g4CnaVsZEb/Uh1dmoGk4eHabQLmN/zRwKnVfC7NyaJ3IyeXIsnHTIcNIHeCy00b3qsMcKNyIKU29PQYqZKbtjBx68jksiuE8woPzEg/jHelYcDr+BQTYcZ8+NeV+pDjLFtK5gWs0MLnozAyQ09UB86IyjNQBVuO4ZsY4usw4zaSscWNLU9cAVedtB7zCgDpPxzxCIiycS9MU256XsNluaxcF15lYDHCXzgoQ1yzjPAm/fc8wUgd4esmvmfTEUkzX02aMUwcSJh0I1Y7M6GwbFQfthMG0NSAUmoNFg6HOMO4zALVNvyvADrObT/cFqyjAi3WZc+YwPsyxc4aROsAbRvxvGcdZp7EkNIVq0pbOY9rGXOdVMGHAeR4+ejloBNKBaERXvr3dAtU2c20G7cYJpY5r3XHhMJue5V9ZRfopXPZ33TjhtdR1gKfPPC1EOlA/2243zvOxzvPKgIfZllDc+KZfiuOVsXSwFGLXfg3ud/WuoBO/cv6wrBov8gulD9vmTOKdV08pdk83ojtfavp7ZiKZXoikNnVUZg5PyZsvvCpJ37CBh7RVeAoCB0EdV1lYkHGe2Wf6MNXNdbpjuBzImomifG39kFyyvMx+N0H32t2ZBF5OdhHH8booinYCRqbXWRyYN5pwXgWXxUiYRx555JFHHnnkkUceeeSRRx5vi15895xmXAJ9AXoBmmdDV1wIfQY6CM2xoRfRqw/566HboQndMrET+gt0A/QBNhwn7oN+AzV1S+QWaCvEY3azoSu2QDdb7WJDLyL154HvEqMQn27+GuK/3X0IOg2ahr4P/QLiE/lfQtz/HegwtATq6ZOc9xu9Asjgl7T7ID4h3g/xW+8FaA9UtW1PQty/F2L/o5Bz3/9l9GoM/CDEMYqAOEatgfhP8bdDV0Kfhv4EnQp9EdoM0bV06gHIBYcC9me/KyD2c/o4dA60HNpg26gXIb4RmUSv0oM3fRdUh5i2TM1XIcLhP4b+NvQwNAmtgBi8aU4W3T8v4Bh4G/Q9qBvsewUdzWtmEr0E+HXofuifdvsiiGPfp6CVEMc892MWZsZS6AGIfdy/nH6vSeSExIkeAwntLYj7fgx91+oHEB3GNM4nkf8hOJm8DBEsdQiahfgt5eLgbH4HdOe76CZoBOpJnOgx8BvQ56HPQnSjS1X+TvMM6B6Iyxwex+BakpPF3dAUG7qiAjG96exbIb4hmUevZuFToDHoV9BvITqM35g9DXGsm4EI+I8QJ5O/QYTJNOaCm30J9TqIKc/z/AtyjqX4fym6FCJIzt50cObRK4AExBsiFI6BLN+Anoeeg+hGrvf4CYJO5K+COAPvgNxHNi6FCPBRiOdY/PPTMsRlS08B9moMJJDrIa7jGGdBTFtCoaO4duMMuwpiME0/B/H3aRwHSxDXdgT/DORS+oRHrwDy5pmqXDjTUXQeB/qPQoSzeJv9+OvIayHCP9PW/wpxYXy8yeWERK9SmDMj044PD+ieYxBTjQ8XmLZM5+5tjpEEfTbE9d7lEJc6v4M4HBwvOEauhXj+x6DFT2tO6qCbuPxwsz7LIYizMW988TajH+LkQ0dyAqLeK2O4j28Aj+mVMfLII4888sgjjzxOzhD5LzPZ7D/By1tOAAAAAElFTkSuQmCC'
        img_str_notepad     = 'iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAplSURBVHhe7ZwLcFxVGcfPptndEPJoeAgqAkJRqOITaGuKLdQSLNixIyCjgmO14qijZdTKdCwawWqZDoI4VaztFHSAio9aSgmYEamiba10CIamtNjaF6WkaTebd7ZZ///z2PvYR6bNvUdd7n/zy7nfuefu3e+733ncTXZFpEiRIkWKFClSpOPSsg3PL9z52pHHtJnTnS2b7t5+8PCftOnR4ic3L20/0LlDmzmt3rJ93ouvdG7VZvnrUw+0/D4+/77sabfdnx0eHu7S1WLxU5vvMPWZTGajrpZatXHb513HpHW1+PerR8931b+oq62pQpeha2/vyKQ7X+rpXbKz99DqrTtmsy41MCS+s7O/oeVg/5JVe3rWfnv9pm+Z+oUd6Umbjwx+Zvmu7pb21PCseY+03m/2LWhP1Tx9qPfWjZ39cy/4wYMyI1l/a1vXResP9Nx+17bD7amhzFdYH7asBPCh/QOty/f1bRzMiup0ZuT0ZCKh9wgxks2KZw4PLehIZz6STMR1rRBZ1P9qb+/KjvRw04rd3Y8nXPt4zJp9fXc/tCe9Il6ZiOlqecy6/T3Nu9JDE5tf6LwXWbxQ7wpNoQcQTsW39WRm0DnDjbObBIN49fRG2AiIyCIoQlw/6yrUx8XMy6dIW7VX5ZyrZwgG8crGSdJmEFnOvuoKkYjHxbQpl+r2AI/ezAhP/z35IkJU7uqFJThUs2h7Txp+0YItf+dK+SOdVqVsVcJWVapkrW6Sa8MK03bZJWeIysrKUH200YX7lOMqa0zmuOvkQ5dqvw4I8B6jgiazkw9Xu0LtbSj0AMZisREnAMZJ47gqacs26HXKNkFw2vmfw43T3ltnQ1YmEfrCcY5lSadlG6DLQkFxb0vbHJMLshN0G7IUQDiENMs57aK4rY5zjjG2EyCPbYKO0jyHDVkJoHTIZErOQScQhWznGFPvoNp77VwdImrqbCj0WZj6eluXcocOyiIrHln7hOjsOsraMathfL24ZuZ0Pj3EAMrfYuWUs8piFpYB82dKUMGjjhxN5Z+DfduC7HVhF7RPbRiv945dDfV1+eeQuR6+rHTh+Vs76Rb7lexaMHKl3KKtDFlyq6SNTdaqKmP72qB8cOrZZdKFpZOu7lUIPOQ+3RY/ee2VbZ5Plc6s7LQx2zZkpwvrmdHrpHLcCYC2sZh2B4H17vayjS7dtrvO2DZkLQM9maMd9TssbdkGti7dbfx23jG551alDVkZA7+05aD0xzjF8ndPtIouzJ5BqB6TyIemNSKM3nM8PP288lrG8CGzBo+ggkelUt2eDDVDhg1ZWsaYIKqS9ilY/Aal+rpa/fz6HPJC6Z0hy0oXvmXTAfhGtyBdemztNEu5JW3VRtawjan3tFGl21Y/yn50xoQy68IgfzJwHGZJ29MdNfhRdbKNKk0bN057HGBBlrowHTKBLLwskXWInrvObBe0fW3Vfu85bMhaBhZaluQFxbTRpcxO9/7cNurx8GSvZ7/ChqyMgXOf3SP9Mc5ya33rM+IoZs8gVFdbK6Y2XiafWwaPlSjXNF1YHmOgJ1PwoB1U8KjudNqbnfjFc9iQvS5sHIRnLMdj8RuUamtrZODkOeSFUqUNWenCN2/YrVxidtAxXUpb+unsK2njlzJVWcxmyY11syaWSxeGY/RJlx4bD9q5DPVte2w+aOvSvd97DM6BNjZkvwtr8p32ovZ5g55rr9+xkWOrrDPnMLbChqwFUDnoCoIHtMFDBkBmlwmIv73OXtlGlf7ncx9jQ1YCmIjFtIMmMCaovsziNnYWCkpBG22N7bRRz52ssDK82wngDSelEESTXY7TZttj6zbOOOcE3X2MtGUb87zO/ip49emaHn32cGXlMrW1tWVTKfWXsxG+5ewS6wrJXe9vU2pfRUWFGDduHGdfMXny5NBnYSsB3L2jI1uRrPYEr1gQSgWn1D4jBjDGIWO4X5w7oUzuRB5uvikTOzYkqqqqRDKZlPi3jV1se7R9JJFIiHg8LmLHBsWvv3uzPnu4spKBS5uqRwaGsrEiSROokHyiEmlRn4yJeWu7y6MLr/7kmdnBXt6v6ooQxcmXJKtrxZwH9pVHADtffm7gz83XJof6gnsDoZjoUOLkOnH5onWi7pyLs+jSoQ5TVgJI8eMMGNwbtJknOfAH28ezmI1r8Lx92o4UKVKkSJEiRYoUKTCN0+X/qt4E5oFecBh43wsbXeb4TsD/ag/8ZjKo25xzwMdAtbSC05ngs+BCUMmK45Q5/lwQyi1dULdyHwTfAGvBLwBv2T4H3gIKneMkUAt+DDaDr4E3Ar9OBVeAf4A94Bjwazl4DmSk5dX7AF/PfPA0KNRmTAoqgPwr+cfBNYAv+A+gCjifkvbqAnAboPNrwGngLMALwawxOgNcC/4CdgITwH6wCfAj/odAE3gz8GcZL+BN4LfgJeAfAl4BreCEP7QSVFrzbRa+yL2AWUNH6dj+IrwKhgHFtrQ5Hs8AHK8YHPICYLAYvL/rOnIZYMB4Du7nMQeA+xz8XoVLAC/CTDAA3PvJa2BMWRn0uzEctOnQaAP2ReAusAr8hhXQZLAEMEvMF1Hw0ziXAmYas8VkEMdEdn8ez/P5xfGSY/JcwGD/DfwUPAUYyMAUxCx8OmDXexfg/+3uA3yRzJCpgPUMmJv3gvcD0w0pTkDkl4DZzK71L9AIfg5WgCcB65m17WCX3vZrEpgF2gCHC16k8wAvArM2MAURQAaNGcHuwhfNrsauMR3cAvh+HLORE4eBY97bADODAXwDuA5wzHoreA/gBMDsezdgRnGmN/UcJpjlHcDfBc8HXwDPa/iaHgVsx+faDgJ7jzCIAPIPsP8EHA7o3AbAMe1iwKu/DDBrOFMatoBnAY8zAWbJsY6DPUvC9R+7dgvgl/HQedYzgzm28VzuLsnzLQXMNGYyvx5kDuAX/PB4TkjsARxbA+nKob7dXUIMFp3g4M+ZegLgxeR45mYQcNwbAjzG1HMCYhZyGGAgOeNPA7cDXgB+x8xB4B6Hj4D7ALsyMzSQteF/K4BuJQG7KgPghwE6GUwEHGdNPbs5uzvHWC5/PgG+CLgK+AkoNja+DJihXHZ9FbwTjElBzsJcKvDKNgMO3pwFOa4xK/K+7wqi4x8F7J6ceAq9Fo55KwG//2UdYEZSXLRz8loMmH0sudheD24EzDLqFPABwH0mI/kdWxxSuG59O1gAGNgTUhgBvAfw6nP5MAXw65wKBZBj2/fBIsAAfhNwMnGr2DKGjv8V0HkGlcsnDgfs5pycagDFbV7QHwIGka+LXXk34OTH4xg8O/9IM4o+DP4IfgSYffzXAN5lvAP4xVmVdwiPA+5nN+aYxEnADTOYSxleGHZjU883CHiPy+5dSpzUuNzhxT2Re+lRFVQGcmnCJQuzhYtb3t/y6t4BOJMye9zixHE2YLufAfcH5zg+8T6a2cg25MuAw4LJQJ6Pr50TSqkF+//NvbBZp3F2ZHeko5xVObsWepOAMsuW3NffaXHpwbHPvLPDrskhwIx/xyN2ZS5beJ5Q3s6KFClSpEiRIkWK9HqUEP8B3rZh+IVmlOgAAAAASUVORK5CYII='
        img_str_bluetooth   = 'iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADnIAAA5yAesn900AABS5SURBVHhe7VwHlBR1nv4qdJ7EBHoAwTAGFFQQFROLDmbEBIjgue7bu6fPVRfTHusZ9gwHeMZzTbeu3prRVXA93SeKERU9XEXAtBiJDsMMM8PMdKpw31fds8fzcb4LVLN7N7+Zb6q7uvpf1V/9wvf7V/Wg3/pth5pRWu5w830Y9z3x1rHPvbty7Kq1G8181kQMsCO+Z+ZdMw/TQ21tHAftPzg7fcL+L4wdPXJZ6a071HY4gTNm3jYq61ac+dWaLaeZycQueTsazbomCY3A8gCLR+j5HgzDgG26SEZyMDNdHTUD4i277lZ//7h9h86ffuIRX5SGK7vtMALn3jd/7+ffXn1Jd86a0ZuvSFlGElkjxwNyYPkWsrleWBHAjCTg84eP4DtceB4s2+LCgW1nUJfMrdu/qeHue/7ur24myflg8DLaDiFwv0mzmv1k+vFcpG5g3jFh8zBcz4Vr52B7Nuy8j913qUPr5nX4ti2PSEUNaTVgeD5MeqNLt7RcG6bjw+UrlRUu0innpZOOGHL2xTNOaSntpixmlpZlswNPuWFS1hr6TLdRNzBbyDH55RiiDnyGp+nRy9wYensyOOzAobjqwuNQF+lBvqsDTIUMY1Etf8wHnqpnMSuOrt4E1rQlj1n4+tcL5s+fX1faVVmsrAQeNu3icT1W9BE33lDpevQi7t5mnjMERqlBkoJQNVwUMptx8gFNuPaiyaiN9MLLtPF1EkcPtD2LSxteENo5RI0CXNfCmvbEoQ++8u0zH3y1uSbYYRmsbASufPXJCsQaf5OPDahykIXNsmt7EfqQwEziB3/pZQX+LTBURQ5w8vjhuO7SU0liB5xsp3yO4RsjeYBjgyHMAqMANx30ukls6Kw44veL/vCI7/vxYICQrWwEnnf3qss7sundPC9BclyGHwkiaZ5+6IJGcCii0OV6j9uU0rPr4pQj9sE1F56OataIfA8VjREl0fRGwjcifEccrjaPmGjZnMPyzzdNfGPFN5OLA4RrZSHw7Fm3DyuYVec6VhIuc53yGFhpRZr8LAhFk2sNh2SSVJZfs3RocsSCV8CU8fvhuosmotpuQ29uM9/Ld8sNuYFOgk/P9VnF7WScBLZi6Yq1s8vhhWUhcN23mUkZo3aQ6xQoUShPfKqNUr4z+eGVzQyXbPjKf6yyZCZfOjKDj+WnCtVTm0fi8guPRtxfj2ymFwUjFlTnYCSRqWeGSYItvLviy6Fft3efprVhWhkIHBPJGVU/zBT4QRmW0ng+P6RI8kQOHwcVNiBC25BH/uT5mpY+lzbDVOSyZmP60WNw7YUnI4kuZPNZeiw/Al8zlUsVx5I60RRWtxeMFxd/dGLxGMKz0Amcc/cVQ1s2Z0cbpkKWAtiPkRzmrQjzmdONQpbC2Ywyh5Ewkmu5UUJVtiifPZLek/PAX3oqPdLJYMYxB+LqCyYi5bfDKWThcGzfsEg0t2B+BYX2uo3d2NCyqZlhPDw4kJAsdAI//ab1h8lkdcRgHvNYXQvco8t8Vyh0YUAih3SVgUxvO/OeG3imQW+yXWo8eZI8kgVjY2cn7n3kGbR2s3qrC3FyOPvY/fH35x+LpN+KXL4zCH2fxYdvCcwpuGhpyw3+/NvuQcU14VjoBL7/6fomX+FlkkArE+Q0rzePGorh6396HO76xYloGlhAprOHrzPX2V0w7F4emORMkQ87HsOCF9/HNbc/hY4sSbXoaWzpzj52NK4+rxlVXitcShzPyjMtyHNNxKIxfLmmFa8uWZ4KBgrJQifQMxPRLEOzoOoq8pwe1Ccc/MOlZ2DSwXtizO6DcMsVZ2LPQT56u1u5TQSOz/6Xod5ntiYSqurwxKKPcdVdz2FDB3Mf1/sU1uccNxZXnnsCklYOedcvFhWyblkxtHUVUFVZOaM4SjgWKoGL3v5gSG193eiMwxrKD2WyezAcD8mohcGNldyC3kLPOWD3wbhp1lQ0NbjIdtEDkeIr/0GgCJHXRVJp/PbZpXh58VKYJuu3WhjW5yknHoSR++yJbC/zH7dVq8dKgu6cgZZNXaOLo4RjoRL42LPvDuvNeU0KW1VX0zEQtyuwblMWfzv7MSz7hu1ZvBpuoYBD9hiMW2dNx671zI9dm4pSp2QuC4nJnOZ0tWLyiYeiefzBLC4+K7gEkIX7nlqCD1auRjwukV5gmhCRTAKejbXrW0ujhGOhEvjeZxsSPTn6AtkzSILBSumQSDs5AB+vK+DSufPw4RqSFaFMcbI4dM+huHHWGdiplpW1t600ikLVQ7ajBVOO2g3XzzweA6upj7lO8zgPvbAUdzz4GnJ+ClHLJJ3aXnmQ+ZD7am3viLISVxRH2v4WKoEdmbxBx6FXyFtcShXV1Qj7YKCycgBWftWNy+fOxydru1QpSGIO4/YehBt+Pg07DYyTIwkZIJvNYmLz3ph92TTUxW1YrOiGZeHBhcsx556X4Rg1iEdZqNT++TwZ+ljsahyXhciyB5HAMcFAIVioBFqWaZC6oCq63JPyIOuBXIR/mAtrBmL5V5346Q2PYuXqdpLIzsLNovmwfTDl5CO5mcPNfNRWV+GCH09Fulo6j/2vGcPDL32MufcuRNasQjRBHcmqHbSBSoKESTmkh/TTRJeHnXQ8YVioBDbWDoirU3AZuq4+nLSaIDL5usR1sroBy77uwsUM58/WtVEDx+lJLqpSMcoZaUMXlTEbKYanrylptm8PLfoIN9z5HDJ+JaxYPOivfZ4qX2dHv3Rcg57I2s19RtDa6aWLR7T9LVQC0w1VlbqWEUhihTFpY0QHoawkr9ymrFVVk2Y4d+Ly2b/Fp2s7EDPicOiunto+/oAhS3bovSk8vmg55v7yOWSNBLmMFtezWEiA67RoaiEwrg8eqVrLZUOyUAlMxWMJyQ1NX1lE3xyfqJSr2AxlS10H9VtlVRpvf57BrBufwIovNiBCz1G+NOm9HCIg4/EXP8R1d76ErJdCIhGDZeQ5rqb3Yxxb5aPosfLEPyHIv57OWygWKoEaPfgAeqiwCnyx+Fg0mvJEEhDkSIZbrD6Nt5Z9iucXLgmuxsn/qLxJYJR9bRd+9fACbMoVEKuoobTRzA1JU2FS6GrbrYzDauf8JfV+qa0JwUIlkB2EJp6ZhyR65SGajfEJzbCw6JIER1NShNRyrn09TjhqFM6aeiw/uJxGpPB9JLExXYML/vp01KcoaTLsfZEgicmAGcfMsYPR9gznwBO15F8RqxNomrqeF4qFSmDUNuPKc4EjKecVXZKUMMwYVR6LiBOQ6yDXsR7H75/GnEunYWhDBVsyh7mS0ofjCBa3mXLkfrjhotNYUDYj39tBmvheEu9ZDsdm/eUJ0bqiaW8+NAdp+Eqi4VioBPLMu0Uho+SuKln0KVnf0gRFc8dqHDkyjZt+RhFdE0fBz9IhI0He81RdSZJJ+IUMJo/fG9dePAWV5ia4mY3BFRXLY57k4EFqkMtrIY+U99GT4zHuJCQLlcB1LW0bgwxH6WLI67jOl9fJN+h5lq6mda3DuH0bMZcdyOC6GFwvx9CLon1zD9s3iwRZFNIFdPRkYESigedOHTecJE5GldkGt7udBEaLBHIfShHFSX56JT04ylxRnzS3FI9o+1uoBK5Z17FFQkUNhTyRj4L1Dsuqy+eZtrUYtw/D9mfTMaQ+yZymyVVNXb2HeQteZhPBw2Me29TVg9n3PIk/tvQE2hFeHlOPHImrLjwdSaODBPfAYdWRnwcnLCCRoc/Ul7CNPMVOd7DjECxUAguu40QUekHsFnOSIizCn3xbG34wcgjmXnEWdknHkGfYWoaNhf/2Fa69eR42dTNtqZLSIpEYlrz/Ba6YMw9r23L0YpNhnsOZE0bhFzMnk8R2ttJZrqcHK+RFn1o65sSoFZH3rSuOtP0tVALrKpN+1CwWEZNh5rOfU2HM9bTi0JGNuPHnMzCsPkLP6w7E84vLvsYvbn+aUoWBW1EZeJHMpHelahrx6ntrcOXNT2LV+s5APFNtY9qEEbhm5iTUJlzk3V56IukjweqLY5Q/lVXVbazGn5aG2u4WKoGjhg/1KzVHoJ5Wd1v5UeSz3Rg2NIUbrj4LOzckGGcZel4VXlm2Glf94xNYu4XbVdezOhfHEInyWs+LI5pqwCvvLsUHH/2RLR9DWVfyGLiTmkdizz0akc338JluPJJcAmJWBOmBdewiWcJDslAJPHfq+PXVCXeTy+MPZIY+HpN6Z1cnlq8sOYVVgcUrWnDNTQuwsYskVQ0k4brpQxehilFsSQKxjrqZNpz/N5Nw0vgxJKmHOslH3jNxz78swrIPVyEZr6RnBjeM0NtdpOike+ySljAMzUIlcN+9Bn/W1dn+RizOzyCtZmQRsW1s6Y5izq2/w9NvrsKijzZi1i1PYk2nTw+rg8cPLqFtaeqmZH6edTvbgvOnH4GZM44hMSxNLCYZSp1bH3oN9z7+DnyrOsihUu6mNKaTQ311DEPSlV+XhgnFQiWQoePXVVd0J0iabiZSt6GZ5EisFt3OQFx3x0u4bO58fNPJ6luTYthyKSnCsq3U2WeSLj8643Bc9uMJSPrSxBZyfhy3PPQ67npyMfzKQcwQ6oelBVWJKcPzW9A0rAYD66t/XRwlHAuVQFnz2L0/tPMZkkASQUGhzoMeZsRT6CjE0d4dQyRex0KiWzPyRTHM7aQXA6MQrh1QgWmnT0AlOz7pR11Xvu3B1/DPj70JJAaxTOsFG4Yb4fu5ZKUyzTxG75tGOmV+WxwoHAudwD2GD3msykZe01lu0F0oR9G9zALsuMFiEIXtCuwp2C/Lf3SDgUNvLZrHsGdvy4LBvoaeZ+Hmh17B3fNehpmsRzSaZN5j1xHM1nIpcc7OraGhBkMG1b7PAUKrwLLQCZx48IhNO6crn7M1kxyUVM0qS+6qMOYpnOl1JMfy6EUetRu9x6MA1p2nReMh6kIRy6pDp7xr3hu499F3gOSQYDLVcAuIUIDbEuqWrsblkGOlHz1iL4wasesS0zRDvaoUOoGSEGOaBjzQWMHsV5DElRZUgmNlJWnBJAMLjEgrzjpRgpApu6+IaDqL5BTouf/01Nu46/E3WbjrYJM8X5Ooen9Qq+WFMTpgHEmSf8jIBqcxatxfHCQ8C51A2SXnTXx5p7S3OGJ1Mv/r9g56o2SNpt2pDYMJAxYQUocCZYmEsOYRFb46QtdI4q75S3HH/Yv5PA07GmXY8mFwpyo91vJYkfOEh96eTow/eDdMOHjXp+l9HxSPIDwrC4H0wuwJzcNnD67uQSHbQcLYtZJI5St5jmaOg9lnFhcz0Lwul/IqZksjhnsWvI/bf/MGjEgj4uwuWHG4vQ5dd3jleUJYdSO6GaQbFZW9OPXYURt3rq28jhuEbmUhUHbOCeMXHj5il7t3qorBz0lU08tIlkciA8Wi6xr8sRl+umzJ5Bisv+/pP+C2Xy9EwR4AK848SW8LRLZmpJnzHIs9sKb9cxy3sxPnzWjGhLFNN9H7PtawYVvZCJTNmTl59tTxoz6ri5pwdMWdcsVT0x/kMQW1QjNGEiMkJ4X7Fn2Mmx9YCDdaixjJE9mOrs6RaIV9cJ2ZHkp9DrRvxk8odaZN2PexhGHcUdxj+NanFcpmnuftdeujb87711dXjFrdwsIRrYdpkwhWz+L9gZog7UV9fRTtXR3IZJOUeSmSqzuvVGjAbkMzPFEUKGsKvZ2ojvTiJ2eOx/STDpxXV2mcHWbv+10rO4Eyktgw//WVN7305kfnLPtkMzZszjO/Rdgns5ugh0k8664CeWUkkgrCNTBL67NwczmgkEeC0uawA5pwUvM+3Sf/YPgDtmFcTvKUWMtmO4TAPlu7xTnz9cXLp77/8ZrTVnzxrdGZYRlg3+vRu/S9D/XFRnBfDWUNyWUtQiKex4AKG3sNbcTYEcO2HD1+zGPpJB5kzltSGrastkMJlFGusEnx91jy6Tdj1rbnTvpk1bqGDRs6jK6uHrbQRjULDbWylYnHU93pdJW7V1ODP7wpveHAXdMPUld/SeK+Kg21Q2yHE/h9RmKTIpiWIYJi3W/91m/91m/91m/91m/bxUK95Pc9NpiYQOhW/F6toFUTzYSmBnQrRnB1pN+2bUcR7xAHBc+Ktgfxe+IYQrfa/0VYOToRfUfjR8TJRB8xA4jdic+ILq2gJYm9iG+IDkKdh/AKsZqYQlQR/x3TfTG3E28SofxLlHIQqDTRSNQTffsbQeg7bA8Q+qc5+mb5gcQpxKPECkL3VSqMRabCeiCh7XYh2kvYOsy1/lriuRIyhMZYQ3QSf/EpoYE4idB3NvRYXqkvwMgrRd6zxFmEvOw/O7EK80eIiYStFVuZvhesGZnziVC/obm1lXNGWh5yCbEPoXCdRBxOyKv0hUBB63Qt41biNmIucQQRJWTjCBGsi+V/FpML5SRQHqN8KI/TfvU4RugL0YcQvyLuJZ4hflfC88SXhEJRphDXvX4Ky/93BG7LtH+Fr5YiTN8oklduJlSlFxPrCRGoAiP5I9mjAjTqO1AIy7OVIvYtrduP0HtCk2vl1IFDieOJ1wndLaB8uJHQB19JvEyoUio/Hk3IO1WR+6bo5akKX5E9jND7hLHEuaXlzoQ8U5pyT0I5U+9fS4RynaScE6oiYDzxLqEKKtEsAvVhJWc0s6zjUQHYv/R4KaFqKlPoJ4ito0a58UxCovwtYjrxMDGP6BPo+mcfquKhVOFyEii7nlC++24F3Za9R6iYbAiebdt0EmYSypvLiTuJh0roIUK3cudA5a6PiKuJBYTCVddw5xAKWf1XyqsICV9Vba3blun/BcjbLiReIKT7ykLYd63cBCo/SYLIW1RdFZ6fELqLQF2DCoZE9PflLBWa8whpQVXpp4lNxA6xchP4vzXlRnUbqrK68+pJQgWpL7/pBCn3/VlInO1l0nsKtRcJeZ9aN8kTeaFaLBWVtwkVlr7XVFT0nyhVGK4kVGgU9ioqEtcS4989+ZqE0OsS433CO3QrRxHZVi/8XzV5lqTNwYQquKqr7joV2fIy5csmQiaSVxG/JCS2y9L7lrsK/09Mnqb/SKmColy39a0bkkZbFxrNI0qE93Uu/dZv/dZv/dZv/fZ/1IB/B+F3QVmxUOzRAAAAAElFTkSuQmCC'
        img_str_uts2        = 'iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAwGSURBVHhe7ZwLcBXVHcb/Nzch4RESHgKiBpCCrahAOxXFEVsR0DpFC7ZlSlsKpbVW+pjadqqdoePIMHamdihTpU6hzBRbadHasUNRkSpVIpSqIEgEHDAlPAIJQnhFknu33+/cu5mby70JFzcJkf1mvtm9u5uz53zn/zhn92wsRIgQIUKECPFRwsqVK09MnDjR69atm6efHcZIJOINGDDAu/fee73du3ev0LHzH6tWraobNGhQxgZ1FBFy1KhRXnl5edzzvIiOBYZAC4vH4/0mTZpUvXr1ahs6dKjNnDnTZAGmBiSvaF+oPrZhwwZbsWKF1dXV2ZQpU2z58uUHCwoK+icv+dAIWsAxPXr0WH/y5EmbN2+ezZ4927p27Zo82zHYt2+f68j169dbSUmJ1dbWWn5+fmDtzktuA4Es7WLEA1ge4kWj0Q5lnz59rHv37q5OR48eddsgEbQF3pCXl/cq+0uWLLG77rrLNSIV9fX1dvz4cbdfXFzs3OzEiROm2OSOBQFCBsKxPXXqlE2bNs3WrFnjzjU2NgZqgYEKGIvF5kmwn7OfTUAasnDhQissLDRlRyfe0qVLzbfcIKAw4srUKKDNBQwUqtzr2rjMJwE9uYwna2vGxx9/3FMQ93r27Ompkd6CBQs8WWKzrPlhWVpa6u3fv9/d79ChQ9748eObzqmObANDoD3R0NBQLXH6sZ/NAl977TVbtmyZdenSxaZPn+4s5Omnn3auHRSwvPnz57sY3KlcWALWS8BC9rMJSMyTq7v4pHjZdCzoGCiR3H5bCxhoFhYKktusQDSJ7BrIPmSfY0HRF689ELQFxtQA1ympFogVbNu2zVlaLrj88svd2G3Xrl05DUG458iRI5vu3ZlcOC4BXZmpAr777rs2Y8aMnOPcQw89ZGPHjrW5c+faunXrkkdbB8Mjzcfd+K+tBQwUqhwm5rJdahbWdOqcHiwsXrzYq6ys9Hgwkel8NnbmLHxSFujmbqkWuHfvXnv44Yft9OnT7rqzxaxZs2zEiBFuTLd169bk0dbRabOwsuujEuy77GfLwu2NTpWFNXx4J7l7wSBQC1SW/ZqGJX9kP9UCjx075p6GMP4LEqNHj3ZuStmMI4cNG+Yydyo6lQtLwFsl4Cr2UwXcvn273XHHHa4xQULTQisrK3NlI+B9991n99xzT/JsAp3NhcuSu81ApQ8fPuyexQVJkhJW7f8OuoPOBoFaoBrzhCxuOvupFnjgwAFbtGgRWdpdFxSYS/fu3dsee+wx93vChAk2btw4t++jU7mwBHxOgk1iP8zC54Ydye0Fg6Bj4HPJ3QsGQVvgWb5BCnQ21TSH6wgELeCg5PYMRBobLP+9XVb43LNWtPi3VvTMcsvf+Y5F0qZ3DEc0h3VPb9auXWsbN240zWfPeJLTKMl2eHW2qLHC7v7gFftpw3/s+XiVHbWGdhUz6CTyopLGePZTk0gkHrP81zdY9NmnzKr3o5K73nr3tdjtd1rj9ePMK+jiDiEWT615HemLVlpaamPGjLEhQ4a454dxSfRKvNp+cWqjvdl4yGJJyfrkFdmswk/YD7pcZaWWKK9TJRE1eHhytxkisqjoqy81Fw8crrHoi6ssWnPI/aRxO3fubCYeOHLkiG3evLlpnHdc9vfk6Z22qbGmSTxQG6+3P9RX2BterY62jx0G7cKJbk9D3vFjZnurmovno+ag5e1LnGNQzIA73V0Bx3mDB+rkpltj70vGDNd59bYhdjDDmbZB0AJmnuwinNw4IziXnCMT/7K9G0FU/xzWlUk8Hx94qXbZHNnKP1cELWCf5LYZ4t17mPW/OPkrDSW9LD7wEsZAxCYX73gplA6O+ysMiq3AroiWqvJnXtctUmDXRvtlbVimsj8M2sWFveKeFrvxZrOL+jmhmlAq8W65zWL9BrifCMgTlfQFSTyi5x0HD0pBTwk4vWCYXZXfx5Si3DFQGilUEvm4XZd3UUZx2wKB3kVz3caCggI3d0ufykXqT1lUw5ZoxVaL7N9r1qu3xa68Rrza4t0SlgVwVR4MVFZWWk1NjXtcNXjwYBs4cKB74+ajXtHijXitvRCrsrcbD1txpIvdlH+xTYpeav0jXZsa1qnmwtleKjVB4jDuizRo7KfjXmGReVnmyjSUpIIlIlwm12M4c0pCQiyxu+XLBZo7VWebC7cMjeG8oiKLy6WxumziAdyZ9TOsYMgWt3BTROtrhdZL0qWLlw1KJK2+vz5bBC6g39hMQ5GOQGpmT+mIjMnuXBCogJolrO3fP7H4c8uWLVZdXe1WXeFGHUHuXVFR4WIpuOyyy9xWSKyvCwCBxQIgq7t6zpw5b/HwlPV5w4cPd0mgI8HUcMeOHe7p9f33328PPvhgoDEwUMhV8jZt2uQWdMtd8JvzgvIMb/Lkyd6ePXs8Ep2Onb9QlnuqvLzcmzp1qldSUpKxQe1FOrGsrMx74IEHvKqqKsTz5CXFOhcY2sSUVdEGVb79lkidBeQdDLGyp/1zRJvFAlniy6r0OAkZofLatJiwuEYbgjsPCI/r+hM6xlpDjXaiS7TdLL6v49vFI9q/sCAx+mpg/LyMc494UAKXy50m6nieGLhlhAgRIkSIECFChAgRIsRHF7nMhXuJF4ksI2AuyhOPVHxMZB67T+SpKte2hL1irUg5PUU+UuS1G3Ni3qAfFuuSv89b5CLg58VviUzsWQed/tHHk+J+cb74FfHLIuAhQomIUKmCLBAph1XhU8UbRR4ecJ7r+DBkmcjK/0bxvEQuk/hPiqw+fUOsENOXGswROfaiiGXtFNeL28QrxPdFBFkrcnyTyP1/KI4SXxBXi/8VsfApIpbMN8iBPYLvSEwTaRxroN0nrWl4SUSg9P+Iwe8/i78T3bfEKbhaRMzvi6kv5YtEvnzn3wdcJ563T2sCfyt3DkAcOoSXJ359+CoRwWeKuHK2OHip+D3xL+I/RcLLZJGQAQgNfxIJPzzgJcZ+W1wujk4eGyz+SOQf8/xD/L1IGYllEK2gowU8KG4QqfDPRKz8ehFhiIOEAdw3PWEBGkhMJqwgMjGYMHG3OEHk3e9bIiLhNQj1KRExCUH/E0tFyrhZJFT8XeS+eMQtYiZPa4ZcXOMqcazox7X0GPgNkZsTyxLr0BLoId4qfiDi5qnnsLT3RBo5RsRibhK5D9+cVIt8KJxJQK6fJT4j8nXUmyL1Ip4OEemYAyLfVtwmYuG3i9RjsVgpXivSaX8T/TK2iHQioeNlkTZlRUdbIJ3wtvgbEVf8jkhjGAL9RJwnkqUz1ROrIb4OFCeKd4o3iFjeNWJfkZHC8+K/xNkiiZDy+ZqATsGNecnOC2M62S8Dw+KDE4ZuLSIXAbEEhhOZhj686cq4MqsVIBTrqrES3JWGLhJniL8SrxRpSKaysWzGj58RcdGvJ7e4KsMpf5jFslYsE7DPONX/4odkRbykM/h7nywX2y2mD9XOQC4CYvKATJru+rgbjUHkdNduCZ8T54oIBfwxIG5NoOefyWBJmUIN1yHUr0Wsl89siV38/quYWI6QqBtxEtekblirb1mUj1CPiPw9pKxHRZJYYu1xC8hFQIIu4zssggb7jcL6MH9caaOYy3/QYbZBYGfQfYno14f1bjQUd9wjZhpIE58ALk5DER2BcMNPi9SPckgalI0odMpnRWIc5xEVS6budAZl4NqUQXxs1asy9Ww2YM4U+AWRSjGGY0X+N0WCP7OKpSIip6KlJELWZOnql0QyMYGbMolXXxX5RwlPiAiNUL8UyZy4e5WI+39RJIYRDrCgkeJTIlmV/R+L/xYZi+JFiMdieJIh00lcnkSCiENFEhOd6r9KbXEWlIuAgB4iAJPeqQQ9SybFZTB5rCV9zMa1I0SEJTOmflLJ3zIE2SUSi8ieJAaEpTOgXyauTEfwm+EJHUJd6BA6E6vjGNmUMSHHsWwEYCzI3x0TMQSsi1hIRxAfqQdiUw7xEfFWiq16U64v1rkeQXBbf+DLDakY47VMA146qbfIOaZo6TGSMgnmxFC2gEYS4xDbLxPrR0SE4Ryuxv1xU/4Wd+fviMM0nPNczzXc108IjB+pD2X4U0Q/IVFX2sP13DvT8ClEiBAhQoQIEaLzw+z/px9eEFjkTNsAAAAASUVORK5CYII='
        
        bitmap_qis         = PyEmbeddedImage(data=img_str_qis.encode() if QIS_or_MES == 'QIS' else img_str_mes.encode()).GetBitmap() # 原图: 80*80
        bitmap_excel       = PyEmbeddedImage(data=img_str_excel.encode()).GetBitmap()      # 原图: 80*80
        bitmap_mspaint     = PyEmbeddedImage(data=img_str_mspaint.encode()).GetBitmap()    # 原图: 80*80
        bitmap_powerpnt    = PyEmbeddedImage(data=img_str_powerpnt.encode()).GetBitmap()   # 原图: 80*80
        bitmap_photoviewer = PyEmbeddedImage(data=img_str_photoviewer.encode()).GetBitmap()# 原图: 80*80
        bitmap_notepad     = PyEmbeddedImage(data=img_str_notepad.encode()).GetBitmap()    # 原图: 80*80
        bitmap_bluetooth   = PyEmbeddedImage(data=img_str_bluetooth.encode()).GetBitmap()  # 原图: 80*80
        bitmap_uts2        = PyEmbeddedImage(data=img_str_uts2.encode()).GetBitmap()       # 原图: 80*80
        
        self.btn_qis         = wx.BitmapButton(pnl, bitmap=bitmap_qis, name='logi_qis')
        self.btn_excel       = wx.BitmapButton(pnl, bitmap=bitmap_excel, name='logi_excel')
        self.btn_mspaint     = wx.BitmapButton(pnl, bitmap=bitmap_mspaint, name='logi_mspaint')
        self.btn_powerpnt    = wx.BitmapButton(pnl, bitmap=bitmap_powerpnt, name='logi_powerpnt')
        self.btn_photoviewer = wx.BitmapButton(pnl, bitmap=bitmap_photoviewer, name='logi_photoviewer')
        self.btn_notepad     = wx.BitmapButton(pnl, bitmap=bitmap_notepad, name='logi_notepad')
        self.btn_bluetooth   = wx.BitmapButton(pnl, bitmap=bitmap_bluetooth, name='logi_bluetooth')
        self.btn_uts2        = wx.BitmapButton(pnl, bitmap=bitmap_uts2, name='logi_uts2')
        
        self.btn_qis.SetToolTip('Quality Intelligence System' if QIS_or_MES == 'QIS' else 'Manufacturing Execution System')
        self.btn_excel.SetToolTip('Excel')
        self.btn_mspaint.SetToolTip('画图')
        self.btn_powerpnt.SetToolTip('PPT')
        self.btn_photoviewer.SetToolTip('照片查看器')
        self.btn_notepad.SetToolTip('记事本')
        self.btn_bluetooth.SetToolTip('蓝牙')
        self.btn_uts2.SetToolTip('Test Plan')

        self.section_btn_dict = {'QIS':        self.btn_qis,
                                'Excel':       self.btn_excel,
                                'Paint':       self.btn_mspaint,
                                'PPT':         self.btn_powerpnt,
                                'PhotoViewer': self.btn_photoviewer,
                                'Notepad':     self.btn_notepad,
                                'Bluetooth':   self.btn_bluetooth,
                                'TestPlan':    self.btn_uts2}
                                        
        self.title_btn_dict = {QIS_title:          self.btn_qis,
                                Excel_title:       self.btn_excel,
                                Paint_title:       self.btn_mspaint,
                                PPT_title:         self.btn_powerpnt,
                                PhotoViewer_title: self.btn_photoviewer,
                                Notepad_title:     self.btn_notepad,
                                Bluetooth_title:   self.btn_bluetooth,
                                'UTS':             self.btn_uts2}
                                
        # 设置所有按钮的背景颜色为初始化时的未点击背景色
        for each_btn in self.section_btn_dict.values():
            each_btn.SetBackgroundColour(Unclicked_button_RGB)
            
        # 在末尾再追加一个固定控件
        btn_select_again = wx.Button(pnl, label='打开选择界面', name='Select_again')
        
        # 开始依次放入按钮
        hboxSizer = wx.BoxSizer(orient=wx.HORIZONTAL)
        for each_section in all_sections:
            hboxSizer.Add(self.section_btn_dict[each_section], 1, wx.EXPAND, 0)
        hboxSizer.Add(btn_select_again, 1, wx.EXPAND, 0)
        
        # 如果是debug模式, 就再在末尾再追加一个固定按钮.
        if not User_mode:
            btn_getAllTitles = wx.Button(pnl, label='标题', name='CurrentAllTitles')
            btn_getAllTitles.SetToolTip('获取当前所有窗口的标题')
            hboxSizer.Add(btn_getAllTitles, 1, wx.EXPAND, 0)
        
        self.vboxSizer = wx.BoxSizer(orient=wx.VERTICAL)
        intial_bitmap         = PyEmbeddedImage(data=default_img_str.encode()).GetBitmap()
        self.img_show_correct = wx.StaticBitmap(pnl, bitmap=intial_bitmap) #wx.NullBitmap
        self.vboxSizer.Add(hboxSizer,             0, wx.EXPAND, 0)
        self.vboxSizer.Add(self.img_show_correct, 1, wx.EXPAND, 0)
        
        pnl.SetSizer(self.vboxSizer)
        
    def Button_FCT(self, evt):
        global count_pressed, index_Title_dict, countdown
        the_obj  = evt.GetEventObject()
        obj_name = the_obj.GetName()
        
        if obj_name in Windows_Title_dict:
            if obj_name == 'logi_qis':   # 设置所有按钮的背景颜色为初始化时的未点击背景色
                for each_btn in self.section_btn_dict.values():
                    each_btn.SetBackgroundColour(Unclicked_button_RGB)
                    
            if obj_name == 'logi_bluetooth':
                # 特别注意: 若不写control, 则会报错: pywintypes.error: (31, 'ShellExecute', '连到系统上的设备没有发挥作用。')
                win32api.ShellExecute(0, 'open', 'control', Bluetooth_cpl, '', 1)
                the_obj.SetBackgroundColour(Clicked_button_RGB)
                return
            
            window_title = Windows_Title_dict[obj_name]
            the_window   = gw.getWindowsWithTitle(title=window_title) # 注意: 这是个list,所以满足条件的可能不止一个.
            
            if the_window:
                the_window = the_window[0]                          # 注意: 这里只获取第一个匹配的窗口,所以稍微有点局限.
                the_window.activate()                               # 作用: 窗口置顶
                the_window.maximize()                               # 作用: 窗口最大化
                the_obj.SetBackgroundColour(Clicked_button_RGB)
            else:
                if obj_name == 'logi_uts2':  # 这里是为了兼容 UTS1, 在找UTS1程式的窗口
                    the_window = gw.getWindowsWithTitle(title='.tpm')# UTS1 的程序在最小化时,必须用test plan的文件名称去匹配才有效
                    if the_window:
                        the_window = the_window[0]
                        the_window.activate()
                        the_window.maximize()
                        the_obj.SetBackgroundColour(Clicked_button_RGB)
                    else:
                        wx.MessageBox(message=f'未找到任何UTS1或UTS2相匹配的窗口:\n\n{window_title}', caption='myWarning', style=wx.ICON_WARNING)
                else:
                    wx.MessageBox(message=f'未找到包含如下指定标题的窗口:\n\n{window_title}', caption='myWarning', style=wx.ICON_WARNING)
                    
        elif obj_name == 'Select_again':
            sencond_dlg = MyDialog()
            ret_value   = sencond_dlg.ShowModal() # 这里在等待用户行为
            if ret_value == wx.ID_CANCEL:
               return
            Auto_open_close_WindowsAPP(user_dialog=sencond_dlg)
            with lock:
                countdown = Interval_time_alert
        
        elif obj_name == 'CurrentAllTitles':
            now_all_titles = gw.getAllTitles()
            now_all_titles = list(filter(None, now_all_titles))   # filter()函数可以用来过滤掉列表中的空值
            wx.MessageBox(f'当前所有窗口的标题:\n\n{'\n'.join(now_all_titles)}', 'info.', wx.ICON_INFORMATION)
            
    def Auto_alert(self):
        # thread_2线程函数
        global countdown 
        try:
            while True:
                time.sleep(1)
                with lock:
                    countdown -=1
                if countdown == 0:
                    countdown = Interval_time_alert
                    self.Maximize(maximize=True)
                    wx.MessageBox(message='请确认当前产品图片\n\nlogi OOB', caption='[logi OOB]自动提示')
                    self.Maximize(maximize=True)
        except Exception as e:
            pass
            # print(e) # 若没有退出函数OnExit_GUI,在点击右上角的[关闭]时,则报错 : wrapped C/C++ object of type MyGUI has been deleted
            
    def OnExit_GUI(self, event):
        self.Destroy()
        os._exit(status=0) # 不要用 sys.exit(), 否则在点击右上角的[关闭]时, 程序会卡死, 无法关闭程序.
            
if __name__ == '__main__':
    
    app = wx.App()
       
    # ======================== 配置档
    abs_path = os.path.abspath('')
    cfg_file = os.path.join(abs_path, 'OOB_cfg.ini')
    if not os.path.isfile(cfg_file):
        log_Essential = r'C:\Users\Public\Documents\OOB_cfg.log'
        if not os.path.isfile(log_Essential):
            wx.MessageBox('Find no ' + log_Essential, 'myWarning', wx.ICON_EXCLAMATION)
            os._exit(status=44) # 注意: 这里不能使用return,否则报错 SyntaxError: 'return' outside function.
        with open(file=log_Essential, mode='r', encoding='utf-8') as readObj_01:
            cfg_file = readObj_01.readline().strip()
        if not os.path.isfile(cfg_file):
            wx.MessageBox(f'Find {log_Essential}\n\nBut find no {cfg_file}', 'myWarning', wx.ICON_EXCLAMATION)
            os._exit(status=44) # 注意: 这里不能使用return,否则报错 SyntaxError: 'return' outside function.
            
    config = Cfg()          # 这个config是个实例对象
    
    try:
        config.read(cfg_file, encoding='utf-8')
        all_sections = config.sections()
        all_sections.remove('General Setting')
        User_mode              = config['General Setting'].getboolean('User_mode')
        Stay_on_top            = config['General Setting'].getboolean('Stay_on_top')
        Monitoring_key         = config['General Setting']['Monitoring_key']
        Interval_time_alert    = config['General Setting'].getint('Interval_time_alert')
        Unclicked_button_RGB   = tuple([int(i) for i in config['General Setting']['Unclicked_button_RGB'].split(',')])
        Clicked_button_RGB     = tuple([int(i) for i in config['General Setting']['Clicked_button_RGB'].split(',')])
        Revision_control       = config['General Setting']['Revision_control']
        QIS_or_MES             = config['General Setting']['QIS_or_MES']
        VBS_script             = config['General Setting']['VBS_script']
        QIS_website            = config['QIS']['QIS_website']
        QIS_title              = config['QIS']['QIS_title']
        Excel_filename         = config['Excel']['Excel_filename']
        Excel_title            = config['Excel']['Excel_title']
        Paint_filename         = config['Paint']['Paint_filename']
        Paint_title            = config['Paint']['Paint_title']
        PPT_filename           = config['PPT']['PPT_filename']
        PPT_title              = config['PPT']['PPT_title']
        PhotoViewer_foldername = config['PhotoViewer']['PhotoViewer_foldername']
        PhotoViewer_title      = config['PhotoViewer']['PhotoViewer_title']
        Notepad_filename       = config['Notepad']['Notepad_filename']
        Notepad_title          = config['Notepad']['Notepad_title']
        Bluetooth_cpl          = config['Bluetooth']['Bluetooth_cpl']
        Bluetooth_title        = config['Bluetooth']['Bluetooth_title']
        TestPlan               = config.items('TestPlan') # 这里得到所有键值对[('key1','value1'),('key2','value2'),…]
        
        all_project                 = []
        Project_PictureFolder_dict  = {}
        Project_Icon_dict           = {}
        Project_TestPlan_dict       = {}
        for key, value in TestPlan:
            all_project.append(key)
            Project_PictureFolder_dict[key.lower()] = value.split(',')[0].strip()
            Project_Icon_dict[key.lower()]          = [icon.strip() for icon in value.split(',')[1].split('|')] if len(value.split(',')) >=2 else []
            Project_TestPlan_dict[key.lower()]      = value.split(',')[2].strip() if len(value.split(',')) >=3 else ''
        print('Project_PictureFolder_dict:', Project_PictureFolder_dict, sep='\n', end='\n\n')
        print('Project_Icon_dict:',          Project_Icon_dict,          sep='\n', end='\n\n')
        print('Project_TestPlan_dict:',      Project_TestPlan_dict,      sep='\n', end='\n\n')    
         
    except Exception as e:
        wx.MessageBox(message=f'Please find below Error in config file:\n\n{cfg_file}\n\n{e}', caption='myWarning', style=wx.ICON_WARNING)
        os._exit(status=44) # 注意: 这里不能使用return,否则报错 SyntaxError: 'return' outside function.
    
    else:
        if QIS_or_MES in ['QIS', 'MES']:
            pass
        else:
            wx.MessageBox(message=f'QIS_or_MES was set as "{QIS_or_MES}" which is invalid\n\nQIS_or_MES must be set as either "QIS" or "MES"', caption='myWarning', style=wx.ICON_WARNING)
            os._exit(status=44) # 注意: 这里不能使用return,否则报错 SyntaxError: 'return' outside function.
    
    # ======================== 检查软件版本
    if Revision_control != latest_ver.split(':')[1].strip():
        wx.MessageBox(message=f'软件控制版本: {Revision_control}\n\n软件当前版本: {latest_ver.split(':')[1].strip()}', caption='myWarning', style=wx.ICON_WARNING)
        os._exit(status=44) # 注意: 这里不能使用return,否则报错 SyntaxError: 'return' outside function.
        
    # ======================== 定义出所有指定的窗口标题
    Windows_Title_dict = {'logi_qis':       QIS_title,
                        'logi_excel':       Excel_title,
                        'logi_mspaint':     Paint_title,
                        'logi_powerpnt':    PPT_title,
                        'logi_photoviewer': PhotoViewer_title,
                        'logi_notepad':     Notepad_title,
                        'logi_bluetooth':   Bluetooth_title,
                        'logi_uts2':        'UTS'}
    print('Windows_Title_dict:', Windows_Title_dict, sep='\n', end='\n\n')
    
    index_Title_dict   = {}
    Section_Title_dict = {'QIS':       Windows_Title_dict['logi_qis'],
                        'Excel':       Windows_Title_dict['logi_excel'],
                        'Paint':       Windows_Title_dict['logi_mspaint'],
                        'PPT':         Windows_Title_dict['logi_powerpnt'],
                        'PhotoViewer': Windows_Title_dict['logi_photoviewer'],
                        'Notepad':     Windows_Title_dict['logi_notepad'],
                        'Bluetooth':   Windows_Title_dict['logi_bluetooth'],
                        'TestPlan':    Windows_Title_dict['logi_uts2'],
                        }
    for n, per_section in enumerate(all_sections):
        index_Title_dict[n] = Section_Title_dict[per_section]
    print('index_Title_dict:', index_Title_dict, sep='\n', end='\n\n')
    """ 例如:
    {0: 'Logitech Quality Intelligence System v2.0 - Google Chrome',
    1: '1_OOB_Excel',
    2: '2_OOB_Paint',
    3: '3_OOB_PPT',
    4: '- Windows',
    5: '5_OOB_Notepad',
    6: 'UTS'}
    """
       
    default_img_str ='iVBORw0KGgoAAAANSUhEUgAAATgAAAA8CAYAAADymabIAAARyElEQVR4nO2dCbRXRR3Hv7wHj1XBXVZDQTQ10QxMQM0l933fkNTSUhPXsIw0wqUos8xKUQGJXECfmUjFoqEGCorGIi4sIiIioLIp2+tM5/s/557LLL+Ze+//LcznnDnw3rszd+72u7/5bReRYL4CYBCAMQD+CuBKAK3i6Yzw3qipw+3wgIvUxnA8t2a44NWa8RYEjrUzgEcAPAbgSQBDAFQ1BvCppVMfAP8N3GFD5hwAI9QJTBzjuQB+BOB4ADO39hOUA28C6GQY5gcARtWro4kUSSMAQwHcA+AiAC8BeB/AYCXgWlt2XBkvyxZ8jW+KJpq/dQTwdwB7A1hXy/Os72xruTerGs5hRnJgPwCvAVhOTfO7APYHcHFFPLveXGcQbiV2A3Be3Z1+JNLg2AbAJzyo9gDeArAZwJeN47X25puCDocAeEjz+/MB9DD0eSUuuyKRIJT2djOAF2kT7wDgFKWIRAHnj017K9HM8PtvK7XZ8LfhUcA1eN4AMENzkOdr7qv3+MCmORnAdqnfLQUwTrNtFwC9auGktqDRX7JdmsZ00kj4AsBHNAfdR6efeoZWArgKwOVRwPkzG0BnR6/omInoqDZ4HU/V2BuVcOun2XaGRsC9Zdi2Xy0JOPUifyqwr1pizhdu+0LCIzyWqyD18yIAJykBGAWcP38GcIKl11p6WCORSHlRdrjRyT1GAefPMwB+C6C/pucGvjWX1PWDiEQMKA3qRs2fmhq2P5aeyxJ1yswSBVwY13IJodb5X1XeGv58J+O3IhEd3Q1LSV3YSxfDtttrfrerYdveAVdhJwDXeGzfk63EDEdsbVmJAi6cMWyRiJRT2CT08rCfdQPwcLwKWxIFXCQSyRtlonlaMGZPap9JlEf0n8L5ODOGihJwKkzi6wD2BLAjgJYAVgNYBmAu41bWF7TvJHsA2JfBt20Y/Keind8FMI3u5IZCY0ZvqyyKXRj8uJbH+zaA6fy5SNTy6QBe9zZcen0GYDG9z3N4DYqgBWMM9+I9V0Gjs7rWUzmPSHmYSs+wi2qNRvuxsK+IPAVcFSP4LwBwmCOdRknpSUx5Ul6PjTnOQwm0ywCcwYA/G6/ywZMwkPltigF8kHRUs4EXKnmxbDYR9bdhiZ+T49g4GsClzIHdxrKdcoBM5D7yPOc70v6jcnEPZF6gieVMZRtqiPEK4WAANzAswHTPKaH6L+YqPpfTfiP1BFvVg+6CQ6hg7teHgdUTFjDQ0fZgSNiDsTdFVXFInovnLdsl45xuzbA/V5WG3tSEQ8Z+h7FKWVBa+e3UzEPm8JIjK2SBpW8/aogjA/arlj/tMh67i/pcTaQV/55uJxrGGpbaLr3ktJFnNREtWTU45VL+CzW2UHbjGBcyyn9ZwDiqVNGvLa7shoSKeL8DwPUZjkl56P5BjUaNs8mzv7KdPOoRca7jEAo5VdbmFk+TRQcug/YM2K/SeF8HcFSBAdkquv5bBY2dB7psihKr+QJP08aw/QLN9l0B7COYZ1vN71oIl6jLeP9YySLg9qe6r5tkCMcxEvkY2owkqGonf6QGuTWgLv4TXI7mgQoH2B3AmR4C5mxqTpKUNReNGHOl7HanA1gl7HcbVw6h7ExNrgej3vPmC4OQ0NGJx65jHLMU6hs9aX4KYSdhFsSDEgEHj2VZkr0pQYtQnz+gVueiVAOqXGp9bS9RlTB/tqBjGyq8Ec+gtlfEHCanNHDbEjWvNikH00gWmtP5ozueJQ6barnxKXi5Txmu3RWS4w/R4FrTULxjQSe4Pcfv4aipdj2N61sLg3LU3NJcyrw+21t3P2puRZXYUjbFI5lTWC4Op9AeXcZ9JrmfjhkdoxmJUATzEg6zIlDe8hWGoOS8+Ld0HKnWUmKYh5Sdx9SmYRRaPm/luy1z3pdeQck46/jwjqLd6CWPvjUMM7iNBRhLSDW4AYzqLrX1ln7rU9sOSIzTk55A2zw/phDsSQcA+DI6lKllqxz9l1vsLGo5Okt4vjbRPvYYr/sEAJ8L+qVtir4a3EIuO6t5vdcI+00VPSX5MzhnjUbaNjP7xhffkuWjCjyGhT5ztw2UFnA9hRN4nJVvdRzIDADXGBstF2KioL96Q12SeNiTqAf/apaZcY0zUNNfKuDS2F4Owyz9XnbM8TGLcCrRkQ++bZw7DX37C86TEso/BrCDpn9T2u5MQnKApo9UwI2mPThNFb2tkmvc1XHu8qa2hFsNX/Ih2ARcc0ZCPMeS4aBdt6hj+J3P/G0DpQWcywa0ylFpI8nJDDy1jTdS06+X4AQ8IfwAzPZ869vGWsfA2STlFHCHOeY33MOO1IKxf6axVmhq2TWjPcg2h2mCmEMkPMDJvjrhBqGA+6Fgnx0FQu4qwTh50ITVaIp68F0tVHuDRcC9k9LQSzmxzfjS0/WZyOfE1mwhQAf5TFwq4Do4lkkbAr7Wc7TDaP2lpvbVcMecn/b8lkQV1/O2MW9K9SmngHvE0uc9vj196Ebt2DTm2amxznKcm7maa+TiUodwg0DA3eexvzMcY9m057xoR6dGbQm3mgzaGywCLt2SSf93G7Z5V2D/f9LQd5rvxKUC7hrHtqbljYshjnGTFXAbO2xJKwMNmx2oqZnGTcdLlUvANWaKkanPJQHHCsfbMe1oeNxxfQ4JnIMriNwm4NZ4OrkqWETRNJ7YYB3IabSR1qZw2xAYNwiaHa4NEHCdLS/TKy3762MZ/wKfift4UW3a2aoMAu4Ounx1trLSfofz/wc5lp5DuMzy5QPG011r6LcvBWfI2FnonnJuJNnA5bXL9qZjrOVGOTT1sy1gdRztgyHYgk1dTEh8ZERCKVXLFC/pq4FK6cwA9NMc2/+BWk0WKqkRmwT/YI/4UnBlczwVjBMC4x7n82WqK9M/mPbTpanfN+GzqONt2pu9kGpw8yzbZVF94XA6TE9sd5ljvq5S4jYOcox9VKJvuTS479TS276kBe/q8bbOG5sGd0vAvq6zjJdrehCD3+9xeM1raJ7JI0i9ypD2VGozPAVUf3rVQ+6d9D3R2XIedOXGfmYZ+xzfE+MT02QLvp3su+MUL1j+lkwH2t2y3Qcetdx1uKptmD5CXCRZBHYWSvu1nW+UYWlnIiSdr5yVY9T56+sQKiuZvfMAf1a21F8EeHR3oHZqqjO3inbUDR5jHh5g6plNDfLZ1O/VM/kbQ5/TUwK+lyFqAQzvetxzTmIBt41j28W+O05hK/Gd/BiHbXn6YcY51DiOo6hljA3T8rRoSsnoLk901nMeypcB/WrKOL+XGbhsup+mcsVQqnvWmiEWP2GNs9uEedUqo2iKxqxQYjPDN94JPxQnExiQrLIX7jK8fAZRAdFxD4P62zH6QSdnNtFm530NpQLONXDWL43bwhxqDP9Pk8dX+KXzaOg0Ex5zbaY51XVmsVrKnMQ811ND6U2TD7gyej5RsKKK20x3OGLOY8hPF8s2/RlgXyQvsqqNjTWWpXhzRj6MteS138FPLnojFXCrHRUnspafaW/5W7JQoS0Zu2PGOVQ45rEm4/ghlKMoqI6Sw2e1YztJ7NvWzCJ6BP/D6i37Upsp1eLrwwITOkG2D7WzdM5lK8bSjbI45sAPIf8+x3P/asb+4+hM0bGrIVgbDAv5eehOfbyoCy02mSOZDhSKzUObNADbbGw786aYFTiHHo6YsqxerhBMan2JRQVVyC0JNtcxH1rw8qchsJyCLK0gVNAGZbN1NaVHUXmyv8csoIcEZapuzhDVkORdekFH0GaY1Y55I8OKDhBu/yk1VR/74RbYPCLJN8sTlu2+yFA2aRdHRsMDiW1dns67MpyHex1j75TYtlxe1GMcczoyw/FK+ciy/wkF7tdV8NKXfmX0ovrQTZBNU8Pr4MpH3kRBmJW+FERJE4RvLqqJTsL0uU1MBMiEjxd1kuVvTeneDeGnDs0pud/XHbX1rw5cNu3uuDFmBnrusvKKww6Wx83swibEjmALIUuR1IbEXFZXvtgRZ7mLw+a5kuPcn8O5GZHIf84blSP+K8GYY+gdzoxUg2srqAVmKtxn4hTHW2mdxpPoqgE32dPp0SIhSEwt7bouZ6rWZMfc+ngca4kKJixLljGnOva/IKXdSigl79v2v7VocEna05vq0m7SbRpL9hdJHhpcUwo3lyZaatUB99YWSAUcLPlhpbY+UU3AxUWCQMgHNWN8Q3BiJgpTedrSC+Q6prQDo5wC7nLH/JY4PGlptmcJq1J/l5Cr4lvXNoeZwgdMvUz+lOprMiBvjQKuB3NsbbnCybaJ38XIo7qyi6wC7kRmIvgK7xUsqhBcfdxHwHUXSt/xXIKkQzcqaTAdLxhjveXBlVS2Xc4aY7o3QFvGHJmqHSSbLqm7nAKuJdOSbHNcyuosNiposF2s6e8SclcIztNaBqrqvNkqzuv7dFTp+vqWS2ooAq4Fl5V3sTS5z4M/PfVF+aLpaJiHyzR1MJeavoIt3eawEIR3wVUfAQc+8NJJLWO0ezX/dT2oyXa7Zc5d6diQjLOJtrtnqf7P9Jy/rr5ZuevBXSmc7xS+7Q6mMbczXygDaeux9bUJuUrPL3jN5rmu5oPo0tRrNEKuIQm4ZrwWR3N5/gBtXJLzkm6f8H7II+7TxH0MRbmEeahnMhtBNx9TqakjPATbZx71/+YwhVFshrINphNwLT2qu4a2VwQHINEqsrbjDPsut4CrFBSrzKPZ4o32yvCJQGk7KbG/+irgKviyGE9BvyKnc1Oq8iypc5gVW15ruiWdTG1YdWi2R/8pdPJt5/nZT1Wd5ZcS84yvgAMnFPodVFeb5xFyYqo3lUfrb9lvuQUceE5MS7w82lqBR/TYQK1D0salbEn1WYNrywT3PM7LO6xy01qw37yQCrjViWDjaxwlx9Jto8Z+2IiREK7y+sm2mTmqxqVriIADa0vZamyFtNmeSe2NBPXkfNtmXiwbtSHgwLdV3ue8hgHFUnvO8YJKzL7tKU2oUH1forYWltbXtXUMkzi2wI/82JAKuDsSY7Tw8AC/bMlcAGXA3zzu3b1tBxMq4EBP5TPCibjaoxneUhcKP2ziaksZXOuitgQcGA8lCQyVttHMAvFhP09bpqltZOkjnT2pIdjgqgQFQ0ttBa/FuWVahtqQCLhJmoIAVXyObee5r0cO8xEsTGAa721JimYWAVfiLKrSITf5LI/vONhoTyEhdbEn2zrGhUkrhtSmgANvkL4Zl6xT6MELpYo2odC6YWMpKE00FCdDBdMY0/t8n5prfz5ntaGpmXjIcq7WMpbNFJxfyZzT9LFeEViUoxFjMdMfXnpNEiPXyPFgDfT4fmIFQxUupLfIVupnJZOPR9D2UiPch4TOvJlPZ3Kzic308I3hOUhXFrUxgEZ3HdVsOi5jJQkdL3p8gLlEYx7nOSzI6SqvNJfLiJGpQqJZaMWSPOexnpctJmsBlx4qvvFNxz6HWGIZh/J8+dCb51+H8kzekNP5MNGPD/gslsD/vOD9ZaUrc0Y78RqvoRLzPB0eLgYx9m0Iq/BuzGFOvVi4tA3ve1tW0/8pqtxNJdfF3XiTNqfkX8Z4n7kFJYmn2YlCriMDXDdzKbCQD5jzBNUjKil0u3DJ2ZJJyp/xeN8qQ7pZM2plXXi+m3D/S/hgL2pA5ztSD6hv9byOZ7S3DvUQP5xxfJu3anyA1hCJRCJiTMGGNanCgqHYvIO2sJFIJFIHqUuGTQk2O9lumo8W+9DBUdXEx0YXiUTqAPVNwNmKKzbPULoHqSh6HT6fXItEIhFvXJ+xs9Wss9HYUelgbQ7fnYhEIhEnbziE3NkBp/BGx5jPxMsSiUTKgUsYrfUsAnmmoJBniNCMRCIRb9owtsomkNR3M29yfFtyW1Z9cAm3+VmK7UUikYgvA4TpQItYUuU4Bvx2Z7bFvR616c6PVycSiZSTqhzL0dja2HhVI5FIbdA1Q6K3pM0XftchEolECqGnwB4X0hZ7fsglEolECmF/j3rukvYmsyIikUikTqDquA3PKNg2Mtc1S7pXJBKJFIZasj4tCP1Ih5SMdJU9jkQi9Y/6Vi5JSjtWAT2M4SGdE4n0q+hAUEUHJ1Agrqj7hxSJRLwA8D9ad/AaGpVyeAAAAABJRU5ErkJggg=='
      
    first_dlg = MyDialog()
    ret_value = first_dlg.ShowModal() # 这里在等待用户行为
    if ret_value == wx.ID_CANCEL:
        os._exit(status=44)         # 注意: 这里不能使用return,否则报错 SyntaxError: 'return' outside function.
    
    # ======================== 主界面
    the_size = (80*(len(all_sections)+1)+100, 130)
    if Stay_on_top:
        the_style = wx.DEFAULT_FRAME_STYLE|wx.STAY_ON_TOP
    else:
        the_style = wx.DEFAULT_FRAME_STYLE
    GUI = MyGUI(None, title=f'{app_name} ({latest_ver})', size=the_size, style=the_style)
    
    # ======================== 创建对象: PostMessageA
    user32 = ctypes.WinDLL('user32.dll')
    user32.PostMessageA.argtypes = [ctypes.wintypes.HWND, ctypes.wintypes.UINT, ctypes.wintypes.WPARAM, ctypes.wintypes.LPARAM]
    user32.PostMessageA.restype  = ctypes.c_bool
    
    # ======================== 自动打开/关闭与指定产品需要的Windows APP
    Auto_open_close_WindowsAPP(user_dialog=first_dlg)
    
    # ======================== 监听键盘按钮
    if Monitoring_key:
        if not os.path.isfile(VBS_script):
            wx.MessageBox('Find no ' + VBS_script, 'myWarning', wx.ICON_EXCLAMATION)
            os._exit(status=44) # 注意: 这里不能使用return,否则报错 SyntaxError: 'return' outside function.
        keyboard.on_press(on_key_event, suppress=False) # 注意: suppress=True时, 会导致键盘上的按键打不出字符.
        #keyboard.wait('esc')  # 等待直到按下'esc'键
        
    if Interval_time_alert:
        countdown     = Interval_time_alert                     # 单位:秒, 声明全局变量
        lock          = threading.Lock()                        # 申请一把锁
        second_thread = threading.Thread(target=GUI.Auto_alert) # 声明线程数
        second_thread.start()                                   # 启动线程
    
    app.MainLoop()