# This Python file uses the following encoding: utf-8

import wx
import os
import sys
import socket
import win32com.client
import wx.lib.agw.aui as aui
import wx.lib.agw.pybusyinfo as PBI
from getpass import getuser
from lib_bushound import MyBushound
from wx.lib.embeddedimage import PyEmbeddedImage

# ============ 版本记录
first_ver  = 'Ver: 1.0.24.1105'
latest_ver = 'Ver: 1.0.24.1123'
app_name   = 'UID_reader'

# ====================================== Mouse项目设置
info_mouse = {'Palau-Avalon-Dagger-ROM (M185)': 
                        {'Category': 'MSE_ROM', 'eQuad_ID': '4091', 'DevManuf_PWD': '', 'Description': '810-007154(for Rangoon palau in GTECH_VN),,810-007075(for Pattaya in GTECH_VN),810-007156(for Pattaya in GTECH_VN),810-007089(for Pattaya in GTECH_VN)'},
            'Nara-CR (M310)': 
                        {'Category': 'MSE_FLASH', 'eQuad_ID': '4055', 'DevManuf_PWD': '', 'Description': '810-006913(for Rangoon nara in GTECH_VN),810-008625(for Rangoon nara in GTECH_VN),810-008627(for Rangoon nara in GTECH_VN)'},
            'Palau-Slient-BLE (M240)':
                        {'Category': 'MSE_BLE', 'eQuad_ID': 'B03B', 'DevManuf_PWD': 'AF604F394A9913EE2018F4C04C210406', 'Description': '810-009220(for Rangoon Pamir in GTECH_VN),810-009344(for Rangoon Pamir in GTECH_VN),810-009343(for Rangoon Pamir in GTECH_VN)'},
            'Sanak M for Business (M650)':
                        {'Category': 'MSE_BLE', 'eQuad_ID': 'B032', 'DevManuf_PWD': '8C40CCACF393AF171415AAFF085D9155', 'Description': '810-007772(for Rangoon BLE in GTECH_VN),810-007774(for Rangoon BLE in GTECH_VN)'}
            }

# ====================================== Keyboard项目设置
info_keyboard = {}

# ----------------- RCV PID setting
RCV_mgmt = {'C52F':['UID'],
            'C534':['UID'],
            'C547':['UID'],
            'C548':['UID'],
            'C52B':['UID'],
            'C539':['UID'],
            'C53F':['UID'],
            'C53D':['UID'],
            'C542':[''],
            'F013':['FW_Build'],
            'FA01':[''],
            }
            
# ----------------- basic setting       
Open_Lock_timeout  = '08'
LNA_gain           = '00'
AFF_gain           = '00'
#eQuad_ID          = '4091'
Mask_ID            = 'FFFF'
RSSI_threshold     = '0F'
Page_Scan_Interval = '00'
HIDPP              = '21 09 11 02 02 00 14 00'
HIDPP_short        = '21 09 10 02 02 00 07 00'

# ----------------- used for MEZZI1 and MEZZI2 RCV
x1E02_Manuf        = '78314530325F4D616E7566'
var_x1E02_Manuf    = ' '.join([x1E02_Manuf[2*i:2*i+2] for i in range(len(x1E02_Manuf)//2)])
RcvManuf_PWD       = '571C1CA986FF48901E3547848439EE5E'
var_RcvManuf_PWD   = ' '.join([RcvManuf_PWD[2*i:2*i+2] for i in range(len(RcvManuf_PWD)//2)])

# ----------------- used for Enable Gothard in BLE(Bluetooth Low Engine) device
x1E02_Gothard      = '78314530325F476F7468617264'
var_x1E02_Gothard  = ' '.join([x1E02_Gothard[2*i:2*i+2] for i in range(len(x1E02_Gothard)//2)])

def all_USBHub():   # just reserved
    logi_pid_list = []
    wmi = win32com.client.GetObject('winmgmts:')
    for usb in wmi.InstancesOf('Win32_USBHub'):
        USB_VID_PID = usb.DeviceID
        # print(USB_VID_PID)    #'USB\\VID_046D&PID_C52B\\5&116A2970&0&4'      
        if 'VID_046D' in USB_VID_PID:
            logi_pid_list.append(USB_VID_PID.split('\\')[1].split('&')[1].split('_')[1])
    print('Here are all logi devices:', logi_pid_list)
    return logi_pid_list
    
def all_usbcontrollerdevice():
    logi_pid_list = []
    wmi = win32com.client.GetObject('winmgmts:')
    for usb in wmi.InstancesOf('Win32_usbcontrollerdevice'):
        USB_VID_PID = usb.Dependent
        # print(USB_VID_PID)  # b'\\\\LOGIOQB0PJFGOHP\\root\\cimv2:Win32_PnPEntity.DeviceID="USB\\\\VID_046D&PID_C52B\\\\5&116A2970&0&1"'
        if 'VID_046D' in USB_VID_PID:
            if len(USB_VID_PID.split('\\\\')[2].split('&')) == 2:
                logi_pid_list.append(USB_VID_PID.split('\\\\')[2].split('&')[1].split('_')[1])
    print('Here are all logi devices:', logi_pid_list)
    return logi_pid_list

def HIDPlusPlusRequest_BufferRead(DevID_out:int, DevID_in:int, the_timeout:int, the_CMDTimeout:int, the_CommandList, the_min):
    the_ret  = None
    the_Flag = False
    for m in range(0,3,1):
        print(f'\n============> Try sending: No.{m+1}')
        obj_bushound.Buffer_Control_Clear()
        the_buffer = obj_bushound.USB_HIDPlusPlusRequest(DevID_out=DevID_out, timeout=the_timeout, CommandList=the_CommandList, CMDTimeout=the_CMDTimeout, DevID_in=DevID_in)
        if the_buffer[0]:
            if the_buffer[1]:
                if the_buffer[2].decode().startswith(the_min):
                    the_ret = the_buffer[2].decode()
                    return the_ret
                        
        for n in range(0,20,1):
            print(f'======> Try reading: ({n+1})')
            the_buffer = obj_bushound.Buffer_Control_Read(DevID=DevID_in)
            if the_buffer[0]:
                if the_buffer[1]:
                    if the_buffer[2].decode().startswith(the_min):
                        the_ret = the_buffer[2].decode()
                        the_Flag = True
                        break
            wx.MilliSleep(milliseconds=100) # 延时100毫秒
        if the_Flag:
            break
    return the_ret
    
def GothardRCV_Confirm_Pairing(eQuad_ID):
    MSE_Address = None
    DevID       = 0
    DevID1      = 0
    DevID2      = 0
    DevID3      = 0
    
    # Open Gothard RCV
    obj_bushound.Driver_Initialize()
    DevID  = obj_bushound.USB_OPENDEVICE(PID='F013', VID='046D')[2]
    DevID1 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID, EpNo=1)[2]
    DevID2 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID, EpNo=2)[2]
    DevID3 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID, EpNo=3)[2]

    # Enable wireless notification
    result = HIDPlusPlusRequest_BufferRead(DevID, DevID3, 100, 3000, f'{HIDPP_short} 10 FF 80 00 00 01 00', '10 FF 80 00 00 00 00')
    if not result:
        Disable_wireless_notification_FCT(DevID, DevID3)
        return MSE_Address, DevID, DevID1, DevID2, DevID3
        
    # Proximity Open Lock
    result = HIDPlusPlusRequest_BufferRead(DevID, DevID3, 100, 3000, f'{HIDPP} 11 FF 82 B2 07 00 {Open_Lock_timeout} {RSSI_threshold} {LNA_gain} {AFF_gain} {eQuad_ID[0:2]} {eQuad_ID[2:4]} {Mask_ID[0:2]} {Mask_ID[2:4]} 00 {Page_Scan_Interval} 00 00 00 00', '10 FF 82 B2 00 00 00')
    if not result:
        Disable_wireless_notification_FCT(DevID, DevID3)
        return MSE_Address, DevID, DevID1, DevID2, DevID3
        
    busy_info = PBI.PyBusyInfo(message='Now, Please Power on Mouse ...', title='Tip')
    # Read Buffer to confirm pairing
    for n in range(0,50,1): # 持续读 50*100=5000(毫秒)
        the_buffer = obj_bushound.Buffer_Control_Read(DevID=DevID3)
        if the_buffer[0]:
            if the_buffer[1]:
                if the_buffer[2].decode().startswith(f'20 01 41 00 {eQuad_ID[2:4]} {eQuad_ID[0:2]}'):
                    the_ret = the_buffer[2].decode().split()
                    MSE_Address = ''.join(the_ret[10:14])
                    break
        wx.MilliSleep(milliseconds=100) # 延时100毫秒
    del busy_info
    if not MSE_Address:
        Disable_wireless_notification_FCT(DevID, DevID3)
        return MSE_Address, DevID, DevID1, DevID2, DevID3
        
    # Disable wireless notification
    Disable_wireless_notification_FCT(DevID, DevID3)
    
    return MSE_Address, DevID, DevID1, DevID2, DevID3

def UnlockRCV_Confirm_Pairing_MSE():
    DevIdx   = None
    DevID_e  = 0
    DevID_e1 = 0
    DevID_e2 = 0
    DevID_e3 = 0
    
    # Open Unlock RCV
    obj_bushound.Driver_Initialize()
    DevID_e  = obj_bushound.USB_OPENDEVICE(PID='C548', VID='046D')[2]
    DevID_e1 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID_e, EpNo=1)[2]
    DevID_e2 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID_e, EpNo=2)[2]
    DevID_e3 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID_e, EpNo=3)[2]
    
    # Unpair all devices(Slot 1 ~ Slot 6)
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 01 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 02 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 03 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 04 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 05 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 06 00')    
    
    # Enable wireless notification
    result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP_short} 10 FF 80 00 00 01 00', '10 FF 80 00 00 00 00')
    if not result:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
        
    # Perform Device Discovery for 5s
    result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP_short} 10 FF 80 C0 05 01 00', '10 FF 80 C0 00 00 00')
    if not result:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
    
    # Get BT_Addr/RSSI (Swallow 建议降低要求: 这里不卡关DevPID)
    BT_Addr = ''
    RSSI    = ''
    for n in range(0,20,1):
        the_buffer = obj_bushound.Buffer_Control_Read(DevID=DevID_e3)
        if the_buffer[0]:
            if the_buffer[1]:
                if the_buffer[2].decode().startswith('11 FF 4F') and len(the_buffer[2].decode().split()) >= 20:
                    # if the_buffer[2].decode().split()[4:7] == ['00','00','10'] and the_buffer[2].decode().split()[8:10] == [DevPID[2:4], DevPID[0:2]]:
                    if the_buffer[2].decode().split()[4:7] == ['00','00','10']: 
                        the_ret = the_buffer[2].decode().split()
                        BT_Addr = ''.join(the_ret[10:16])
                        RSSI    = int(the_ret[19], 16)      # 十六进制转十进制
                        break
        wx.MilliSleep(milliseconds=100) # 延时100毫秒
    if not BT_Addr:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
    
    # ============ 完成执行 "Perform Device Discovery for 5s" 会产生大约70行的数据, 才会读取到 "10 FF 53 02 01 00 00".
    ## Read Notification end buffer
    #the_Flag = False
    #for n in range(0,100,1): # 持续读 100*100=10000(毫秒)
    #    the_buffer = obj_bushound.Buffer_Control_Read(DevID=DevID_e3)
    #    if the_buffer[0]:
    #        if the_buffer[1]:
    #            if the_buffer[2].decode().startswith('10 FF 53 02 01 00 00'):
    #                the_Flag = True
    #                break
    #    wx.MilliSleep(milliseconds=100) # 延时100毫秒
    #if not the_Flag:
    #    Disable_wireless_notification_FCT(DevID_e, DevID_e3)
    #    return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3

    # Perform Device Pairing
    var_BT_Addr = ' '.join([BT_Addr[2*i:2*i+2] for i in range(len(BT_Addr)//2)])
    result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 FF 82 C1 01 00 {var_BT_Addr} 00 00', '10 FF 82 C1 00 00 00')
    if not result:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
    
    # Read connection buffer (Swallow 建议降低要求: 这里不卡关DevPID)
    for n in range(0,50,1): # 持续读 50*100=5000(毫秒)
        the_buffer = obj_bushound.Buffer_Control_Read(DevID=DevID_e3)
        if the_buffer[0]:
            if the_buffer[1]:
                if the_buffer[2].decode().startswith('10') and len(the_buffer[2].decode().split()) >= 7:
                    # if the_buffer[2].decode().split()[2:7] == ['41','10','02',DevPID[2:4],DevPID[0:2]]:
                    if the_buffer[2].decode().split()[2:5] == ['41','10','02']:
                        DevIdx = the_buffer[2].decode().split()[1]
                        break
        wx.MilliSleep(milliseconds=100) # 延时100毫秒
    if not DevIdx:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
        
    # Disable wireless notification
    Disable_wireless_notification_FCT(DevID_e, DevID_e3)
    
    return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
    
def UnlockRCV_Confirm_Pairing_KBD():
    DevIdx   = None
    DevID_e  = 0
    DevID_e1 = 0
    DevID_e2 = 0
    DevID_e3 = 0
    
    # Open Unlock RCV
    obj_bushound.Driver_Initialize()
    DevID_e  = obj_bushound.USB_OPENDEVICE(PID='C548', VID='046D')[2]
    DevID_e1 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID_e, EpNo=1)[2]
    DevID_e2 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID_e, EpNo=2)[2]
    DevID_e3 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID_e, EpNo=3)[2]
    
    # Unpair all devices(Slot 1 ~ Slot 6)
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 01 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 02 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 03 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 04 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 05 00')
    obj_bushound.USB_USBRequest(DevID=DevID_e, CommandList=f'{HIDPP_short} 11 FF 82 C1 03 06 00')    
    
    # Enable wireless notification
    result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP_short} 10 FF 80 00 00 01 00', '10 FF 80 00 00 00 00')
    if not result:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
        
    # Perform Device Discovery for 5s
    result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP_short} 10 FF 80 C0 05 01 00', '10 FF 80 C0 00 00 00')
    if not result:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
    
    # Get BT_Addr/RSSI (Swallow 建议降低要求: 这里不卡关DevPID)
    BT_Addr = ''
    RSSI    = ''
    for n in range(0,20,1):
        the_buffer = obj_bushound.Buffer_Control_Read(DevID=DevID_e3)
        if the_buffer[0]:
            if the_buffer[1]:
                if the_buffer[2].decode().startswith('11 FF 4F') and len(the_buffer[2].decode().split()) >= 20:
                    # if the_buffer[2].decode().split()[4:7] == ['00','00','10'] and the_buffer[2].decode().split()[8:10] == [DevPID[2:4], DevPID[0:2]]:
                    if the_buffer[2].decode().split()[4:7] == ['00','00','10']: 
                        the_ret = the_buffer[2].decode().split()
                        BT_Addr = ''.join(the_ret[10:16])
                        RSSI    = int(the_ret[19], 16)      # 十六进制转十进制
                        break
        wx.MilliSleep(milliseconds=100) # 延时100毫秒
    if not BT_Addr:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
    
    # ============ 完成执行 "Perform Device Discovery for 5s" 会产生大约70行的数据, 才会读取到 "10 FF 53 02 01 00 00".
    ## Read Notification end buffer
    #the_Flag = False
    #for n in range(0,100,1): # 持续读 100*100=10000(毫秒)
    #    the_buffer = obj_bushound.Buffer_Control_Read(DevID=DevID_e3)
    #    if the_buffer[0]:
    #        if the_buffer[1]:
    #            if the_buffer[2].decode().startswith('10 FF 53 02 01 00 00'):
    #                the_Flag = True
    #                break
    #    wx.MilliSleep(milliseconds=100) # 延时100毫秒
    #if not the_Flag:
    #    Disable_wireless_notification_FCT(DevID_e, DevID_e3)
    #    return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3

    # Perform Device Pairing
    var_BT_Addr = ' '.join([BT_Addr[2*i:2*i+2] for i in range(len(BT_Addr)//2)])
    result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 FF 82 C1 01 00 {var_BT_Addr} 00 00', '10 FF 82 C1 00 00 00')
    if not result:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
    
    # Read connection buffer (Swallow 建议降低要求: 这里不卡关DevPID)
    for n in range(0,50,1): # 持续读 50*100=5000(毫秒)
        the_buffer = obj_bushound.Buffer_Control_Read(DevID=DevID_e3)
        if the_buffer[0]:
            if the_buffer[1]:
                if the_buffer[2].decode().startswith('10') and len(the_buffer[2].decode().split()) >= 7:
                    # if the_buffer[2].decode().split()[2:7] == ['41','10','01',DevPID[2:4],DevPID[0:2]]:
                    if the_buffer[2].decode().split()[2:5] == ['41','10','01']:
                        DevIdx = the_buffer[2].decode().split()[1]
                        break
        wx.MilliSleep(milliseconds=100) # 延时100毫秒
    if not DevIdx:
        Disable_wireless_notification_FCT(DevID_e, DevID_e3)
        return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3
        
    # Disable wireless notification
    Disable_wireless_notification_FCT(DevID_e, DevID_e3)
    
    return DevIdx, DevID_e, DevID_e1, DevID_e2, DevID_e3

def Disable_wireless_notification_FCT(DevID_out:int, DevID_in:int):
    # Disable wireless notification
    result = HIDPlusPlusRequest_BufferRead(DevID_out, DevID_in, 100, 3000, f'{HIDPP_short} 10 FF 80 00 00 00 00', '10 FF 80 00 00 00 00')
    print('☆☆☆☆☆ [Here Done] Disable wireless notification')
    
def Post_B_FCT(DevID):
    frm.gauga_B.SetValue(pos=2)
    frm.status_B.SetLabel(label='Done')
    # obj_bushound.Buffer_Control_Clear()
    obj_bushound.Buffer_Control_Close()
    obj_bushound.USB_CLOSEDEVICE(DevID=DevID)
    
def Post_C_FCT(DevID):
    frm.gauga_C.SetValue(pos=2)
    frm.status_C.SetLabel(label='Done')
    # obj_bushound.Buffer_Control_Clear()
    obj_bushound.Buffer_Control_Close()
    obj_bushound.USB_CLOSEDEVICE(DevID=DevID)
   
class MyFrame(wx.Frame):

    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        self.Bind(event=wx.EVT_CLOSE, handler=self.OnExit_GUI)
        
        self.notebook = aui.AuiNotebook(self, agwStyle=aui.AUI_NB_TOP)  #|aui.AUI_NB_WINDOWLIST_BUTTON
        self.notebook.SetFont(font=wx.Font(pointSize=14, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        self.notebook.SetTabCtrlHeight(height=40)
        self.UTS2_bgc = '#A7CAF0'
        self.page_A = self.page_A()
        self.page_B = self.page_B()
        self.page_C = self.page_C()
        
        self.notebook.AddPage(page=self.page_A, caption='RCV')             
        self.notebook.AddPage(page=self.page_B, caption='Mouse')
        self.notebook.AddPage(page=self.page_C, caption='Keyboard')

        self.notebook.SetPageTextColour(page_idx=0, colour='Purple')
        self.notebook.SetPageTextColour(page_idx=1, colour='blue')
        self.notebook.SetPageTextColour(page_idx=2, colour='blue')
        
        if info_mouse:
            self.choice_B.SetSelection(n=0)
            self.Choice_B_FCT('')
        else:
            self.notebook.HidePage(page_idx=1, hidden=True) # 隐藏
        
        if info_keyboard:
            self.choice_C.SetSelection(n=0)
            self.Choice_C_FCT('')
        else:
            self.notebook.HidePage(page_idx=2, hidden=True) # 隐藏
        
    def page_A(self):
        panel_A = wx.Panel(self.notebook)
        panel_A.SetBackgroundColour((240,240,240))
        panel_A.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        text1 = wx.StaticText(panel_A, -1, 'Devices:')
        btn1  = wx.Button(panel_A, -1, 'Refresh')
        btn1.SetToolTip(tipString='Click me to scan out all logi devices(VID_046D)')
        btn1.Bind(wx.EVT_BUTTON, self.Refresh_FCT)
        btn1.SetFont(font=wx.Font(pointSize=8, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        hbox = wx.BoxSizer(wx.HORIZONTAL)  # wx.HORIZONTAL | wx.VERTICAL
        hbox.Add(text1, 0, wx.LEFT, 0)
        hbox.Add(btn1,  0, wx.LEFT, 5)
        
        self.list_ctrl_1 = wx.ListCtrl(panel_A, style=wx.LC_REPORT|wx.LC_SINGLE_SEL|wx.BORDER_SIMPLE)
        self.list_ctrl_1.SetHeaderAttr(attr=wx.ItemAttr(colText='purple', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI')))
        self.list_ctrl_1.InsertColumn(col=0, heading='All Devices', format=wx.LIST_FORMAT_LEFT, width=200)
        self.list_ctrl_1.Bind(wx.EVT_LIST_ITEM_SELECTED, self.LIST_ITEM_SELECTED_FCT_1)

        text2 = wx.StaticText(panel_A, -1, 'Features:')
        
        self.list_ctrl_2 = wx.ListCtrl(panel_A, style=wx.LC_REPORT|wx.LC_SINGLE_SEL|wx.BORDER_SIMPLE)
        self.list_ctrl_2.SetHeaderAttr(attr=wx.ItemAttr(colText='purple', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI')))
        self.list_ctrl_2.InsertColumn(col=0, heading='Available Features', format=wx.LIST_FORMAT_LEFT, width=200)
        self.list_ctrl_2.Bind(wx.EVT_LIST_ITEM_SELECTED, self.LIST_ITEM_SELECTED_FCT_2)
        
        vbox_A = wx.BoxSizer(wx.VERTICAL)  # wx.HORIZONTAL | wx.VERTICAL
        vbox_A.Add(hbox,             0, wx.TOP|wx.EXPAND, 5)
        vbox_A.Add(self.list_ctrl_1, 1, wx.TOP|wx.EXPAND, 5)
        vbox_A.Add(text2,            0, wx.TOP|wx.EXPAND, 5)
        vbox_A.Add(self.list_ctrl_2, 2, wx.TOP|wx.EXPAND, 5)
        
        self.panel_plus = wx.Panel(panel_A, style=wx.BORDER_SIMPLE)
        self.panel_plus.SetBackgroundColour((240,240,240))
        self.vbox_panel_plus = wx.BoxSizer(wx.VERTICAL)  # wx.HORIZONTAL | wx.VERTICAL
        self.panel_plus.SetSizer(self.vbox_panel_plus)
        
        hbox_panel_A = wx.BoxSizer(wx.HORIZONTAL)
        hbox_panel_A.Add(vbox_A,            1, wx.LEFT|wx.BOTTOM|wx.EXPAND, 5)
        hbox_panel_A.Add(self.panel_plus, 7, wx.LEFT|wx.BOTTOM|wx.EXPAND, 5)
        panel_A.SetSizer(hbox_panel_A)
        return panel_A
        
    def page_B(self):
        
        panel_B = wx.Panel(self.notebook)
        panel_B.SetBackgroundColour(self.UTS2_bgc)
        panel_B.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        
        self.gauga_B     = wx.Gauge(panel_B, -1, range=2, style=wx.GA_HORIZONTAL|wx.GA_PROGRESS)
        self.choice_B    = wx.Choice(panel_B, -1, choices=list(info_mouse.keys()))
        self.text_Ctrl_B = wx.TextCtrl(panel_B, -1, '', style=wx.BORDER_SIMPLE)
        self.text_Ctrl_B.SetForegroundColour('blue')
        btn_read_B       = wx.Button(panel_B, -1, 'Read')
        btn_clear_B      = wx.Button(panel_B, -1, 'Clear')
        self.tip_B       = wx.StaticText(panel_B, -1, '')                    
                        
        self.status_B = wx.StaticText(panel_B, -1, '', size=(150,50), style=wx.ALIGN_LEFT)
        self.status_B.SetFont(font=wx.Font(pointSize=24, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        self.status_B.SetForegroundColour('blue')
        #self.status_B.SetBackgroundColour('yellow')

        self.choice_B.Bind(wx.EVT_CHOICE, self.Choice_B_FCT)
        btn_read_B.Bind(wx.EVT_BUTTON, self.Read_UID_page_B)
        btn_clear_B.Bind(wx.EVT_BUTTON, self.Clear_page_B)
        
        hori_box_1 = wx.BoxSizer(wx.HORIZONTAL)
        hori_box_1.Add(self.text_Ctrl_B, 1, wx.LEFT, 0)
        hori_box_1.Add(btn_read_B,       0, wx.LEFT, 5)
        hori_box_1.Add(btn_clear_B,      0, wx.LEFT, 5)
        
        hori_box_2 = wx.BoxSizer(wx.HORIZONTAL)
        hori_box_2.Add(self.tip_B,       1, wx.LEFT, 0)
        hori_box_2.Add(self.status_B,    0, wx.LEFT, 0)
        
        staticBox      = wx.StaticBox(panel_B, label='UID')
        staticBoxSizer = wx.StaticBoxSizer(box=staticBox, orient=wx.VERTICAL)
        staticBoxSizer.Add(self.choice_B, 0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 5)
        staticBoxSizer.Add(hori_box_1,    0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 5)
        staticBoxSizer.Add(hori_box_2,    0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 5)
        
        self.pic_show_B = wx.StaticBitmap(panel_B, -1, bitmap=wx.NullBitmap)
        #self.pic_show_B.SetBackgroundColour('tan')
        
        self.vbox_B = wx.BoxSizer(wx.VERTICAL)
        self.vbox_B.Add(self.gauga_B,    0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 10)
        self.vbox_B.Add(staticBoxSizer,  0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 10)
        self.vbox_B.Add(self.pic_show_B, 1, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 10)
        
        panel_B.SetSizer(sizer=self.vbox_B)
        
        return panel_B
            
    def page_C(self):
        
        panel_C = wx.Panel(self.notebook)
        panel_C.SetBackgroundColour(self.UTS2_bgc)
        panel_C.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        
        self.gauga_C     = wx.Gauge(panel_C, -1, range=2, style=wx.GA_HORIZONTAL|wx.GA_PROGRESS)
        self.choice_C    = wx.Choice(panel_C, -1, choices=list(info_keyboard.keys()))
        self.text_Ctrl_C = wx.TextCtrl(panel_C, -1, '', style=wx.BORDER_SIMPLE)
        self.text_Ctrl_C.SetForegroundColour('blue')
        btn_read_C       = wx.Button(panel_C, -1, 'Read')
        btn_clear_C      = wx.Button(panel_C, -1, 'Clear')
        self.tip_C       = wx.StaticText(panel_C, -1, '')                    
                        
        self.status_C = wx.StaticText(panel_C, -1, '', size=(150,50), style=wx.ALIGN_LEFT)
        self.status_C.SetFont(font=wx.Font(pointSize=24, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        self.status_C.SetForegroundColour('blue')
        #self.status_C.SetBackgroundColour('yellow')

        self.choice_C.Bind(wx.EVT_CHOICE, self.Choice_C_FCT)
        btn_read_C.Bind(wx.EVT_BUTTON, self.Read_UID_page_C)
        btn_clear_C.Bind(wx.EVT_BUTTON, self.Clear_page_C)
        
        hori_box_1 = wx.BoxSizer(wx.HORIZONTAL)
        hori_box_1.Add(self.text_Ctrl_C, 1, wx.LEFT, 0)
        hori_box_1.Add(btn_read_C,       0, wx.LEFT, 5)
        hori_box_1.Add(btn_clear_C,      0, wx.LEFT, 5)
        
        hori_box_2 = wx.BoxSizer(wx.HORIZONTAL)
        hori_box_2.Add(self.tip_C,       1, wx.LEFT, 0)
        hori_box_2.Add(self.status_C,    0, wx.LEFT, 0)
        
        staticBox      = wx.StaticBox(panel_C, label='UID')
        staticBoxSizer = wx.StaticBoxSizer(box=staticBox, orient=wx.VERTICAL)
        staticBoxSizer.Add(self.choice_C, 0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 5)
        staticBoxSizer.Add(hori_box_1,    0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 5)
        staticBoxSizer.Add(hori_box_2,    0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 5)
        
        self.pic_show_C = wx.StaticBitmap(panel_C, -1, bitmap=wx.NullBitmap)
        #self.pic_show_C.SetBackgroundColour('tan')
        
        self.vbox_C = wx.BoxSizer(wx.VERTICAL)
        self.vbox_C.Add(self.gauga_C,    0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 10)
        self.vbox_C.Add(staticBoxSizer,  0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 10)
        self.vbox_C.Add(self.pic_show_C, 1, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 10)
        
        panel_C.SetSizer(sizer=self.vbox_C)
        
        return panel_C
        
    def Refresh_FCT(self, evt):
        # 清除上次结果
        self.list_ctrl_1.DeleteAllItems()
        self.list_ctrl_2.DeleteAllItems()
        self.vbox_panel_plus.Clear(delete_windows=True)
        
        # 更新最新结果
        now_RCV = all_usbcontrollerdevice()
        for n, each_RCV in enumerate(now_RCV, 0):
            self.list_ctrl_1.InsertItem(index=n, label=each_RCV)
            
    def LIST_ITEM_SELECTED_FCT_1(self, evt):
        # 清除上次结果
        self.list_ctrl_2.DeleteAllItems()
        self.vbox_panel_plus.Clear(delete_windows=True)
        
        # 更新最新结果
        index_focus  = self.list_ctrl_1.GetFocusedItem()
        self.now_RCV = self.list_ctrl_1.GetItemText(item=index_focus, col=0)
        print(f'index: {index_focus}, now_RCV: {self.now_RCV}')
        if self.now_RCV in RCV_mgmt.keys():
            features = RCV_mgmt[self.now_RCV]
            for n, each_feature in enumerate(features, 0):
                self.list_ctrl_2.InsertItem(index=n, label=each_feature)
        else:
            pass
        
    def LIST_ITEM_SELECTED_FCT_2(self, evt):
        # 清除上次结果
        self.vbox_panel_plus.Clear(delete_windows=True)
        
        # 更新最新结果
        index_focus      = self.list_ctrl_2.GetFocusedItem()
        self.now_feature = self.list_ctrl_2.GetItemText(item=index_focus, col=0)
        print(f'index: {index_focus}, now_feature: {self.now_feature}')
        
        self.gauga_A = wx.Gauge(self.panel_plus, -1, range=2, style=wx.GA_HORIZONTAL|wx.GA_PROGRESS)
        the_label = self.now_feature + ':'
        #if self.now_feature == 'UID':
        #    the_suffix = ''
        #    if self.now_RCV in ['C52F', 'C534']:
        #        the_suffix = 'A00->A07'
        #    elif self.now_RCV in ['C547', 'C548']:
        #        the_suffix = 'A00~A07'
        #    elif self.now_RCV in ['C52B', 'C539', 'C53F', 'C53D']:
        #        the_suffix = 'A01~A07'
        #    the_label = the_label + '\n' + the_suffix
        show_text = wx.StaticText(self.panel_plus, -1, f'{the_label}', style=wx.BORDER_NONE)
        self.textCtrl_feature = wx.TextCtrl(self.panel_plus, -1, '', style=wx.BORDER_SIMPLE)
        btn_1 = wx.Button(self.panel_plus, -1, 'Read')
        btn_1.Bind(wx.EVT_BUTTON, self.Read_UID_page_A)
        btn_2 = wx.Button(self.panel_plus, -1, 'Clear')
        btn_2.Bind(wx.EVT_BUTTON, self.Clear_page_A)
        
        hbox_result = wx.BoxSizer(wx.HORIZONTAL)  # wx.HORIZONTAL | wx.VERTICAL
        hbox_result.Add(show_text,             0, wx.LEFT, 0)
        hbox_result.Add(self.textCtrl_feature, 1, wx.LEFT, 5)
        hbox_result.Add(btn_1,                 0, wx.LEFT, 5)
        hbox_result.Add(btn_2,                 0, wx.LEFT, 5)
        
        self.vbox_panel_plus.Add(self.gauga_A, 0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 10)
        self.vbox_panel_plus.Add(hbox_result,  0, wx.LEFT|wx.RIGHT|wx.TOP|wx.EXPAND, 10)
        self.vbox_panel_plus.Layout()

    def Choice_B_FCT(self, evt):
        self.gauga_B.SetValue(pos=0)
        self.text_Ctrl_B.Clear()
        self.status_B.SetLabel('')
        
        now_project = self.choice_B.StringSelection
        print('now_project:', now_project)
        
        # 必定更新注意事项
        now_category = info_mouse[now_project]['Category']
        the_tip = ''
        if now_category in ['MSE_ROM', 'MSE_FLASH']:
            the_tip = 'Tip:\n1.Please use "Gothard RCV(FW35)" to read out Mouse UID.\n2.Quickly Power on Mouse'
        elif now_category == 'MSE_BLE':
            the_tip = 'Tip:\n1.Please use "Special RCV(Unlock)" to read out Mouse UID.\n2.Power on Mouse and make Mouse in Discovery Mode.'
        elif now_category == 'KBD_BLE':
            the_tip = 'Tip:\n1.Please use "Special RCV(Unlock)" to read out Keyboard UID.\n2.Power on Keyboard and make Keyboard in Discovery Mode.'
        self.tip_B.SetLabel(the_tip)
        
        # 必定更新图片显示
        image_path = os.path.join('images', now_project+'.png')
        if os.path.isfile(image_path):
            the_image = wx.Image(image_path)
            the_label = wx.Bitmap(the_image)
            the_tooltip = '\n'.join(info_mouse[now_project]['Description'].split(','))
        else:
            the_label = wx.NullBitmap
            the_tooltip = ''
        self.pic_show_B.SetBitmap(label=the_label)
        self.pic_show_B.SetToolTip(tipString=the_tooltip)
        self.vbox_B.Layout()
        
    def Choice_C_FCT(self, evt):
        self.gauga_C.SetValue(pos=0)
        self.text_Ctrl_C.Clear()
        self.status_C.SetLabel('')
        
        now_project = self.choice_C.StringSelection
        print('now_project:', now_project)
        
        # 必定更新注意事项
        now_category = info_keyboard[now_project]['Category']
        the_tip = ''
        if now_category == 'KBD_BLE':
            the_tip = 'Tip:\n1.Please use "Special RCV(Unlock)" to read out Keyboard UID.\n2.Power on Keyboard and make Keyboard in Discovery Mode.'
        self.tip_C.SetLabel(the_tip)
        
        # 必定更新图片显示
        image_path = os.path.join('images', now_project+'.png')
        if os.path.isfile(image_path):
            the_image = wx.Image(image_path)
            the_label = wx.Bitmap(the_image)
            the_tooltip = '\n'.join(info_keyboard[now_project]['Description'].split(','))
        else:
            the_label = wx.NullBitmap
            the_tooltip = ''
        self.pic_show_C.SetBitmap(label=the_label)
        self.pic_show_C.SetToolTip(tipString=the_tooltip)
        self.vbox_C.Layout()
        
    def Read_UID_page_A(self, evt):
        self.gauga_A.SetValue(pos=0)
        self.textCtrl_feature.Clear()
        UID = ''
        FW_ = ''
        
        obj_bushound.Driver_Initialize()
        DevID  = obj_bushound.USB_OPENDEVICE(PID=self.now_RCV, VID='046D')[2]
        DevID1 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID, EpNo=1)[2]
        DevID2 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID, EpNo=2)[2]
        DevID3 = obj_bushound.USB_GetIDByEpNo(ParentID=DevID, EpNo=3)[2]
        self.gauga_A.SetValue(pos=1)
        
        if self.now_RCV in ['C52F','C534']:
            if self.now_feature == 'UID':
                the_buffer = HIDPlusPlusRequest_BufferRead(DevID_out=DevID,
                                                            DevID_in=DevID2, 
                                                            the_timeout=100,
                                                            the_CMDTimeout=3000,
                                                            the_CommandList='21 09 10 02 01 00 07 00 10 FF 83 D5 00 00 00',
                                                            the_min='11 FF 83 D5 00')
                if the_buffer and len(the_buffer.split()) >= 20:
                    UID = ''.join(the_buffer.split()[5:13])
                    
                print('Here RCV UID:', UID)
                self.textCtrl_feature.SetValue(UID)
                
        elif self.now_RCV in ['C547','C548']:           
            # ++ ============ 'Bolt' 即Mezzi接收器比较特殊,需要每次输入密码. ============ ++
            if self.now_RCV == 'C548':              
                # Enable manufacturing mode
                ret = HIDPlusPlusRequest_BufferRead(DevID_out=DevID, DevID_in=DevID3, the_timeout=100, the_CMDTimeout=3000,
                                            the_CommandList=f'{HIDPP_short} 10 FF 80 D0 01 00 00',
                                            the_min='10 FF 80 D0 00 00 00')
                if not ret:
                    self.gauga_A.SetValue(pos=2)
                    return
                    
                # Read Deactivatable features state
                ret = HIDPlusPlusRequest_BufferRead(DevID_out=DevID, DevID_in=DevID3, the_timeout=100, the_CMDTimeout=3000,
                                            the_CommandList=f'{HIDPP_short} 10 FF 81 F9 00 00 00',
                                            the_min='10 FF 81 F9 01 00 0')
                if not ret:
                    self.gauga_A.SetValue(pos=2)
                    return
                    
                # Start Session - x1E02_Manuf
                ret = HIDPlusPlusRequest_BufferRead(DevID_out=DevID, DevID_in=DevID3, the_timeout=100, the_CMDTimeout=3000,
                                            the_CommandList='21 09 10 02 02 00 14 00 11 FF 82 F7 ' + var_x1E02_Manuf,
                                            the_min='10 FF 82 F7 01 00 00')
                if not ret:
                    self.gauga_A.SetValue(pos=2)
                    return
                
                # Provide Password - RcvManuf_PWD
                ret = HIDPlusPlusRequest_BufferRead(DevID_out=DevID, DevID_in=DevID3, the_timeout=100, the_CMDTimeout=3000,
                                            the_CommandList='21 09 10 02 02 00 14 00 11 FF 82 F8 ' + var_RcvManuf_PWD,
                                            the_min='10 FF 82 F8 02 00 00')
                if not ret:
                    self.gauga_A.SetValue(pos=2)
                    return
                    
                # enable Features
                ret = HIDPlusPlusRequest_BufferRead(DevID_out=DevID, DevID_in=DevID3, the_timeout=100, the_CMDTimeout=3000,
                                            the_CommandList=f'{HIDPP_short} 10 FF 80 FA 80 00 00',
                                            the_min='10 FF 80 FA 00 00 00')
                if not ret:
                    self.gauga_A.SetValue(pos=2)
                    return
                    
                # Read Deactivatable features state
                ret = HIDPlusPlusRequest_BufferRead(DevID_out=DevID, DevID_in=DevID3, the_timeout=100, the_CMDTimeout=3000,
                                            the_CommandList=f'{HIDPP_short} 10 FF 81 F9 00 00 00',
                                            the_min='10 FF 81 F9 01 00 01')
                if not ret:
                    self.gauga_A.SetValue(pos=2)
                    return
                    
            if self.now_feature == 'UID':
                A00,A01,A02,A03,A04,A05,A06,A07 = '','','','','','','','',
                for each_AA in ['00','01','02','03','04','05','06','07']:
                    one_byte = ''
                    the_buffer = HIDPlusPlusRequest_BufferRead(DevID_out=DevID,
                                                            DevID_in=DevID3, 
                                                            the_timeout=100,
                                                            the_CMDTimeout=3000,
                                                            the_CommandList=f'{HIDPP_short} 10 FF 81 D4 ' + each_AA + ' 00 00',
                                                            the_min='10 FF 81 D4')
                    if the_buffer and len(the_buffer.split()) >= 7:
                        one_byte = the_buffer.split()[6]
                        if each_AA == '00':
                            A00 = one_byte
                        elif each_AA == '01':
                            A01 = one_byte
                        elif each_AA == '02':
                            A02 = one_byte
                        elif each_AA == '03':
                            A03 = one_byte
                        elif each_AA == '04':
                            A04 = one_byte
                        elif each_AA == '05':
                            A05 = one_byte
                        elif each_AA == '06':
                            A06 = one_byte
                        elif each_AA == '07':
                            A07 = one_byte
                    if not one_byte:
                        break
                        
                UID = A00 + A01 + A02 + A03 + A04 + A05 + A06 + A07
                print('Here RCV UID:', UID)           
                self.textCtrl_feature.SetValue(UID)
            
        elif self.now_RCV in ['C52B','C539','C53F','C53D']:
            if self.now_feature == 'UID':    
                A01,A02,A03,A04,A05,A06,A07 = '','','','','','','',
                for each_AA in ['01','02','03','04','05','06','07']:
                    one_byte = ''
                    the_buffer = HIDPlusPlusRequest_BufferRead(DevID_out=DevID,
                                                            DevID_in=DevID3, 
                                                            the_timeout=100,
                                                            the_CMDTimeout=3000,
                                                            the_CommandList=f'{HIDPP_short} 10 FF 81 D4 ' + each_AA + ' 00 00',
                                                            the_min='10 FF 81 D4')
                    if the_buffer and len(the_buffer.split()) >= 7:
                        one_byte = the_buffer.split()[6]
                        if each_AA == '01':
                            A01 = one_byte
                        elif each_AA == '02':
                            A02 = one_byte
                        elif each_AA == '03':
                            A03 = one_byte
                        elif each_AA == '04':
                            A04 = one_byte
                        elif each_AA == '05':
                            A05 = one_byte
                        elif each_AA == '06':
                            A06 = one_byte
                        elif each_AA == '07':
                            A07 = one_byte
                    if not one_byte:
                        break
                        
                UID = A01 + A02 + A03 + A04 + A05 + A06 + A07
                print('Here RCV UID:', UID)
                self.textCtrl_feature.SetValue(UID)
        
        elif self.now_RCV in ['F013']:
            if self.now_feature == 'FW_Build':
                result = HIDPlusPlusRequest_BufferRead(DevID, DevID3, 100, 3000, f'{HIDPP_short} 10 FF 81 F1 02 00 00', '10 FF 81 F1 02 00')
                if result:
                    FW_ = result.split()[6]
                self.textCtrl_feature.SetValue(FW_)
                
        self.gauga_A.SetValue(pos=2)
        
        # obj_bushound.Buffer_Control_Clear()
        obj_bushound.Buffer_Control_Close()
        obj_bushound.USB_CLOSEDEVICE(DevID=DevID)
            
    def Read_UID_page_B(self, evt):
        self.gauga_B.SetValue(pos=0)
        self.text_Ctrl_B.Clear()
        self.status_B.SetLabel('')
        
        current_project = self.choice_B.StringSelection
        print('current_project:', current_project)
        if not current_project:
            return
            
        current_category     = info_mouse[current_project]['Category']
        current_eQuad_ID     = info_mouse[current_project]['eQuad_ID']
        current_DevManuf_PWD = info_mouse[current_project]['DevManuf_PWD']
        
        if current_category == 'MSE_ROM':
            if 'F013' not in all_usbcontrollerdevice():
                wx.MessageBox(message=f'Find no Gothard RCV(FW35)\n\nPlease firstly insert Gothard RCV(FW35)\nPID: F013', caption='myWarning', style=wx.ICON_WARNING)
                return
            
            UID = ''
            self.text_Ctrl_B.Clear()

            self.status_B.SetLabel('Pairing ...')
            ret = GothardRCV_Confirm_Pairing(eQuad_ID=current_eQuad_ID)
            self.gauga_B.SetValue(pos=1)
            MSE_Address = ret[0]
            DevID       = ret[1]
            DevID1      = ret[2]
            DevID2      = ret[3]
            DevID3      = ret[4]
            
            if MSE_Address:
                self.status_B.SetLabel('Reading ...')
                UID = MSE_Address
                
            print('MSE_Address:', MSE_Address)
            print(f'"{current_project}" UID:', UID)
            self.text_Ctrl_B.SetValue(UID)
            Post_B_FCT(DevID)
            
        elif current_category == 'MSE_FLASH':
            if 'F013' not in all_usbcontrollerdevice():
                wx.MessageBox(message=f'Find no Gothard RCV(FW35)\n\nPlease firstly insert Gothard RCV(FW35)\nPID: F013', caption='myWarning', style=wx.ICON_WARNING)
                return
            
            UID                = ''
            Index_EnableHidden = ''
            Index_EEPROM       = ''
            self.text_Ctrl_B.Clear()
            
            self.status_B.SetLabel('Pairing ...')
            ret = GothardRCV_Confirm_Pairing(eQuad_ID=current_eQuad_ID)
            self.gauga_B.SetValue(pos=1)
            MSE_Address = ret[0]
            DevID       = ret[1]
            DevID1      = ret[2]
            DevID2      = ret[3]
            DevID3      = ret[4]
            
            if MSE_Address:
                self.status_B.SetLabel('Reading ...')
                # get feature 1e00 EnableHidden
                result = HIDPlusPlusRequest_BufferRead(DevID, DevID3, 100, 3000, f'{HIDPP} 11 01 00 00 1e 00 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_EnableHidden = result.split()[4]
                else:
                    Post_B_FCT(DevID)
                    return
                    
                # get feature 1eb0 AccessMem
                result = HIDPlusPlusRequest_BufferRead(DevID, DevID3, 100, 3000, f'{HIDPP} 11 01 00 00 1e b0 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_EEPROM = result.split()[4]
                else:
                    Post_B_FCT(DevID)
                    return
                
                # Enable Hidden Feature
                result = HIDPlusPlusRequest_BufferRead(DevID, DevID3, 100, 3000, f'{HIDPP} 11 01 {Index_EnableHidden} 1F 01 00', '11 01 10 1F')
                if result:
                    pass
                else:
                    Post_B_FCT(DevID)
                    return
                    
                # Read UID
                result = HIDPlusPlusRequest_BufferRead(DevID, DevID3, 100, 3000, f'{HIDPP} 11 01 {Index_EEPROM} 2F 00 08', '11 01 11 2F 00')
                if result and len(result.split()) >= 20:
                    UID = f'{''.join(result.split()[6:8])}-{''.join(result.split()[8:10])}-{''.join(result.split()[10:14])}'
                    
            print('MSE_Address:', MSE_Address)
            print(f'"{current_project}" UID:', UID)     
            self.text_Ctrl_B.SetValue(UID)
            Post_B_FCT(DevID)
            
        elif current_category == 'MSE_BLE':
            if 'C548' not in all_usbcontrollerdevice():
                wx.MessageBox(message=f'Find no Special RCV(Unlock)\n\nPlease firstly insert Special RCV(Unlock)\nPID: C548', caption='myWarning', style=wx.ICON_WARNING)
                return
            
            wx.MessageBox(message=f'Attention Please\n\nThe mouse will be forcely unpaired with its original paired RCV', caption='Info.', style=wx.ICON_INFORMATION)
            
            UID                              = ''
            Index_EnableHidden_BLEPro        = ''
            Index_ManageDeactivatable_BLEPro = ''
            Index_PWDAuthenticate_BLEPro     = ''
            Index_EEPROM_BLEPro              = ''
            self.text_Ctrl_B.Clear()
            
            self.status_B.SetLabel('Pairing ...')
            ret      = UnlockRCV_Confirm_Pairing_MSE()
            self.gauga_B.SetValue(pos=1)
            DevIdx   = ret[0]
            DevID_e  = ret[1]
            DevID_e1 = ret[2]
            DevID_e2 = ret[3]
            DevID_e3 = ret[4]
            
            if DevIdx:
                self.status_B.SetLabel('Reading ...')
                # get feature 1e00 EnableHidden
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} 00 00 1e 00 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_EnableHidden_BLEPro = result.split()[4]
                else:
                    Post_B_FCT(DevID_e)
                    return
                    
                # get feature 1e02 Deactivate Feature
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} 00 00 1e 02 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_ManageDeactivatable_BLEPro = result.split()[4]
                else:
                    Post_B_FCT(DevID_e)
                    return
                    
                # get feature 1602 PWD Authentication
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} 00 00 16 02 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_PWDAuthenticate_BLEPro = result.split()[4]
                else:
                    Post_B_FCT(DevID_e)
                    return
                
                # get feature 1eb0 AccessMem
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} 00 00 1e b0 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_EEPROM_BLEPro = result.split()[4]
                else:
                    Post_B_FCT(DevID_e)
                    return
                
                # Enable Hidden Feature
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_EnableHidden_BLEPro} 10 01', f'11 {DevIdx} {Index_EnableHidden_BLEPro} 10 00')
                if result:
                    pass
                else:
                    Post_B_FCT(DevID_e)
                    return
                
                # ++======================== Enable Gothard ========================++
                DevManuf_PWD      = current_DevManuf_PWD
                var_DevManuf_PWD  = ' '.join([DevManuf_PWD[2*i:2*i+2] for i in range(len(DevManuf_PWD)//2)])
                
                # Authentication-Start Gothard Session
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 00 {var_x1E02_Gothard}', f'11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 00 01')
                if result:
                    pass
                else:
                    Post_B_FCT(DevID_e)
                    return
                # Authentication-Provide PWD
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 20 {var_DevManuf_PWD}',  f'11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 20 02')
                if result:
                    pass
                else:
                    Post_B_FCT(DevID_e)
                    return
                # Manage Deactivatable features-Enable Gothard
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 20 04',              f'11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 20 00')
                if result:
                    pass
                else:
                    Post_B_FCT(DevID_e)
                    return
                # Manage Deactivatable features-GetInfo
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 00 00',              f'11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 00 07 04 04')
                if result:
                    pass
                else:
                    Post_B_FCT(DevID_e)
                    return
                
                # ++======================== Enable TDE commands to Mouse ========================++
                # Authentication-Start Manuf Session
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 00 {var_x1E02_Manuf}',  f'11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 00 01')
                if result:
                    pass
                else:
                    Post_B_FCT(DevID_e)
                    return
                # Authentication-Provide PWD
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 20 {var_DevManuf_PWD}',  f'11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 20 02')
                if result:
                    pass
                else:
                    Post_B_FCT(DevID_e)
                    return
                # Manage Deactivatable features-Enable Manuf
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 20 01',              f'11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 20 00')
                if result:
                    pass
                else:
                    Post_B_FCT(DevID_e)
                    return
                    
                # Read UID
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_EEPROM_BLEPro} 20 00 08', f'11 {DevIdx} {Index_EEPROM_BLEPro} 20 00')
                if result and len(result.split()) >= 20:
                    UID = ''.join(result.split()[6:14])
            
            print('DevIdx:', DevIdx)
            print(f'"{current_project}" UID:', UID)
            self.text_Ctrl_B.SetValue(UID)
            Post_B_FCT(DevID_e)
            
    def Read_UID_page_C(self, evt):
        self.gauga_C.SetValue(pos=0)
        self.text_Ctrl_C.Clear()
        self.status_C.SetLabel('')
        
        current_project = self.choice_C.StringSelection
        print('current_project:', current_project)
        if not current_project:
            return
            
        current_category     = info_keyboard[current_project]['Category']
        current_eQuad_ID     = info_keyboard[current_project]['eQuad_ID']
        current_DevManuf_PWD = info_keyboard[current_project]['DevManuf_PWD']
        
        if current_category == 'KBD_BLE':
            if 'C548' not in all_usbcontrollerdevice():
                wx.MessageBox(message=f'Find no Special RCV(Unlock)\n\nPlease firstly insert Special RCV(Unlock)\nPID: C548', caption='myWarning', style=wx.ICON_WARNING)
                return
            
            wx.MessageBox(message=f'Attention Please\n\nThe keyboard will be forcely unpaired with its original paired RCV', caption='Info.', style=wx.ICON_INFORMATION)
            
            UID                              = ''
            Index_EnableHidden_BLEPro        = ''
            Index_ManageDeactivatable_BLEPro = ''
            Index_PWDAuthenticate_BLEPro     = ''
            Index_EEPROM_BLEPro              = ''
            self.text_Ctrl_B.Clear()
            
            self.status_C.SetLabel('Pairing ...')
            ret      = UnlockRCV_Confirm_Pairing_KBD()
            self.gauga_C.SetValue(pos=1)
            DevIdx   = ret[0]
            DevID_e  = ret[1]
            DevID_e1 = ret[2]
            DevID_e2 = ret[3]
            DevID_e3 = ret[4]
            
            if DevIdx:
                self.status_C.SetLabel('Reading ...')
                # get feature 1e00 EnableHidden
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} 00 00 1e 00 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_EnableHidden_BLEPro = result.split()[4]
                else:
                    Post_C_FCT(DevID_e)
                    return
                    
                # get feature 1e02 Deactivate Feature
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} 00 00 1e 02 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_ManageDeactivatable_BLEPro = result.split()[4]
                else:
                    Post_C_FCT(DevID_e)
                    return
                    
                # get feature 1602 PWD Authentication
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} 00 00 16 02 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_PWDAuthenticate_BLEPro = result.split()[4]
                else:
                    Post_C_FCT(DevID_e)
                    return
                
                # get feature 1eb0 AccessMem
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} 00 00 1e b0 00 00 00', '11 01 00 00')
                if result and len(result.split()) >= 20:
                    Index_EEPROM_BLEPro = result.split()[4]
                else:
                    Post_C_FCT(DevID_e)
                    return
                
                # Enable Hidden Feature
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_EnableHidden_BLEPro} 10 01', f'11 {DevIdx} {Index_EnableHidden_BLEPro} 10 00')
                if result:
                    pass
                else:
                    Post_C_FCT(DevID_e)
                    return
                
                # ++======================== Enable Gothard ========================++
                DevManuf_PWD      = current_DevManuf_PWD
                var_DevManuf_PWD  = ' '.join([DevManuf_PWD[2*i:2*i+2] for i in range(len(DevManuf_PWD)//2)])
                
                # Authentication-Start Gothard Session
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 00 {var_x1E02_Gothard}', f'11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 00 01')
                if result:
                    pass
                else:
                    Post_C_FCT(DevID_e)
                    return
                # Authentication-Provide PWD
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 20 {var_DevManuf_PWD}',  f'11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 20 02')
                if result:
                    pass
                else:
                    Post_C_FCT(DevID_e)
                    return
                # Manage Deactivatable features-Enable Gothard
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 20 04',              f'11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 20 00')
                if result:
                    pass
                else:
                    Post_C_FCT(DevID_e)
                    return
                # Manage Deactivatable features-GetInfo
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 00 00',              f'11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 00 07 04 04')
                if result:
                    pass
                else:
                    Post_C_FCT(DevID_e)
                    return
                
                # ++======================== Enable TDE commands to Mouse ========================++
                # Authentication-Start Manuf Session
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 00 {var_x1E02_Manuf}',  f'11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 00 01')
                if result:
                    pass
                else:
                    Post_C_FCT(DevID_e)
                    return
                # Authentication-Provide PWD
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 20 {var_DevManuf_PWD}',  f'11 {DevIdx} {Index_PWDAuthenticate_BLEPro} 20 02')
                if result:
                    pass
                else:
                    Post_C_FCT(DevID_e)
                    return
                # Manage Deactivatable features-Enable Manuf
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 20 01',              f'11 {DevIdx} {Index_ManageDeactivatable_BLEPro} 20 00')
                if result:
                    pass
                else:
                    Post_C_FCT(DevID_e)
                    return
                    
                # Read UID
                result = HIDPlusPlusRequest_BufferRead(DevID_e, DevID_e3, 100, 3000, f'{HIDPP} 11 {DevIdx} {Index_EEPROM_BLEPro} 20 00 08', f'11 {DevIdx} {Index_EEPROM_BLEPro} 20 00')
                if result and len(result.split()) >= 20:
                    UID = ''.join(result.split()[6:14])
            
            print('DevIdx:', DevIdx)
            print(f'"{current_project}" UID:', UID)
            self.text_Ctrl_C.SetValue(UID)
            Post_C_FCT(DevID_e)
        
    def Clear_page_A(self, evt):
        self.gauga_A.SetValue(pos=0)
        self.textCtrl_feature.Clear()
        self.textCtrl_feature.SetFocus()
        obj_bushound.Buffer_Control_Clear()
        obj_bushound.Device_UnselectAll()
        
    def Clear_page_B(self, evt):
        self.gauga_B.SetValue(pos=0)
        self.text_Ctrl_B.Clear()
        self.status_B.SetLabel('')
        self.text_Ctrl_B.SetFocus()
        obj_bushound.Buffer_Control_Clear()
        obj_bushound.Device_UnselectAll()
        
    def Clear_page_C(self, evt):
        self.gauga_C.SetValue(pos=0)
        self.text_Ctrl_C.Clear()
        self.status_C.SetLabel('')
        self.text_Ctrl_C.SetFocus()
        obj_bushound.Buffer_Control_Clear()
        obj_bushound.Device_UnselectAll()
                
    def OnExit_GUI(self, event):
        obj_bushound.Device_UnselectAll()
        obj_bushound.Driver_Release()
        self.Destroy()
        sys.exit()

if __name__ == '__main__':
    
    app = wx.App()
    
    
            
    # ====================================== 载入dll
    dll_file = 'UTS2_Drivers.dll'
    #dll_file = 'UTS_Drivers_64.dll'
    abs_path = os.path.abspath('')
    dll_path = os.path.join(abs_path, dll_file)
    if not os.path.isfile(dll_path):
        dll_path = os.path.join(r'C:\UTS2.0\dll', dll_file)
        if not os.path.isfile(dll_path):
            wx.MessageBox(message=f'Find no dll file below\n\n{dll_file}', caption='myWarning', style=wx.ICON_WARNING)
            sys.exit()
    
    obj_bushound = MyBushound(dll=dll_path)
    obj_bushound.Driver_Initialize()
    obj_bushound.Buffer_Control_Open(iIfExport=0)
    
    # ====================================== main UI
    frm = MyFrame(None, title=f'{app_name}({latest_ver})    Developper: logi SEG TDE    (For GTECH_VN Use Only)', size=(800,600))
    frm.Center()
    frm.Show()
    app.MainLoop()