import wx
import wx.adv
import wx.lib.plot as wxPyPlot
import numpy as np
import wx.grid as grid
import shutil
import traceback
import os
import sys
import socket
import csv
import math
import copy
import chardet
import datetime
import win32api
import pandas as pd
import wx.lib.buttons as buttons
import wx.lib.agw.speedmeter as SM
import wx.lib.agw.aquabutton as AB
from getpass import getuser
from wx.lib.embeddedimage import PyEmbeddedImage
from fpdf import FPDF
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.figure import Figure

"""
重要的心得1: (关于保持原整数, 原浮点数)
aa_str   = '2.4'
aa_float = float(aa_str)
aa       = int(aa_float) if int(aa_float) == aa_float else aa_float

重要的心得2: (关于int())
int(0)      # 0
int('567')  # 567
int(56.7)   # 56
int('56.7') # 报错,ValueError: invalid literal for int() with base 10: '56.7'

重要的心得3: (关于Python中的'nan', 'inf', '-inf', 不区分大小写'NAN', 'INF', '-INF')
if final_Cpk == 'nan':      # float('nan') < 1.33, ==> False
    final_Cpk = ''          # 特别注意: float('') < 1.33, ==> 报错: ValueError: could not convert string to float: ''
elif final_Cpk == 'inf':    # float('inf') < 1.33, ==> False
    final_Cpk = '∞'         # 特别注意: float('∞') < 1.33, ==> 报错: ValueError: could not convert string to float: '∞'
elif final_Cpk == '-inf':   # float('-inf') < 1.33, ==> True
    final_Cpk = '-∞'        # 特别注意: float('-∞') < 1.33, ==> 报错: ValueError: could not convert string to float: '-∞'
另外, 判断一个数是有理数的方法如下:
if not any([math.isnan(final_ax1_yTop), math.isinf(final_ax1_yTop)])

重要的心得4: 内置函数eval()的函数原型：eval(source, globals=None, locals=None, /)
aa = '2.4'
aa = eval(aa)  # -> 浮点数: 2.4

重要的心得5: 变量关系
full_vars_with_limits >= final_vars_with_limits >= self.final_var_options
"""

# ============ 版本记录
first_ver  = 'Ver: 1.0.23.611'
latest_ver = 'Ver: 1.0.25.1212'
app_name   = 'myAnalysis'

reserved             = {0:'{:.0f}', 1:'{:.1f}', 2:'{:.2f}', 3:'{:.3f}', 4:'{:.4f}', 5:'{:.5f}',
                        6:'{:.6f}', 7:'{:.7f}', 8:'{:.8f}', 9:'{:.9f}',}

reserved_scientific  = {0:'{:.0E}', 1:'{:.1E}', 2:'{:.2E}', 3:'{:.3E}', 4:'{:.4E}', 5:'{:.5E}',
                        6:'{:.6E}', 7:'{:.7E}', 8:'{:.8E}', 9:'{:.9E}',}

reserved_percent     = {0:'{:.0%}', 1:'{:.1%}', 2:'{:.2%}', 3:'{:.3%}', 4:'{:.4%}', 5:'{:.5%}',
                        6:'{:.6%}', 7:'{:.7%}', 8:'{:.8%}', 9:'{:.9%}',}    # 原型范例：'{:.2%}'.format(0.1234) = '12.34%'

reserved_precision   = {0:1e-00, 1:1e-01, 2:1e-02, 3:1e-03, 4:1e-04, 5:1e-05,
                        6:1e-06, 7:1e-07, 8:1e-08, 9:1e-09,}

            
def get_encoding(file):
    with open(file, 'rb') as f:
        tmp = chardet.detect(f.read())
        # print(tmp)                # -> {'encoding': 'UTF-8-SIG', 'confidence': 1.0, 'language': ''}
        return tmp['encoding']      # -> 模块chardet会把UTF-8-BOM读成'UTF-8-SIG', UTF-8读成'ascii', ANSI读成'CP949'.
        
class MyLogin(wx.Frame):

    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        #self.SetSizer(sizer=wx.BoxSizer())
        self.var_choices = ['UID', 'UID_1', 'UID_2', '8L_SN', 'No', 'SeqNum', ' Serial_num']
        self.SetBackgroundColour('steel blue')  #(35,107,142) or '#236b8e'
        self.Bind(event=wx.EVT_CLOSE, handler=self.OnExit_login_GUI)
        self.Start_GUI()
        self.Center()
        self.Show()
        
    def Start_GUI(self):
        # ------------ 创建登入界面
        logo_str       = 'iVBORw0KGgoAAAANSUhEUgAAAGEAAAAgCAYAAAACAhZqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAeMSURBVGhD7dp3rGxVFcfxa0EFUSyAigUULBR7iSU27MQEEluiooL4jyXBXmKNLZZYQiJo7MaWgFGJ0diNvWFDRQUbFrD3Lvr7zMy6WTn3nOHNy4v38ry/5Js7b5+9z5yz91prr7XnrW1rWxemPcPe84+7ry62+HuXcMfwn/DX8Krwh7CZukd4SrhM8DxvCVtR1w0PDJcIfwpvDL8IK+sVwQIUB4bN1LXDeaGe51/hzqF0xXDVBZfVsIk6JtRz/iPcOKykiy/+/nHxl34d/j3/uGk6PFxl/nEmVnbT+ce1vcI7wicWPCJspv4WTD6Zu3/OP+64ahG2ms4I58w/zuTlTDgJoQeH6y3YN1zUxJMPCzMv3qqL8LNw3/C68PbwgPDlQLy0ey5LvCjJxB8VHhrsJzu1CAcE4cINhIZVda1g/HXCHhom9NVwQrDpfUTDQia9h8u/LP5OidVdP7A8e8iqOigcEXjfpTQskfm8YP5x7ZLBGN+7v4aFeLI+Pw/6rGdHzw1Pn3+cuf5Nwk9m/5pLTL5PeFDwQl5MHPxp+Fh4c/h2mJIM52HBPWy6lwsm70dB2HF/z6Lfd8Ozglh/p+CBvx+eER4Tbh+ODFcOJHSdGd4UPqphIXuIe9w62F98x2/C58Ip4QthSlJji3//wNikybLGc8OHAg+t+blneE+wQJ7Tv28bjg8W8NLhl4Envzx8LQih4PHrWahFqB3+V+EaoSRT8iV1fYzzg0keE2sQz8fGjWEReMjbBm0W6YOtbYgFIv2eGn4XxvrBiz8xjMk+w/PGxhXfCbIikkr/PWg3qeaK4QzHQMZ37zCqqUXgviyn32gKaaTw0cUCvxLG+k/xxWARXtPaPh9o2SI8MpDaYniNkfSUt6gxJQZzVhj2m+IWgWfWIuwInkMo3qDhIlwtUJ8IKELUFA8JLE8o6te5e+XJLPLVoV8XenyXsDY2ngUdG4jLV/uXgnDC+p4dhIW69oHwpGCfMSnCZF0zocKCkGKCHxw8Q13/bTgkkPu/O9Q1nB0sqnFPDt2g3hXEeqFxuAhfDzxNdHhOMG/9unfYoOEiiLceThysdvFbrOuyMb8sVB+YeLpR6A/Hmrl6l/EvDtXHIggl9PpQ7eJ+3xQtSl07UcNC7wzVLoTVBHcxEp5R/V4YSFix4Vf7Z8LQYs0L4zgt2DfoXqG/5ydDr3HIicTvQ/UxFxuSor4INhFp1GNbG6SJY2JBnwrV74fBBtvHK+dvGcbEY/p44U/ba1tbXwQvL3OqazZsEkJ9d7WfFEzizcPNGryCFVe/Twf3fklrM2G3C2OS0dhsSzbiWgSLOBXzpdp1fxv4lcJMUymqm3HfkkGygjHpywJLVwg282714jzG5KFYVknmxeLsMatI6txT0OOC75QxCXsFKzRxJVZ7zSB1Lsm2Pjv/uEGey6SPSXj7wfzjBvXi0zvP0lOaWgSW2FdbrF9WjvOekrE8odcQ0t5lEgJLNmVjhaZV5KV63cGbWdvlB1jkCiXEg8T2PpYnrPr9ZD+aGjdstxAzTS2CDh6kxCv2m38clbqixDNMep9YBYuFmdINF3/pz8GiC3OryAR0C2XNQsB7B5we3rrA51ODwqm/L6+wYKuKAWJMU+3rGm7MHsAeUG14ZRiTsNOzFUWJL1TsVBsrqDx+KONNQvWtsNezox3ZE4QV+Xu1vy9MyT265dPTQo0Vch4dxqR6ts+U+p7gPRjcmPocC03rRj3lCULR+8OPZ/+ay0O5kdhbukNwotmLO+f+vujDocZblOeFR4VuYdI743ssZ510oZYzkIxHzC85n2E4PazSrYJ4L/vp3m1fEtOJF74geN4ab+HuFxRjkA7vUg094eqB5LnVXnwvcOuPB1lPv+bl9gklOXq/DmW78VI5Rxf9mvGONOgNodp3xBPIkYpQWNdgsuXqjw8MpFfSvLYnIN0bCscbnndYdAqbjkR6sbZTnlB6fqgOHlK2UJJH17VlfCsomIbqqd8yvhFuEErOguqaheuLoG9dc87U5fTVsURdX4ZFd75T8h0nh7G+QyyK5/Vjk/ClTVE2NgfU51gqvWERXhqqgwJt+MuadG+qnLehOcAbLcUXelxQ7I2Nt+jGV5Ve6nm1Ba6wIOtRydY1LzeUwounVZ8hUu5nhtl5/kBC9BNCr6w7MkE1iFScjg51zbtM/bL2olD9hOn1gq7i7qHBCtpAuZbc2mJ0SeO8nILHhDlSFpr0HcupxVWwEve1SHcNHtIJIndW1VbuTjZLDynD8j1OXKl+1HEf9/R7uFTT88uCGMhQsrG7BSGDUUlhTaBqWyhlFMskGtw9KDKluoyNMRjLC0om8zbB/YVXi99/7ygJUzXHwrj7TNUbu0yOI7wwHOF2DTddZ0Lis/jr/KZv/ltBqyYJW0Z9Y7Vhjbl+qfdVcbLybe0CDeuMnsV0SRmlhtVv6nhkWzshu38vnsQ/qaKaglfYFxxpDzfszf7fE7udeIONqE+yX59sst9sbYVftJaFrW3tpMYKoDFkWJv9n852az089AKro8BRpwx/CPm/0f8y9ZJrK/Hl3c6PnHpW3q142ta2Nktra/8FWOH5PTAD+jIAAAAASUVORK5CYII='
        self.logo_Logi = PyEmbeddedImage(data=logo_str.encode()).GetImage() # .Rescale(97,32), 原图大小是(97,32)
        logo_show      = wx.StaticBitmap(parent=self, id=-1, bitmap=wx.Bitmap(img=self.logo_Logi), pos=(5,5), size=(100,35), style=0)
        #pic_show.SetBackgroundColour('tan')
        
        tool_text = wx.StaticText(self, label=app_name, pos=(0,60), size=(700,70), style=wx.ALIGN_CENTER)
        tool_text.SetFont(font=wx.Font(pointSize=36, family=wx.DEFAULT, style=wx.ITALIC, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        tool_text.SetForegroundColour('yellow')
        #tool_text.SetBackgroundColour('blue')
        
        ver_text = wx.StaticText(self, label=latest_ver, pos=(0,130), size=(700,30), style=wx.ALIGN_CENTER)
        ver_text.SetFont(font=wx.Font(pointSize=16, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        ver_text.SetForegroundColour('black')
        #ver_text.SetBackgroundColour('red')
        
        TDE_text = wx.StaticText(self, label='© Suzhou Engineering Group -- TDE Team', pos=(0,165), size=(700,30), style=wx.ALIGN_CENTER)
        TDE_text.SetFont(font=wx.Font(pointSize=14, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        TDE_text.SetForegroundColour('black')
        #TDE_text.SetBackgroundColour('purple')
        
        # ======================== 创建一个折叠面板控件
        collpane = wx.CollapsiblePane(self, label='', pos=(5,410), size=(194,-1), style=wx.CP_DEFAULT_STYLE|wx.CP_NO_TLW_RESIZE)
        #collpane.SetBackgroundColour('cyan')
        window           = collpane.GetPane()
        Algorithm        = wx.StaticText(window, label='Algorithm:',pos=(5,0),   size=(60,25))
        self.choice_algo = wx.Choice(window, pos=(70,0), size=(115,25), choices=['LogiNet2.0', 'LogiNet2.0(LSL~USL)', 'Minitab(Simple)', 'Minitab(With Fit)'])
        self.choice_algo.SetSelection(n=0)
        Index_var        = wx.StaticText(window, label='Index Var:',pos=(5,30),   size=(60,25))
        self.comboBox_X  = wx.ComboBox(parent=window, value='UID',  pos=(70,30),  size=(115,25), choices=self.var_choices, style=wx.CB_DROPDOWN|wx.BORDER_STATIC)
        Decimals         = wx.StaticText(window, label='n-digit:',  pos=(5,60),   size=(60,25))
        self.n_digit     = wx.SpinCtrl(window, value='',            pos=(70,60),  size=(115,25), style=wx.SP_ARROW_KEYS|wx.BORDER_STATIC, min=0, max=9, initial=2)
        Split_file      = wx.StaticText(window, label='Split CSV:',pos=(5,90), size=(60,25))
        self.filePicker = wx.FilePickerCtrl(window, message='Select', wildcard='*.csv', pos=(70,90), size=(115,25), style=wx.FLP_SMALL|wx.FLP_FILE_MUST_EXIST)
        self.filePicker.SetToolTip(tipString='Click me then select one CSV file ...')
        self.filePicker.Bind(wx.EVT_FILEPICKER_CHANGED, self.FILEPICKER_CHANGED_FCT)
        self.mark_color = wx.CheckBox(window, label='Mark red on failed ±3d,cpk',       pos=(5,120), size=(185,25))
        self.mark_color.SetValue(state=True)
        self.empty_UID  = wx.CheckBox(window, label='Include DUT with empty UID',       pos=(5,150), size=(185,25))
        #self.empty_UID.SetValue(state=True)
        self.debug_mode = wx.CheckBox(window, label='Debug for original LSL/USL',       pos=(5,180), size=(185,25))
        #self.debug_mode.SetValue(state=True)
        Readme_link = wx.adv.HyperlinkCtrl(window, label='Readme', url='', pos=(5,210), size=(50,-1), style=wx.adv.HL_ALIGN_LEFT)
        Readme_link.SetToolTip(tipString=f'Click "Readme" to learn more about {app_name}({latest_ver}) ...')
        Readme_link.Bind(wx.adv.EVT_HYPERLINK, self.About_FCT)
        Readme_link.SetBackgroundColour('yellow')
        LogiNet_link = wx.adv.HyperlinkCtrl(window, label='LogiNet2.0', url='lnet.logitech.com/login', pos=(65,210), size=(65,-1), style=wx.adv.HL_ALIGN_LEFT)
        LogiNet_link.SetToolTip(tipString='Click "LogiNet2.0" to login LogiNet website...')
        LogiNet_link.SetBackgroundColour('yellow')
        
        # ------------ 界面插入的图片
        pic_str  = 'iVBORw0KGgoAAAANSUhEUgAAAOEAAAEBCAYAAACOgMJMAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAFEoSURBVHhe7Z0HfBzVtf/vnba76t2yVdx77xVXMKYbMEkgLwkpjxSaTPgHQidAIAmJFUwJj5CEtJeXQAglEHoHd7kXyeq9S6vVtpm593/P7IwsWS5aadvI8/14vaPd2an3N+ecW87F42/8FUUWFhZRg9PfLSwsooQlQguLKGOJ0MIiylgitLCIMpYILSyijCVCC4soY4nQwiLKWCK0sIgylggtLKLMOdNjpmRrQcLRKjS53qlm8xTR5AS+dXwmKk9MxG0Tbtqi6KtZWEScc0KETIBxnx1VV9Q1k3xCMQ+fYUyJJPHe/Gzu+IRUVJycjNuZGIn2AwuLCHJOuKOl1WhcfTvJNQQIUIo5n4/ElVbLM7cVq2uOVtMZnz+5OVH/2sIiYgx7ER5/cjPf6lazFD+26R/1wHGUEoJxu5um7y+XFx08oKz84L6Ciew3kr6KhUXYGfYipJTaPCrSBAii0z7UAQHqiwisZEM7zdtTSpZ9fkw579PHCkYwMQr61xYWYWPYixBjzFMZ8ZRDmtXTP+4HCJSjiHr8xF7TRMZvP0AuKCqj83Y9vDkVrKm+moVFyLGaKHT6WEW2zMQYX1Ilz9lWpqwtqadTmBDj9a8tLELKOSFCJq/TWsDTocWLzIy2uWjmvlJ5yUf7lVXv3VMwjolR1FexsAgJliU8DYZlFDAlioqF2g6aX1RGVmw7qqwoerQgy3JRLUKFJcKzYIgR4kWvTBxVDWTih0fIBQeq0NztWwuSmRita2gxJIZ9AWqhNGhX9EyAi9rtIQmHK/xzd+1T1xazeBE6A+hfW1gEjfUUHyTQ2N/qpCP2lctLPj+knvfuPZvHMqtoNWlYBI0lwiEA8aIqY7GyjY4tqlBX7CiWlxc9ujnTclEtguGcKCwqCr52dCBAvGi0L0IXuIo6OvmjQ+r5h2rRbIgX9dUsLM6I9cQeIn3aF1m86PKRpIOl/gX7itTVb/+4YLIVL1qcjaiOomAF1L6/QplT1cyNVxXEpybS1jGZ/JHR2bgqVMOLtm0tSNq3X13d2ElHgcXSPw47BCNs46lvVCpXk5/NH8tJw3XWkCmLUxE1EbK4Sfpwn3Lh50fJGpePJmGKsMgjf3ICbp2Ww+1dNoX/ODERtwx1eBG4hXv3q6siLUKjczgsOySuOzeNr5yQjQ4lJ6NOdk7MQ7awCBA1d7S6iY7+4hhZ7fHSRHYQUFxVhSC+pZOO+OKYuu6FD5Xv7yiWz9v50OYU/SemwogXYRm6wJXW+6d+XKyuP1bj14ZMWZU3FgZRKwglDeo0v0wdFPe1TkyMFMTY0E5y3thBv/T6Hvlrr95eMA9cV30V03ByvNjtJsl7y9Ci/fuU1aXNdIIZz8ki9ERNhC0dJFNR0Wm7fnGaGKl4pJbMfnWn77pXt5Evv39fwQQzWxCwjNC+2NJBR+0tlpd/Uawu/+DBglx2TlYXuHOYqBRoEJJfxTZmAk/bdEBYjAjvAnNTu904eWeJsvylz+Xr3y1SLoe2OG2lAcLs0Wn3E0l6W0ZZwVJVA52wt5SsKjpOl4Dbbbmo5yZRu+mUDGzfIEbDZW1j8eKnh9QL//yRfMM/Cm5abua2OCNehC5wxXXytM9L1AuPVNPpzEVN0FawOGcw1ZMXxAjxYm0bGf3KNnrd2x8p1/37zoLZzII49FX6wXWcsD6xRG+rCC5ql4ekHKiUF39wUF2lu9390nFYDE9M6f4Y8eLhSjLv1W3yf722Q73qk4cKxpjZndOaNNRAio1dpWT59qPK8m0PFORYLurwx5Q3GFxUECJYRmc3TdlxTFn5fx/L3/7ogHLR7kc2p/UruCZoIjcsI/RH9fuJvbyRTvycxYv7yukiszbTWAyMqImQRUQYGuj1P4PGqLjBHFtky60dNPvD/eol//e5/F0ouEyIpkxf2NtNdXtJYjGkZCxVLnjz7oLp7JysFBvDENO7OoYYwSrKKhKqmsnYVz6Xv/r3T/zXQsEVBCpRPnI9ZUKNyuLFzm6aVlQiL/3wkLJST7FhxYvDiKh0WwN38Q/vyjeX1JIZ7Lkf0v2DmwrCBCubHI9bR2ehUkoQVjjMgasH6/S2NmbA6AIH/VHjBM6dk0qq8vOEoyMScJOVNdz8RNUShmPnvePF9m6avruULvv0CFlXWkOnuX3YAYUZ2szhpf8k5tGOmR0wPEQgxUZpE5q88yBZU1RGF0AH9X4xsIWpOOPNg5trxhtsuKg8ixfZAu724JTiGjprd7G6sr6V5vugowCHqNFWZwY0S6iLEf6GIVPFNfLsXUXqBeW1dBK7T1a8aFJO6Y5Cwttjjcq8ShZfcYhXRqXRmgmjhUPL7thSr68yJEDYL7wj33K8jkw3GuLDAVhEWUG2pnY00qdQrS2R57E/KxXVjs7kytITURPPUxUKt/YDkyLwVBmZwtWMzRGOjkpF9cxF9etfWZiAfiIEAf5rp3z9W0XqlS63X+uRkhwvdUwchQ+tmsG/uWoW/8HEmwtd2sqDRBPhe0yENREWIeyLWUkYR5QgUVd2Oledx8SY5EAdhoUxmyCNeBGWbTbOnZ9GKieNFI6GYhiYRWTo52ruq1KW/menerXH7U8UBEkR2cvlJYm7jvuWPf+O/7ZfvCTfB6MamJCGVEMHlSURLyGGm8peHj9OKG+gU4pKlGXwDvEi5MGAQm02N1VfDAyZqqNTPj5C1hyoQjDyJMGM4cS5Rp8bxG5Y4sEquqBbRgmYw6pxdzHz2EReUrs8XPIXh31rf/6S57E/vCP/4P17N49nvzFBRupTGDfdKnZ4cOrhajqnqFRdXteO8nwKlpgETSVEA6i4YZrE0AXuSIV/zjt71PUwZIrdo9N267OIPn1E2Oii8Y0dZCRP/RRzYk/JNZYxlQnmeOzsQumvbfde96t/eR95dbt6zWePFWRrK5qJXlaREso3daLsojK6FLrCtXTibIVdAaZD01pFmGUKUvjvKZFXfHFYWfHRTwrymRitlIwxSB8RCj4keHw0DvHSKQteQIxQragyb1LkKur9k//8vnzTb16R7/nd927eEItP3IDLe3Yd8cwyqiqVqpvohL1ldElxFZnt9OEkKNhmc1EN4JghJWN5Cx2/6xhZuauULgl2GJhF+OkjQg84aczWGUX3dIAY4ZELLqusEltRCVn+/Fvq7Vv+6b9HH9VwVhfVaEaIGeB49Eoij48kltahqbuOqysqmuhEr4y1EfBmE6NhGfUp3+LLquVpnxWra165ffNcdo+sJo0YoY8INXgoY/0/PhWaZSQqxQIhnW417eODvgsff9H76J8/kG/4NJCRemAbihV6PRggLHR1o7TD5XTenhJ1WUM7yjFzvAjHDPFih4ukHqryz3+3SLkAhkxZKTaiTz+RUApPz4HXWwasIoc4zGlxZKsLj3j5M+/1j7/qe+jNXcrVMOOtvqopIYgKLU40cvcxuuxIJZnT5sRZWrxoUqsIQLzY4qQjdpbI5+04pi778MGCPCtejB79LVUIkvFRFi8eb1SnvfCeUvDb1+S7/njzzetOjhdZiQC/1xwwC6lSaqtqopP2lilLi6vozC4PTjR7vAgpNkrZOe05Ts7bc5wu2v1IQbr+tUUEOY0Ohi4PaNbwy8gOFQLPvuq/8wn2eveuzVOZGCV9FXMBFTfsrcuNk0sb6LQ9xeryqmY6HlxUs7YvasfM3GsYMnW8Xp7xeYm6Vo/prXgxgvRTG2FeJThhQwVcU0pkygmIdHq59A/2+i559EXPL/7xsf8b9e00n1AEe4pQoe3xxAYPs4bQnMHxiCiE8p1ulHGwis7fy9y5xk48CiYSxSaLF/u4qGwZhkztK5MXvrtPWQuzTFnxYmTo020N2pJ++U/fo2X1aCp0+dI/DiHQTQarE/K4w4qPSkynskNCXu2bMNSWwjn4FGRr6dV3NBzYBOzJTkdVeZlceUo8amU61CpB9K9NBxw/LyI5J52rmJDBF2dk4MYJVgr/sNHPEmIFxBCeDmWUsMiKo/yxGnXW9uPKsqPVZE5jOxmpUMSDYIyXvnpIIITisDaHaEKnjrJGOrnouLKkuIbOcPlxQsDVM2e8CA8QiBcrGukkPcXGAuhTrH9tEWL6B39aGtqhx4SnQmvSYNuGmlSmDqG6FeUcqJXnHqshs5xumqxCGkRWZMNjhcOELnC4bCxeTC2ppzOKjrN4sRGNk6keL4IY2QvWMwvGw0MbMlUtz9xeoqz7z48KZpxcwWYxdE6jtvBYwt4wd4fa2Msvi3ZWYMfsKlGWVDWrE9xepFUKhMMqhhuOPUKgC1y7C2XuL6cLi0rIkmYXzmbOhWDG8YvwDv1RIcVGu5um762SF3+wV1mnZ7YzZwVbDNK/YkZ7sofHEp6KQGUHxTLh44/Xo2kHKtT5Na1kNMRy8L3ZhGhAKBVrO2j+7hKyDCx9ZzfOMGpR9VVMQe/KG6h8auykOV8cJat2FNOln/9s80gmRs13shg8kVPbGYGON9CPGnMNXTjzYKV/1uEq35wmJx0BLurQrGJPGYo40B/VL9O40no6VYsX69F0txfHmzlehGOGlIxl9cqU7YfVVUVldL6VknFo9BEhi8f1Eht+d/RkOD6gFomDh68k1neKOYer5LlHmBXp8tAksNDBihFWNB7TIeiDEDzgVcDxsveObpx2rJbO2lOqLqttRqN9RrxoQstoHDMMmSqpkWftLFPWvnF3wTSrSWNw9LOE7PJG1B09GRAjCAdePlmIq26iY4tKlMVVDWiCx0vjQFmmclG168nOR48Xm51oRFEpXXKglCxq6cZZ4OLxLO4ykxh7x4vGkKl95fKSjw6ra/QhU1a8GAT91AZp9fTFMGJY2rOXO47H2KXyiSWN6vRD5XRefRvJ86tIgiROZxNj4EQCq8RK4ALHIbN4sa6djt5VTFZA2sd2N07rbWHMQu94EYZMNbTQ/J1HyepdpXQRjDFlYoyRcCe26X+RIuS3qfLAxQ4Fl91wrrYLjThU6599tFqd3WzEi0xlZxQj7CVWFKhjHA7EiyV1dDpzUZf2pNhggBjNJkiAHTKFlIzHa5TpRcfISkixASkZ9a8tTkN/EUakwBq7DcLoslUhXlRVSappx3kHq+R5UIC73TRxMPFi1OkVL0KmgiOVdPaeMnVZQwfN9StYNGW8iE9Y87ZukgYpNvbuVde+fX/BZCtePD19RMjKBDSjB6GMM0OVE69QAPEi1KLCc8LnF+KY9Ziws1JdXN2Ixnp9KGBFzCZEBrQvwpCptg40sqiMxYsVZGGbG2eoKmbOuDnjRegYbgyZ2l0iL//8kLpqe2BWYitePIn+ljBEgPAwjFDDMlXYCzpzB74ZGkYtKgDti24vl1RSQWYdqCTzGttJjqwicSDxYqzCXFRbbQsdu7tYWVFcT6e7PFir/jeje2oA8WJ1Kx3zyTGyds9xuqDo0YIsK148QfguBBcQ3vSxfMKiCVySyAdGVejfhgjm0TETotoQ1+aiIw5UyHOOVvlntTlpJjMtWhc4zY81EVo0wCwk9D8tqSEz95aqS0rr0WSvD9sh5gIxmlGQcMwQLxbXKjM/PaauOlxB50BKRv3rc5p+Igx1Z+fRuWL8FctwdoKDikoYik6PZWReEDOCtroOYXRRmTK/pJZO9fhQHOQ35Qg2XaGFhn4QY6sTZbF4cQ60LzY4UQ40aZi9fRG6wEFM/0GRuu6D+womMqt4Ts8yFXaXQFQRjkOYl3q5keEC4kWwfl6Vj69spRP3lSlL6tpQvl+hNrZ3eLyYp+D2jhcpFVs60ShIscHixQUQL0KKDS1eNFHH8JPjxaYumr2jRF7x6WFl5Rc/KxjFxGiCHLahJ+yWEIjU4F3NKrKjZ1YEzoPr9HEpR2vVaVWN/nGd3TRFkZm3ZzYx9gJSbFQ00QlFx5VlMMtUtwcng/9qRvfUAIZM1TWRsZ8eIOv2ldP5e35akHGuxYt9TvZEt7XQE40RoWAZ/Sw2bPfwKbXNKK+hQ8np9sjxmgxNKkZwU7u9OOlYLYEmjSXljWiiz49tIETjpa9qGqBpw+cjccdq5FlfHFNXH6yhs5gQz5kUG/2eOEOZwvp0RL1UML9NwVRsdXMZ1SxmbOpQs2WfIqlmFKNxf9h7WycaAb2I9papS5s68EizxosAHDO4q60emnGExYsf7lPWmmeahaHRV4Te8HeYCX0N6cCB0uvzU3tDBzeiqp4f19FF0/wKCtxks1lFdrxGvNjYgXJ2HiUrDlWSue0enAbxopn7o2pd4DroqB0l6nmfH1NWDvchU2H3vUUBjGvsoN1pjnIuTOPqWlFeY4uc2+lGyarKroWZrKJhEQG27GfxYmUTnVRUrCwvq6VTncxlha/MZhUNMQKKSmxVDXTCtoMqzEo8f7imZOzvjpJeN3eIYAJVJHrBjzGgfZEyMbb5+NSqDppX71RyPD45zpQuKsNo0nD5cPKxajp7H4sXK5uQlpIRhGi89NVNAxwzpGQsqZLnbD+urnr9joJZJVsL4vSvhwV9RQi9+0Jp9AVmXJgCY/LOg91jwH9UplJbO5dR2SqMaWknI2TVhPEiHCnAjpepkWvpQNkHK+j8vWVkSbMTj4AucGZuX4TKm5ZumnWgWl7wAbOMeoqNYREv9hGhzws5R89ReIR9MrU3OnF2VS0/xtlFUxSCAqnhzWQVdTFCvOhXqdTYRvP2HCMrDleROZ1enGLWeBGOF9oXIV5saqO52w6R1V8cocthmgUmRlOn8O/njrJbE1ohsq2Z5W5rJ45ZvEhpQkMbyq9rl3Nd3SiJmC1e1DG6wLkV6ihvpFN2FSsrKuvp5G4fTjCbVewdKwI+Fi9WNimTdx0kaw9UoTlmTskY9oqZAKYqu5oYZQxZ0/i08k6a39SpjvJ4qEOToYnF2M0sIcxKvOe4uqS6BY2FJg2mQ1PHi5CS8XCFf+6ucmXVm3cXTGdW0XQpGfuJMKQ9ZvQteTlWoqFLmZkg0NGHvbF4sakDZ1a1ojH1TpIFTRpmrbyB44UUG9AF7mAlixePkyVaig3mosLXZhOi4aZSdvzQBW5vubz4w0PKaj3FhmnixbBbQkUNSNF8j9nAcUMtqhYvqtTR3IZHVjT5xrjcNNns8aJXpXYjxQbMSgwT3WiFWreM2vomwHBTjXgRUmxsP0bW7C6Wl8KsxGaIF8MuQhjBaToB9kYXIwBNGh5ZTKxvRqNrmpUclxcl9sSLJsNwUSHFxvF6Om13qbqMxY2T3DKOZxI0pXtqACkZS1kM/MlRdd3hCjpr+9aCZP2rmKSPCKHvKCbhryEllIR9H+EADhoso595104vl17exOLFVnWk2x+YTlsTowkFCUftdKH0w1V03r5ydVFdCxqjxYtMiGazjAZgIZ1uknygSp6/r0hdrU/LF5NDpsJuCQPthKa2hX3pZRkJpbYmF86qbyNjmjtIpqIgwezxYnMHyoEU/vvKyaIOF05n0YRmNEGM2nomwogXG1x05K4ydfHHB5U1HwRSbMSUi9pPhIGKmVAn/z3Z8IVd+xHBiBddPhpX34FHlTX5xmrxIgyZ0lYwkRCNhwdDZvEipNjYUUxXaik23DiJGZZAW52JrGLveBG6wNW10tG7j5G1u0rlJbE0ZCpiBxGNoUxhx6i80ZYD8WJDK86HIVPubpTQu2CbAu0BrMOWu30kHlJs7C5Rl1U20wmQktFsE6GeDKTYKKuj0z45StbBkKlYSMl4ShHiEDUnwB3VnkWmvWXBAZbRR4kAQ6aqoH2xHeJFateEaLxMhNEfFWYlPlRG5x84ri6ubUf5Zm9fBAsJKfwPlckLD+5XV0FKRmYVo5YFrp8ItfGEIfeYzxEV9rKMfpnaGzrxiIZmNLqtnWb0adIwixjhSHXY80Woc6LcA6V0EaTYMIZMmXn8IsSLdZ00Z98xsvTTI8pqPcVGxOPFviLEFEM003PlQ4C2rXNEg/1gouxSaHxNJ8qtafSPhi5wpowXAXa8cODQBa66mY7fdUxZCSk2ICuc1r5oMqvYc8zM1kMXuJomqqXY2F1CF8KQqUjGi/12RLShTKHbP4gwxoYURhTtIYQp1+kXkmta6ZiGdmUUpNjoqUU1C7pV1J4gbNnDxFfMYiqYlbi6hY7zyoFmGrMJUV/UgBQbpQ3yzG3F6pqj1XTG509uTtS/Civ93VH93SK0aO2LlAqtHi6zul0Y3dqhZvs81KZlMjCTi2rAjhfqaCAlIwyZ2necLGpoRzkwZAo8Pe1lIkECcLwgTEjJuL9cXnTwgLJST8kY1njxNCYvdE0UqgCN/yffi8jPfxh1IF5kQoSHHAyZghQbtW1oDKTYMHUXOB7mB6FSXRsdvbeMLj5QReZ3eHGqwpmvP2pvywgpGRvaad6eUrLs82PKefosU2GJF/u7o9rFDZ07qnGK20D48PfMiTlOatKAeLGpFeVWtfnzoQucKVMy6mKE+Rc9fhpX1Ugn7i5Wzquoo1NcHvMNmTKAY4Z40eMn9pp6Mn7bAXJ+URmdB0OmmBgDcX2IOLXa2KM5rKhKZAUYo0UALoKfo7zLKSRXNdAxLV3qSEixoRVss7mnDCNehJSMR6ronP3lgSFTkJLRrBPbAGyRxcAkHlJsbCtT1pbU0ylMiCFLydhHhGyv2nOYhtjo9r/y1sQ8BgEzgjCkZGzswllVzcLoRj3Fhr6CuSyjjsLixaZ2NPJAJV14oJwsbO7Eo6BJQ7MwJrWMIEYWPmTsK5WXfLRfWfXePQXjmBiHPGTqNH5naNzRHpvtO3drRweMHi96Vepo7Ayk2Ohw09Q+TRomEiMcNMSLSiBeHMPixSWHK8g80w+ZYscMnRVqO2h+URlZse2oskKfZWrQLmo/tbGS0GOGQ4YlwbNzUrwIKTbqIWt4q6zFi1pKxsAK5rmavdxqr4/EVzTSyTuPKiuNIVPwudmsYo8YWbwIXeCqGsjED4+QCw6U0nkwZIqJMWgLFhqTdwbgiC0NBg9cN0ixASkZy1vp6OZWPV4MfGkuIRqw5U4fToYhU5Bio7YZjYaUjGZLPNUbcFG7PSThcK08Z9c+dW0xixeDTcl4ShFCXXoooOzpLkDjv6XCwcPcVKpQqdGDR9TVC/n1nWSEljUcrqrxMhHQHxWGTLV1oZF7S+migxVkQRNzv80cLwLQBa7VSUfsK5eXfHJIXfnuPZvHMqs4oNqVfiIkMMdtCMGQSkFfthgEvdxUyBpupNhoPzleNAu9LCPMMlXVTMftLVWWHqsic7o9OFETowkb+gEjhX8Ni4GLKtQVu8vQ0oGM6u8jQj948JhZQSV0Xiq7lIFCZLIndiyiXUhjyFQTyq/rlPNgyJTpUvgbsOOFpwj0Py2rQ1N2HKMrqxrpBI+M48ycqFjrjwpd4Gr9U/cdUFdve6Ag50yx4im+YB8xHzKU9L+Sfv3dYjCAGCFe7OjiU0tZvNjqVEd4ZBpI9WdCqwhChC5wXR6SegiywJWri2s7YHJXLGqF2kRi7NO+yJab2mn27nJ1aU0rzdE/7kd/EYZwLgoN2IO5ns+mgnlutoZ2nF3PLGOTk2SaOV6E44V4sbEN5e6voIsOVZL5rZ040+zti9AX9XCFuhCyv+kf96GfCDUFDsth8MMQcEIJExofGDLV2oZH1bT5RsMsU2aOFyElo+yndpiVeE+psqy4is6ELnA97p4JLWObi2buq1HmlmwtCCQF60UfEUIqKsJuLD2FgRwK/a9YDPeYUdnTGDILmCVZca+KG3BRXR4xqb6Fjq5pU3K1IVMmjxc9PpxYWken7yhRV1Y10/GQYsOs/VHr20nusRo0Sf+zhz5qY5Eau5fsDEPcbQ1mINEXYxsmPIFXcYrYDoObsWmEeBI+SgVnN5dW1iyMgXhRS7EBmNAqAhAvurpR2sEyuuBghbqo3olye6fY0FeLebT5+ZvVsTsf2pyif6TRz+QROTCnYKgxg4cLdzNBaEdXT3xFvHrKP4VkiYkR3D2wjoFVTIF2A9lDpCdebED57WZNsWHAjpfdCqGuBeXvK6OL9rN4scOD0zUX1SRihFrTFhfJbPbSUfpHGqf0O8OiQpMALtCCrCPCLdP/Yr9n1VP2udk7BJFXAlbRbJZRjxe7YZapTpRTBSk23ObuAqdN+eancTVGvFhDZ0AXODOIEY5NQVho71Sze8eGoQ3+ToEpBU05lJrowqsytwk/XfkL++aFz0oTMyp5CLGJmayiHi8CkDW8yy8kV7F4sZ7Fi32GTJlFjL1cVFh2uXFySS2FlIwrapvpGK+C7ezmxKwQAw8KZg2dOLOzk8W2Ov1F2OvGhQIqhHZ7gyLYI4B7SDGy2yjOiXNzm8b+R3poxS/sX530qjQyoYljjzPTWUW4BPBihy62ubj0mlZhDAyZMmW82AsYMtXiQpnMRV0MXeAaOwLxYiz3R+32q4l+UZsXWyPsltBs8xlrhbVHtIGia7cTPD21jP/enN/bfrz8aduFEz4T7IKvx0U1XellD1oPzErcgUb2iRcNq2giQUL4AC8tXoQhU6V08aFKMretOzbjRe1YFMR5u2nPoOB+ItSGMoW9FsVsPWaYGJmLmhTnx8vTdwq3L9hiv3f+07YpWYd5qE01c7wIQ6Yau9Coej3FhinjRUA/XphlqrKJTioqVpaX1dOp0AVOEyMr/LEgRjgWeGqo8ok2iD4ixH4obaEFNgj5R2DZ2CsrtiHfT9iBI2ZPKJsN4ZHMRT1/3Pviz1Y/Yv/65L+I+YmN2nWE9kXTlNxe7YuQBa6tW0iBFBu1MCsxdIEDe2gmqwhHCsDxsmUYMnWkhs7eeZyuqG+n+ZBig92c2LCKWoq9E/R3R9mjMFTthOAmDCt6ii2HHMxFHRvfwd8w6yXbI4t/at84+j0xxdaCzRgvAnBWkGKjA2YlbgzMSgwpGfUvzXM+uhih7EEXuNYuklVUQpfsr1AXtDjxSC0lYwy5p0B/EbKTCPURwin33Wbs9piBmzewMsfuNbOMcQ4Fz8krEW5d8oTtvgVP2xbl7xBM66IC7LS0WYlb0ajKdn9+RzdN65MFzkyCZMD4RUKpWN+KxhaVKksP1ZDZMGSK6TCqVpFKJ65jfxGGwX6ZryQOEO2ZC/9xKD1O5laM3i7ev3SL/baFz0j5SXUcx1Nsqi5wgFE7zmQXmGUK5UKKjZ4hU4CZhKhbRoCJL6GyDk3ZV64ubnXhTCNW1L+OHCdJrJ8IYTS8vhg64DRN1Sl8EPeFXTgHixdHx3dyG8e8I/183cOOK6e8LGRCkwZ8bTarSMDO6/Gim0+paKZjmyElI4sXzToRKs9DWl3KNXai7L1lyuLWLjTCqEHVV4kKfUSIGdq79tfwQBQQFSFUD4ITTRRB0HPlOJTAXNRpKZX85hl/tt+17Bnb+nFfCMmiV3NRTVNqez+MmVWUWbzY1I6zmFs3urOLZMi+XikZzYJuFcEQdXtxysFyZX5HN0oPg/MXFKdwRxkhslrGXYymEYRgBq5+ZEsK2yezI0lxPnxe5nZh88Jf2TeNf1GE7m+hmvsx0mj3kgkTZiWuacM51Z1qfk+KDcMqmswydnhwakmtOsPtxfGRtoZsZz376y/CUA/qZcj6e6ThWPEgzK1iniLRpraOJNpVxMgmcjiDd+PJuRW8wJnKJz81cB0xjIIXkxpbUF6dU87rGTIFmEWI7DjBADZ14pEwjTbMnRGx+PCsTRSwRoiHMkX7tqgYEucMrNKXitCaGsID1gwxewoQdsu1KMvk9GpfhCFTHU4+taxNGNvaqWZrXeDAHprBKurHqRDKVzap47rdKAmKfjQqavqJkOLQZVtTA+kOte1RrrcIItdjBqyhKFAqsaA8mrWU+mUYVmhnxEQJKRlhVuJGmJWYxYtaio3ACjEvRC0+9OHk5g46yphJKtL022nIHSZ2ltgX5ZvBbBtziTUn4EwHEs6DHI4i7AMTo1Oh8Y2teFRNsz+/s5umkN6j+mNZkOzo6ttIHlWZD3iSqxgJ+ojQjykOeKJhnpUpwkBlCFhDgcPK2SpGhrlUwgrE3TIXGDJV24zyqlqUPBgypTVpaCvErhCdPpzk8qIE/c/wwgyT1KuusJ8lhAsW6hwz0b704JJigiknIVWE+PBsQgyHEmO2+IWQXvEiNGk43VxaaaMwtqWdjIj1LnBURrzTRVOJ3kwXSU6jtnBbwsh3WwsIkQXiPFXOLsRzQTHhRSvJTJSEUhsMmaph8WKrk6b3SckYQ7CD4bp9EbKEJ9FfhFCZEqLAEFxb7Wac5nJH2v0GIUocJiBESWCOKRPiyYcWvsdgxB+wsQO77jBkqqkN5TZ2+PMgJaPWpBFjYlRZxKIvhpeTCv5pLGHo3FGexFa9vCFEJFAF26AjSH+rGK5yETOlLQpAIYCUjDBkqraZ5mspNmKsCxx7IkesrLKT7TnffmqjzBLqtTMRhmr5W+AVeFCE754YMaLIUYI5JNvAKoa7OT/qRSwGYFcYSrmWYqOLSz9ej8Y1aUOmcEzEi6FtIB44fUTILlDonwRsiwM5M6JiygluLIhuTFWmDvZ32IXI9iFxiFCwihJzUUUuChXU5xB6xY0Gu/6UxYvNbTBkimpDpnpc1HOM0/id0WiiwChF6sKbxr5tXzXqQwnECEI8YRlDDwgRXpBGTaLMGvJIsUt+2e+whbwgiD75nCtcZwV8DyY7r0y0IVMwEarWMTxG3NOwAT0EetFfhKxQnlabIYI/RX9qkD3PEbwia7d0+9InEm+e+4f4CYnFAlhHsFggxrBbRnZcCicQjEIvmOFbooZAL8sIQ6aaXDirvouOMuWI/iHQX22aEQyvJWRXHiJP6E3ZH3bZRzm6+I15bzoeXfZ40nXj3rZnJtZBvxvmsmpD80zKCU/M4hQwq0jZgxD6otY71exodH3jIil6eqIbZ3hNnk7vuSgwJ2qtoRLilIB1OwktFORQnF3FYzJqhG9P/33CnYt+mXj+2HdtSWI3ViJgFQPNtaEVTeS7BZsMZhW1K86E6HTzqR1dakZPT5thTj8RMhsIyYpCT59CSBAvcT5BOVPRZNefYpQQJ+NFqYfFzXO2Jt4+68mEuZkHRHBRjXhRX9kknBNlauhwlGtxchkeaDwfjkI8UzshexQFTjhUTRSnyfxLOZXGCYoPcf6+fu/Jl1v7GzJhI5wV5+NWjf3Ifs/8wsRvT/p7XGZSPc/xpJcYQ6PHcN1xkz0too6MqNjk8mcqCtjI4Xf5aK9BxP0sIVaVkJZD2NipDKsgSIqYILr7W7NTrc22Ai6qjeIx6bXCdVNejtuy6P6ki0e9ZUuLa+Cgk0/ImjTYrsIhRHoi67nFAPF2i/HdcnS6kkWSU8aE+NQfB4euByjQp5QGkWmiwHVjjoXgvTmdArTP4T/mojpkPHlEjViw4MmEzQufSlg18mOtSUNROcriCIthANxpsIYer5rIClCgV02YYfuMSunpHxOS0M5PCF2BiJ6B2wAqZ+Bd4qmc4hBcfa3h2ZJhBIQI8WJyHOU25O2wFyx9MvHmeX+In5JxWOAx6el5E1g/OMBeBWoIQgsdDqPqI4nef8npVRw+L43hqZ0HAY+QzR7h2lG4nPJJXqYmRIgNJb7bJqpu/WMk2wYoAVgLCjblUb7DyV+Z+4bj4blPJH1twsv2tLhAWnpwUYOzjJZQYga9ttSnSJLKYbPNKxQUkRHhadCaKzhZTU0gnXFY9mifad8MkJ6VA2npRyVX8tdP/2PCAyt+kbQu731bisPJEQJd4OAxEJQaQ050925eBIIEWaEC7tWuNtzoI0JZRliFHjMhbKLQnmFn2Z6ABCUlVWyP43m34CODvNiByVogXpybdFT80YItibdOfSZ+fuY+MdAFDhr6o3kfLSs7GGRK4cZFxFgw0xuVAnLqk4vgKArDLWWLSkoc7cQOYQgZEqGgByb3TItTufPHfWi/e0Fh4tVj37Y7xG6tOSOw3ukJl1SgQjoqd3gYoKrD7AkG7YTewCLQT4Q4xCdsbAzmGtcX+2FU1PA8JnZFDU2fORYvQvsi9LpZmlkkOcQuto+BnFp4pEIdmCDeF/AJBllpdK7C88P7evURoVEFFaozJtCAFwQqpVixhSjlorYV9h9lEX6QNZOhOYC+8D4/FQRBwQL2n25UvwF8brwshicUZkvU6SPCcGUDpcE4mGFQQDCFORwCBIxjgPGLMKofMr9JJCBG/SsN+IMn7GkEn59BqBbDhz4iFAREREj5oP8dElh8GfWCFOQBhEWIvY4BRvXzAlIg143AIYX93ZNiA8SXLLXir09+RZo64iCv3SBdkLBoMQw403hCG498yQ7aTqEbdyiJevEZuKzCVUHWe6swdhHeIdcNe+ipiKey5qLCcB72uU0k+KKp74oPrXjS/s2JfxVhejVYH6ZXs5QYPpj/EbHLS7XhQgH6ijAOubJSuFqqcBwlQx/YqrWw9i7/YTExZyc2Cm7fkzdG9UMbppZ4SqQK5pFfxByBeashk+7k5Ar+O7P/bvvF4p/aLxj/uZBia8XEpNNxW5yePiLMikcdY7O5Yyr2h0YuzBXVelefoWb0ZMKh02BHw4Sn25q+cBKGGAP5bphjaqMyb/Pqg10CQ7mmjTjO3zV3i+P22X+yLcreywva6JFzxCpCvoPhxpmGMk28udA7KQ8fTHBITooD4UikifYVD8dDYCAYYmQPLYpFUbX7DI0FmlrSE934wgnviHevfMp+07w/S6OT6gPVyGAVLctoavoJbVK+cGDiKHxIJUpIRAgFRSshUEM6gKISDhHEQgkN1hr3Q2/3nJBYw28a90/p8aUP2a8a/5aQzFxU7evhahkjdVLMW2PhQFQuYT+hLbtjS/3yafx7CTapi0D0OMTYEDrfpCZTISmBCtBSfdbthVyFbHdBtRMOWS6npFcHiQHR7xi0D9h/hEdJzEUdm17J3zr7Oft9zDIuyNsh2AU/ZESwrKIZ4FkpO9OgXmDxOOG92ePRdk4l1OjNEjTsV7KMyLEmzj0+g8Z96yKcu3QylyzyIi+rMj2VGEGwg9tZ6Ij2/gHtGE53IPqXYBVTEzz4gtzt4kPLfmG/deH/SNOyD0H2Rs0qautaBEd485udllOKcME9W9o3nWf7Q+4I7jhSAkcWrEUE8fr8MvmgSG15/m2+GnrPfOcCLv8b67mcybl8PMeLmpUdqqU9Oxj57NB/e6ABfrA2a4AE2Wvn7MD2QHEY5cS5uavH/ke6f+kz9m9O/os0Apo0jFjREuTACUkAFjyn3e2EbHz4a6ttz2Sl4jpwS0FUQQuRCc3jldVPi30dz71JK1/6VGiYkqXGf/dyPObqFXx2aoIgwTpgGfWfILvsDXVpRQ5B9afYxXZekL0chucd7O70pxKOCrngLpz+PhBgXSZEh43i6Wml/PWzXrI9tugx+wXjPxOSRG/gTEwuxOFo2Zkz2nNOpxfhTVvIwqn4k2+vF36Zn4FKtPgQw+wNwVtEgRWUJqciv3NAbfnZa6j8wFG+c/F0Je2uq9C486byaSkJosBB4l39N6EGKzyJt2FPRqLYmiDRDp6X/dqA31PcW6rasE0J/YMgGGVpo/sDiwNDW5n9R3mUEu/DM7OL+bsW/Nx+5/ynbTNG7GUBgIJVs8aLcG4RGtWD9dH8YedMTRQnw4SoXvvUkx/edJnt0SVT0Ps8VnyaENl3wYhREyINWNLmNsX7l49J7e/foJXlXZz3urXqyO+sQ/mzJgrJdh5hH2went9huByYOWkJDrUrPV5qccSRLlGG/Dba2WgpMQIraf+HHrt9gGc01AOAcZUUp8cp3AXj3hcfWbnVfsPsv0sTUmq0+2a5p7HHgLzgix8r3HvjBtvPv7XeUThhJDrCIZkgElyFDcz0BGKEF2Hu575y1fX7V2n1n97halNslP/BRUr+FUsTs1vIGm+TJ8fn1ea5h/IS2jKjPRA4Rc6Ixx0pKbZWh0BcvA8TjgsEbbGQXe/EMQxWkPA7JkYJ4XEJ9fx/Tfqb9NDCn9vX5HwiBqY5sIglBhyKzv1xYdMli/iXbrnMft8VS+x/Sk2mzWDZwE2F74O1jCLEi4qsfnbY1/7rN1Hl69v5ptHj4+PGzL84odJxm/to1xpnm5KgeLSwJvRCpESldlHxpiQK7SlptJVny5DeS19leAB3hnIo3qHiSVml/PrcnaHN4mUREgYsQoC5p8rah7aUfv188dk7r7HfuXya7d0kG+kgip8LFOzgK26goDR3Kf4396jNT/ydlu0vdnSOGjfD7pheIB6Qf+isInM8HQp40eBID04jxkiq3qEFHK/2TmXC3GBPWpzUkpiidHICkv1C6GdlCubQQyoUY2NMjNQe2pyyFoOER8jRq0QEJUIDJkYfuKi3b5Ieuv4i6ZezJ9q+4AmVB9PVzbCKlLmotSxe/OtHSt1vXlGrmzolz7QZS+J9GbcpFeRbrpL2iR63Fw488C8YYPVT/QT2rT08OJWKnKwm2nhnSpzabuOUk0LnSBOeDgPYJ8AAmcCliFQlhImIrRwzA4SJsfuGZ7f++6aN0sNf3yBtHZPFHdesoVbdEVzLpyEIRVHJ3mrifPYtWvWHj7lalJCOsqZdbfOMvEXeTzY6m9wJ/sAoEOM1dIx9w7Ig8apNoVEVYUCAoS8Pil0lPEcVTYC9piWLZcRwXIgYY0giNFh6R2HdZYv4v/3wStvdly+x/29yImmFoRNGvBgMIAaoSe32yOrn+31tT72GKv69R2x2jJwk5E2/Xiqz3+0ubl/s6lA41TtIy3g2KIVGlegRrgey5ENUlJCqDZnSR/UP+xJuAkIiQgCaM9b8pLDkm+vFrbdtdNy9aDL3QaKNOAlM6MEIquIGalL1eLGuTfH/Z7vatPUftLyozOEcM3m2nU68izuKb+1q90/0doDVYuXpTGLkYiFRUBBHIKsh717TZ/fGkKmTR/Wf60RsfkJWXAfUWD9YmBj9V24p3HnHJvGBb1wgFU4fi3dxQ4gXwSpCk0Z1i+J54X1S+5vXSHVDp+QdN+GCuPrR9yhV/q92N/vyfFq8GKKeLtH20/oNhg4Rva+OkWJDsiM/5LtBTIyWEqNDyEVoMPHmQtf3nt/6r9sulR78ylrpNzkZXEXAGgbXF7V3+6Iiy2R3Oen87fuo6i+fCLWCLZOOmP0VqTbhNv9R3zpXmyKecFH7FLkgwJDuapC/NQk9Yxd5jCGnjWgDF5XKNkj7HGtWEY4mXF2pYoSwidBg8f2FNZtW8H/94Sbbjy9aaH8p0YHa4XPoeaOtEAQgRKhJdblk5eMD3tanX0aVb+6yt8TlTuNz5t0kVuN7XdCk4XJTckKM2i/194ERjpH1QRGm/Z9KXSDGQIoN9nRklhHbsGzEi/oqUScmwolQcqZET+ECXNT1DxYeu+EisfCWqx33LpjAfeKwIZd/EPEiYMSLtR2K77UdauNT/yIVRaWOrhFTFti40XejMu5GVxef6wcx9oxPifZtDCLMC09owrZ6ms32WEXmotox1eLFHjFGuykj6k/E8EAdJ65rRERowMTo+fLjhV98/0LpgW+cL/x65hhcxCIR1egYHlTlTa94sapedT//Hq1+7j98TaMv3jdq+qW2zuz75UbpKk+jM1k2hmMNBAyVIuGoMwx6k5E/Bs0qMiFqYmR3BFIySjwIEZPoiTFKu40gERWhwcJ7t3RsmCe8fMsV0k++vJb/n+w0VKV9wYQFb4ONF3cU+zqefZNW/e0Lob5bzKUJU67nXTk/9jeS5V4/lbRtBmt1o0E0n/0BqwiHgLVaVF6ALHBU1sQILmqsxYwhxJSN9UOBWUVy3r2FFV9aIf3p9sts95w/V3olwU6ccBWMeDFoy8jc1HanIr+/V2195jVa8cE+RxvKnMfNX7Aqec3UhNSEuEDPNeidE9NiFMMzsDjYEzYso5aSEcQILipzWkGIsXvxTMBJXUGiJkIDJkbfhp8XHvzBpdIvb7pcvH/OWO4Lh4i6/YqfY6UgqP6oYEG0LnDsN7Utiu8fn6v1v/knKS9rEz0bV9ERN15Mxy6YxCU7BJFX2FZPu+0ohyFR3n0fDMsILqpEqRpoX8Q97YuWGAdJz7S4MSBCg4k3F7q/+sSTHxdcKt133Trxqal50n5EYIoYftADiSFePM7ixd9BF7h3uRrEYXrDBj7vq+u5nBn5fDysB1ZR/1lYoTILsTBHYH4a+Ltn/OIpCc8hDWWrATEGKm84iYmRuag9YhwmRNIdpXEnGrVjRoQG8+/e0rb5hSf+dvOl9p98aaX9+ewkXMsik6Cb4Y1YEV5eFi9+eiiQYuPFj/jGKZlq/DcvwaO/tIwfOSJFsIHIe4QeJjMU7xC9SXbcHs8pHi1x7xn6bobPEg59yyBGyCYFLqpooyoH8SLGgfbFMz5YBgcecG4g8xJzIjSAIVPXrhaf33y1/Z5Vc4R/Q7wY6IsKD14SfLzIfqml2Diotmx5HZUXFfOda+Ypad+7Eo1ZOdeenhAnCtocimyris0Tch3AEcc7OHdSktiWEkfbJcHvB0Ovf30WyxgiQtgbTosXVUxFiBchhb8NycyUaEIM5YlEqa4kosSsCAFoX7zkscJ9t1whPnbTpdJDM8biHRLHeYjCceAbBStEY8hUZaviffETUv+Ll2m5s53z/9cyddSNl6Ixs/OFpAS7wAneQCaIcCBgWUmwca5Aig3axcmB/iDMojCF6LuFh38YDECot9gTL0IKfyY/yQZd4ELbHzX0VyEGGEje0VhDixef3Pr+jy6X7rl2jfibcbnoMIyMH3R/VFbcoUmjtFrt/s3rtOqF97kaaK286VJ1zPol6Vk0fQZ1dnPE64ULFaJi0HsznEwhxUa6je9ISUGtIqd2C9AwHkZHNJyAEOHYmfS0/qiYR1q8qLUvWpwVU4jQYN5dhS1XLOX/98YrbA9etdz+QkYSbtSsYZC5UY1YEV4eVVY/Ouxrf+4tVPnKDq4xNz3Zljj2qzZP+q1+J50qe7w87dsFbugY+wYxQoqNjATSnpBE23lR9upnov0fasKz1QCGVYTKG+gCFxAjxIsx2B812sRaE0WwMBdVvfDBwuL/Wis8d9sV9rtXTLO9ExfPubR4kZUAfbUBA2IAy6il2NgtN//6TVrxWWlGK8q7ENGJd+LOpKt9HluWCrluhmIZsSD0+6EhRsxhNU5Qu9PjpNbEeLWDleAwdVmOjKUNWMbAkCkk4kC8GEIXdbhhOhEawAxSlz9euOe2q8VHvn+R8NNpeXiPyHM+yHcD3w8qXmQubnmj4vnfj0ndE6/QiqONWV3cqK9x8uj/R7psy2SfzX7CRQ1hcdKsIgPixSSJ70q38+2SI7Qpb2FT3hBu72wYlpE52dSOEZFstGfIVHBijMyDA2AHFcErdALTitAAhkx94zdb37plk3T3l1dyz40ZKR0DAQ6lfRHixcOVquvZN1DlC5/Zaurbp3nQ+Nuxb8RtqlOcr7g8lEAAFMw9O9u0/YZVZFEuZTGiin2+kBeI8GSuOTMgRKM/KjRpaC4qzErMhDiwE4yKLsIOO6ueEzO9CA1W3FnYePVy6U8Fl9kfvGyJ/a+pcXyL0RcVGGy8+PF+b9szb6OqV/bGN7Q7zlPw2B8id843lTY8RvF6uZDHiz2EWi9hOMSBYlhFaNLo6Y/KXFQpxoZMRYxoDGWKFCxeVM7/6ZYj31ovPnvbRunuxZPRBzYBuSHpFIhKX23AwG/AMsKQqTe3q01Pv0gqtldmtOHUqyjNuYc6Ey6TZWRjQsSUqZz94vTlaaAl7UQwGPqyydwDfSk69IhR6wKHtS5wvccvRluNEesxY/aKmYHAxNgNKTa+s8n2kxs2CD+bnMPvhxQbg8p3w4RotC+WtahuSLGx9XW+4mhXrgvlfRP5JtylulNnq90+Pizx4nAEhAjvmovKgoaT+6NqK/VmuE2ZPZwt4cksubnQ+d+/3fr67ZdJ91yzmn8+Pxsdh1pUENZQ4sWD1cj11Cuo4u8fxdXVyQs8NPsO6sv/b+JNmkrcHmjo779pHolRL0jYHoakxoPEsIrQ0K+JUe+PGly8aE7Ab9IXNYa1CA2WPFBY++WV0u++f4ntJ5cs5P+WaMNtwc6lAYAQ4QWXDaZ8e++Qt+Xp11Hla3vTG9sSrpDpyB9Rb+51apeQEsh1oxUl/XoHUaqE3qnChzl9XFSIF/UucOdSvHhOiBCA9sXLflZ44DsXCk8WXCk9MH8y96nEtESYNwTfD8YyglMFQ6begBQbL9Pyz6py2pSkTYSMfIB6M5eqHjl+0BU3QT8hTE6PGLUucIF4EVxUmdc6CyPKDKa2YphgjnDUBH/OiNAAusBdU1j42fe+It77rQuFX00ayR3UUjISysNdGEy8CJOcHq9T3X95l9RsfTuu4ohzskvN+iGVcwuI7JhICZIQhSRuJwXkkcUcsjbECC4qZ4PZIv2+eAl1s4/8Ub18IQSeyvHhzDtqFiBe/MHvt/7zlittd1+1QvhjToZUzrxHdvOD6xgOGPEiDJk6WOp1PvVvVPG/XyTVlnHL3WTc3VTN3kRwXC4iMEpjAFBflKsxYwAQIvuHBHZHkuNpa1Yaqku20U4O4RMThQyTIRbnrAgNVt9fWH3dWvG5WzfafnLhXP6lhDi+E4Sofz1gjHgRXq5uWXlrt6flt6+iyn8fHNXQlX6tf+aClSnnz7BnJMSLAojceOk/P0HPJ2EoXyYusvE25E5P4RrSU2hjgp26At3FQ2vez7kcM7EEixdlmGXqe5cIv751o/TArAnCNklE3qHEi2AZYcjUy5+rjb96BVdUNkndm1aQ7BsvQWPmjeeS7KLInTbFhk1/P9fpdWXYIvQmIokO7MxI4hpSk2gzj7EPrCFYRlO5qiepzhJhL6AL3PxJ+NOCS6V7rj9f/PXYEdwxhKlCiai17AQjRhAixIvGkKnfvkNrfvuuWgVDpr67gRv9jXU4b8IoPs6IKftuGwLI0KOqlAhEZm+BXUVkIHEIMOaIMCYYYndDTorD7SMzUE1CHGpn/od8UtPbIAmMYYk0lghPgllFsuCeLe0b5vMv/uga2483LhX+MiKNVmtWMciBxACIEYoOE5q64xjpfOYNVPHKDqFxbBZx3H4lHnvxIn5EToZgg2LWe9vMNQoxFCVJojsxSWqP59RAig0IumIdse+DAoQILxCmJCB/RiJuykpG9YksXoTRKPpq7ALG8APmJK1bIjwNIEZIyfj1teKzBVfYHzx/jvhKvI1z6V9rDFSQRqwIry6PIr+x09v01Buo8tOjfMf6eUr6Dy5Do9fNt2fE29kz3pCFZAuxQFipFClxCGo3pNhIjScdEg8pNjT56+vEGHAFTnNovcUY50DdqclcY3oibbTbaDecqqpbzWBgNygiF0JLo9ILS4RngYnRd9kvCndfe6lQePNlwoMzxki7MVL8mmsEVi5INMvIKG9WPJBio/BftLKznZOvWaqMvGUjGjN3PJ/IMRe1yyew5yXcK/YKYdHAzJrDkKl4ie9KtUutjjjSxclYATGasQnAEKPAI5XFi52ZyVx9SgJqlnjiBzHqq2nPIH0p5rBEOEAW31zYCSk2/t9G6e7r1zueHJOFijkkE02MjGDjRUjhD/FiSa3qeuZ1WvW79/kau0T4H1ysjD5/bl7GMfnKruL2CZ4umE/DGDY1xGJE9fFU2oOAk6kkKv4MG9ZSbDjsikciPtUQolniRQO4D+DCi+ympMTjtuw0vibRTjs4Fi9q56Tfp1jEEmGQQIqNzX984i8/vNJ276WL7H/LTqW1EC9CwQ5KiHoKf1iGIVM7jvjaf/kyLn9tl9A8LjvOMWnRhQnl8be79riu7mhsT/N6fVCMhqaL3h0yjX3DfP0OHvvSEvhWR4LUIQmyFwQI7XTaiiZCs4pwaszqsXjRl5HENWWl0oYkO3X2iRdPAzvhqDx4LBEOEn1W4ie/f4n9kVUzhTdsEurGQ+iPCi9nlyLDkKmtb9DKg8VC56zp4xKTZn5b3G//f679ras6+kwRHoLyYuwXJgfAVCVJkgpZ4FohXqTUL0Murai7qIN4FIAYtY4XHCJxNuzK0ONFScRutr2oCO1MWCIcAhAvXv3Lwm3Xr5Iev/Ey4eHJY/A+LEC8OPj2RfgNDJn6K4sXn3pNrXC2cfKMWfMS7BNv5T/tuLO1Vpns1uZfBMsYwvKkiZGhpWSM47syU6SW+HjiAhfV7PEizyElicWLWSlIixd5HmvxYrTOiVoVM6EHZpm6/qmtb991te2O686T/ic/kysFMQ12IlQjXjxUrrqefQdV/vlDrg4lONDCZSuSalLu8xV5v9be5s7yuT3gn4aubcuwjHDsElb8qXFce3KirQXiRdHHdqQXnUjHi3SIWbhBiGBRRR75IV7MSkW1EC+ysz1b1pEwcuKcLBGGkLk/3tJ89XLphdsut9930SL7PzKSaONgJkLtiRdZwYEhU18cUtsLX6IVb+4UWnLTU2xZc7/iKI2/q3u/d31nkzvBH+gvwjYfImkYVpGpTUvJmOQQ2+JSabsdUjKaOF6EihuIF+0i8qYzFzWTuagOG+3SusBFEs0En+gfbIkwxED7IqTY+O8LhV9/71LhkdUzuLcgxcbQxi8i1N6l+F/drjY++TatPHJcdE6aMTneNvkW/hh/W9f+tiVOp1aLCio0Xn3RPglCpMa+4SVysgrxYlKc2JYYRzoD8WIwWxsCIdyL4Z5CvAhijI/HXVkpXEMqE6PNRjwR6zuqde+xLGHYgZSMX9ny5KffOV/6GaTYmJCDDvOQYgMKAfs+6HgRUmyw38CQqb9+yOLFV0il28cpk2cui0c5N6Ptvpvb6jrGavP1B0ouewW1h9NjPAgga3iyDTuzkqXW+HjVxUMyijACGxcDiyFHc1EZWrwYjztHpHK1OZm4PM7OdXG9UtRHAkuEYQa6wK2ZI7z5w2ttt1+zkv9dTiqqQFq8yHOQgCooNxWsUqCvqXqgQu36zWuo8i/v8/VKcgaes+CixJKMuzwHfVc5W33ZPjfUog4tlOqDYRURp1KRU3wpDqEjJQ612rHi4XH4Ol1C+gt9MeQYlhGWJR77Jo9Ah9ZM497Nz+ZK7CLnIVpAwETCVAnvoYLd+D7bs0QYAZiLqkJKxi+tlp7fvMl234UL7P9MSeRb5EFMbANoYmDFw+WWlY8PeluffplWvHNQbMnOybGnzfmmdNT2Q/dxZVlXiz9B8fpOFCDlFFnAg8WwipgZdZtd8aQmiq3xEu3gkewLNGmErryC1xa6rZ0ZdlIwmJjM/XFh05Ipwqdzx3GfjkrHlbxIZYViTSehFqOBJcIIAmLc8HDhwe9dLP76+xdLDy+fxr0viZx3qOMXWzsV3z8+8tY/929aWVxuc42fONNhH/cjrtT/na6armnubkhWHEJ67xuzeDHBoXalJ6HWxDjayVFZa1+MnHxCAxwwRYGHFLtP8rqHC8tWTxc+njNW3J4Rj5swe1QSEvpu9YAlwijAbnL3V58o/PjGDeKjN1wg/HxcLneUmRbFcI0GZRkZx6rV7j++R2qfe0OtavPalNFzL3B0TbyD7PJ/u8PlS/UhX+gzvhn7Fjgsp9j4QLxoI9osU6q5dNgPuE8TR+Iji8YLH0zKFfc5JK67d7wYKstoiTCKQBe4tfOE1+/caPvRpuXCCyNTaDUIMDDlW/DxIgwklhVZ3VNKnE+9jipe/ExqcIhZeOqCjXEVqQ97mrj52kBFbfxiCKecMawi5eRAvJgotMcn0jaYlZhj8WLARWUR8CB9VajJ1BfDChX674cJURvaNncc3rN4JvfO6GzuOBOjF+LFwVpGGkhn1IMlwigDLiqkZLxutfjsjVfa71831/5achzfNtiJUKEWFZYhXnxvj6el8N+0/KN99ra0MXn2C1dMy1g7R0xPSxJEBTMhBmlxz4ZhFSFejBdVN8SLiTbSKSGFxYtMo9pEqOaE3ScF4vrFEC+O5z7LScFVHD7R6WYoVtESYYwAYtz4WOHemy4Tf/XdDfyjCyZzHzMj4jcKdjAYlglejS2K72+fyfXPvUorS5t4z5eWqiNvvBjnL59kSxFEyH8dEGOoLGPvfWvxooS7UuPFtmSJODnZb9ohUwbsPvnX/qTw+KpZwiczWbyYGodbQYBDiRctEcYY7CZ3ff2Zre/deqn4yHc22H+Vn4lKMKHqoONFZhkJi86O1KiuP+opNmyEctdvUHP/ex3OGzOSj4Pxi+GyjDBKA4ZMQVtcerqtxcYsJHSBM1JsnBG2Cj1pZH04EU5qOjgTcJ+m5uFDSyYJ70/OFffbbJxb/0rjTJZR4BAx3XTZ5yJQVX7RAuGl/3eN7UeXLxX+mp0UGDI1lCnfPCxe3HmMdD7+Bi5/+WOhcXwWibvpSjz2ssX8iJwUPcUGixf1n4UEwyqCGCFezEgW2pKSaRsTppe5cz21thHrgXNGgnMHmBDJ/Lu3tM0ei3ctn8m/OzoTl0m94sWThWj87RCpW048MVseHn/jr2Lg5C3OxPEnNwsHqtCc94r8V+wppcucTprGCexpysQIBVxfbUAYAobfZaRQ27o5fPqKqWpKczdSPtgntBQdVZztbkUG0Qa77bPRs2/CYxkrvM/Hx7lkJV72M79Y64/af3c2UXHPGC3uyUzCjSoJn9GAxvorlol/gVEx+kdBw+6TVNZMx1bWqhObnSSbsCem/lUPINBJOcLBBePxDnBt4TNLhCaC3eTEzw4qy97ep15xsFqeS7ychJlvMxhAEJBy0SGIeFIeiT9vMp8xfwJJPFSFuz84oLYequW7YCSHtjJh1izE82NoDxAmRp+KxS6FxCseLp45xBzH942tIinCy5eKf970q8Lt+keDZtvWgqTWWjS2rEGd1OUhqVr/OyZHsI4QQ86Zyn+6/M7ChsDalghNBxMi1+CimbuOkLVv7JQ3NXbQPFVlUsRIi+kGYxlBjPE2UZg7mku4aKmSlZWMpV3Heefbu9Xm2lbs9SsyDadlhCFfPj+VumUlUekS7KrExKbvySYxEeabS4QA3KfOTpRS56Q5rV1qtl9FUoqDb584Ah1PTMQt4Mrqq1oiNCvgota309w3dijXbDuirGnuotnwOTeIjGGaGOBXrOAnJQriiulC2tpJShpKQNz7e4WWXUeU9qY2JZAMlYbHKmrvTIweD3F4FSXB7RNszA5zSfFqd+REiJkInwyJCA1AjOwN3FJ4rBAmvn6BpyVCk8NusrSvnM57d7d8xc5ysszrRYmcyqwiN7R4MTeN2tfM5tMXT1GTW1xUfmuP2LK/VHV2MHMVTqsIKFQUur1qvMurxNttnBwpEV61VPzTxl8V7tA/ihiWCIcJOx/anLK/Wln2zl514+FqMhvJzF4N0mKBIIx4ccoYkrB6Bp8xM5cmHK3Brrd3K61HG3mXES+GWoyAJkgWh3pVamOqI+NH4SOpibg93CK8jInwmiiIMGwnZRFZIMXGqlnCW7deLT3w9TXSU1mZqBoPISWjkZ6/6Lja9ft3afUL73M1iamq9P2NXP431nI5OWmCHdog+6fwHzqasJklt0nUPzID1a6bI742JZfbB0LRV4lYV7ZIwKctuvABfdnC5Dzxxrb7n3932w+f/u6yL80aw+8glOPbukiG208TELQUUuai4oGP2IB1OUSQ309IdYvqPVDKOxVVQLMnqSlLZ6JUkQq4zYlkn4IJJUpQ2z4bsC32/MBJNtR54Vzxn+vm8f9JsJEOtx8nuX00kajMzrO9aRVSbPXArwYPz2F1ei6/7/+2bbtB/yhiWJZwGMKCfxm6Vn3vYvGXN14sPLJ0qvCeQ0TdMqFau1WwVtHoj9rWpcivbpcbn36NVhwr47suX6pkXbWcHyGxEqytHAY0n1fElJ2T78tbn/zk2hXC8+dN5d/KSMb12vdMqWa3ipYIhzFGwf3+evFn37lI+MXMMbYi6AI32PT98KIKh8rqVPcL7yu1v3uLVJc0YXf4JMg4qbkbehKtnSf8+8pl4h8XThQ+hryihsttViwRngPAkKl1s4XXb7pceuDatfyzWUm0FqzhYPKjQvNEYMo3lew4Sjq/2K+2ecPV5Uxl2j9Fb2+o5gdLf8VS/qWrlol/mDiSOyzy2A/+K3w/aMvInjH6UkSxRHiOwAouWXVfYdWmFdILP97kuOP8efZXIcUGUfycZuGCrFzRKk9YkdcqZthL+zsMUCYo4TSJl9g5eabk4YPfuEB8/uJ5+MWRGVylwCGV6rWoZnFTLRGeY4AVgZSMN14q/uz7G/jHFk21fyBxyDPYiVCNl/5RxIGHC3t1XfvUkx9evUr47bKp/DtpybgJvgs2Xjyd2MONJcJzFFZwfTDL1E0XiT+9foOwZVIuOgDxoiGoYC1jOAh2iCP0x1w/X3jtiuXiH+dNFD5ziNgzUFlBzlFCI5wEWMcS4TkOxIsb5gn/uvUq2z2bVgq/T0+kDSBAI4V/tMUYrEvJHi7y+gcLj121lH9x41LpD+OyuWLIf8PEeEZrHZgPHzn1PyOKJUILKLgqxIvXrhZ/e8eX7Xesmml7MzmOtPlZvAg1qdEWIhNQ0Ptn59R9xeNbii6/QPjt+nncy6PSuWoQ2smVN8Z7cjxuzR+BNDc20lgitOgBrAikZLx1o/jo9y6SfrZoov1TG4+8sWIVBwNM7vr1p7e+++UlwvNLpwrvpybhZrCKRuWNQhEPbuvCycLH7M8+o+MjhdV31OK0fPpYwYjdh8nqd/bIV1S3yBNZeWUFl9PEGInKGJhMJy+dVt18mf3Byx8v3KN/PGiOP7lZLK+l44vr1BlVrXSc20sTEuNwx8w8Yc/CqXg7ewh59FUjiiVCizMCBbeygeZ9fEi55MN95NI2lz8dUmxARQZkigmnGAkTYXYmqrx5o/3BKx7dUqR/PGTYOdmcTpro5bFoU5AvORk5mQBDmAQyOCwRWgwIKLjHauiU17fJX9lXRhc73TSVEwihYRRiuEQYa1gxocWAYJbCd8ljhftuu1p85Nsb+MdnT8RfcAQzv9S88WKsYInQIigm3lzo+vb/bH3jpo3Sw/+1Qdqan4FKNAFCLaq+TigxS6+XoWCJ0GJQLL2jsG7jIv7/bt1ku/fSJfb/TXaQVvBJtbSMQabwPz2BjBpilHqyRApLhBaDBiozLnywsPjb68Unf3hN3F2LJnMfJDr4TqpwHBrElG8nE7WakghjidBiyEC8eOXPt+z61jXSg99czxfOHId3YIyVwMQ2QwMzo6ovDlssEVqEjGU3bem64X+2vvLdS6SHr1slPZOXzpVr1lAzaYPplilp4wmZCi131MIiGFbfX1i9aQX/59uusN29YaH9xcRE0g5FbVCDb808e8wAsURoERYgXrzg0cKj371I3HLL1Y57507gPrHbURe0/cH3A4sXAxUzwx1LhBZhBeLFLz9e+MX3vyzed/064YmpY3ARzEpstC+eCYG5o5hHkDEuKkOMIoUlQouIsOTmQueGecLLN19he/Arq/jnjFmJjSrQky0j/K1ihONE5I6XcFQ6VkcKS4QWEYNZRbLy3i2VX1oh/WnzJvuPz59rfyUhjnRShaCTa1IDXeH8KDudq8kfgXomTxmOWH1HLaJGydaCuD3Fyvx/76JfOlJLZrs8/iRKJQqJw8EKZibRhv++UPzl157e+k7gF8MTS4QWUWf3I5vTvihV1uwpIcubOkiuz09taUlc06oZ/Jvr5wuvMws6rGtoLBFaxAy7Ht6c2uyho2QfsiUloubcdFwLLqz+9bDFEqGFRZSxKmYsLKKMJUILiyhjidDCIspYIrSwiDKWCC0soowlQguLKGOJ0MIiylgitLCIMpYILSyijCVCC4uogtD/B2vLV/R+Ko+HAAAAAElFTkSuQmCC'
        pic_bgd  = PyEmbeddedImage(data=pic_str.encode()).GetImage()    # .Rescale(225,257), 原图大小是(225,257)
        pic_show = wx.StaticBitmap(parent=self, id=-1, bitmap=wx.Bitmap(img=pic_bgd), pos=(200,200), size=(300,380), style=0)
        
        # ------------ 创建一个回车按钮
        btn_enter = AB.AquaButton(self, label='Enter', pos=(200,580), size=(300,100))
        btn_enter.SetFont(font=wx.Font(pointSize=24, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        btn_enter.SetToolTip(tipString=f'Hi {current_username}, just click me.')
        btn_enter.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        btn_enter.SetRectColour('steel blue')
        btn_enter.SetShadowColour('green')
        btn_enter.SetBackgroundColour('green')
        btn_enter.SetForegroundColour('black')
        btn_enter.SetHoverColour('yellow')
        btn_enter.SetFocusColour('green')
        btn_enter.Bind(wx.EVT_BUTTON, self.btn_Enter_FCT)
        
        # ------------ 创建状态栏
        self.CreateStatusBar(number=3).SetStatusWidths([-1,-2,-1])
        self.SetStatusText(text='', number=0)
        self.SetStatusText(text='Copyright © 2022~2042 logitech(Suzhou).SEG TDE', number=1)
        self.SetStatusText(text='', number=2)
    
    def FILEPICKER_CHANGED_FCT(self, evt):
        # 手动在文本框里输入时，也会触发此事件的函数
        the_file = self.filePicker.GetPath()    # 这里得到的是一个绝对路径
        print('[选择的最新档案]:', the_file)
        if not os.path.isfile(the_file):
            return
        
        dir_name  = os.path.dirname(the_file)
        base_name = os.path.basename(the_file)
        dlg       = wx.TextEntryDialog(parent=self, message=f'Original CSV: {base_name}\n\nPlease input StartRow-EndRow:\n(e.g. 1-86;120-200)', caption='Split CSV', value='')
        res       = dlg.ShowModal()
        if res == wx.ID_CANCEL:
            dlg.Destroy()
            return
            
        try:
            val = dlg.GetValue()
            dlg.Destroy()
            res_list    = val.split(';')
            multi_group = [[int(each_group.split('-')[0]),int(each_group.split('-')[1])] for each_group in res_list]
            print('multi_group:', multi_group)
            with open(file=the_file, mode='r', encoding=get_encoding(the_file)) as f_obj:
                reader   = csv.reader(f_obj)
                all_rows = list(reader)
            #print(all_rows)
            all_base_name = []
            for n, one_group in enumerate(multi_group, 1):
                suffix_tag     = '{:02d}'.format(n)
                csv_name       = os.path.splitext(base_name)[0]
                start_row      = one_group[0]
                end_row        = one_group[1]
                saved_filename = os.path.join(dir_name, f'{csv_name}_{suffix_tag}({start_row}-{end_row}).csv')
                rows           = all_rows[start_row-1:end_row]
                with open(file=saved_filename, mode='w', encoding='utf-8', newline='') as csvfile:
                    writer = csv.writer(csvfile)
                    # 特别注意: 下面这句不能顶格写,否则会报错: ValueError: I/O operation on closed file.
                    writer.writerows(rows)  # 注意: 这里是 writerows
                all_base_name.append(os.path.basename(saved_filename))
        except:
            try_crash_error = traceback.format_exc()
            wx.MessageBox(message=f'Please find below Error:\n\n{try_crash_error}', caption='myWarning', style=wx.ICON_WARNING, parent=self)
        else:
            all_base_name_str = '\n'.join(all_base_name)
            wx.MessageBox(message=f'Successfully saved {len(all_base_name)} csv file(s) as below:\n\n{all_base_name_str}', caption='Success', style=wx.ICON_INFORMATION, parent=self)
            
    def About_FCT(self, evt):
        info = wx.adv.AboutDialogInfo()
        #logo_str       = 'iVBORw0KGgoAAAANSUhEUgAAAGEAAAAgCAYAAAACAhZqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAeMSURBVGhD7dp3rGxVFcfxa0EFUSyAigUULBR7iSU27MQEEluiooL4jyXBXmKNLZZYQiJo7MaWgFGJ0diNvWFDRQUbFrD3Lvr7zMy6WTn3nOHNy4v38ry/5Js7b5+9z5yz91prr7XnrW1rWxemPcPe84+7ry62+HuXcMfwn/DX8Krwh7CZukd4SrhM8DxvCVtR1w0PDJcIfwpvDL8IK+sVwQIUB4bN1LXDeaGe51/hzqF0xXDVBZfVsIk6JtRz/iPcOKykiy/+/nHxl34d/j3/uGk6PFxl/nEmVnbT+ce1vcI7wicWPCJspv4WTD6Zu3/OP+64ahG2ms4I58w/zuTlTDgJoQeH6y3YN1zUxJMPCzMv3qqL8LNw3/C68PbwgPDlQLy0ey5LvCjJxB8VHhrsJzu1CAcE4cINhIZVda1g/HXCHhom9NVwQrDpfUTDQia9h8u/LP5OidVdP7A8e8iqOigcEXjfpTQskfm8YP5x7ZLBGN+7v4aFeLI+Pw/6rGdHzw1Pn3+cuf5Nwk9m/5pLTL5PeFDwQl5MHPxp+Fh4c/h2mJIM52HBPWy6lwsm70dB2HF/z6Lfd8Ozglh/p+CBvx+eER4Tbh+ODFcOJHSdGd4UPqphIXuIe9w62F98x2/C58Ip4QthSlJji3//wNikybLGc8OHAg+t+blneE+wQJ7Tv28bjg8W8NLhl4Envzx8LQih4PHrWahFqB3+V+EaoSRT8iV1fYzzg0keE2sQz8fGjWEReMjbBm0W6YOtbYgFIv2eGn4XxvrBiz8xjMk+w/PGxhXfCbIikkr/PWg3qeaK4QzHQMZ37zCqqUXgviyn32gKaaTw0cUCvxLG+k/xxWARXtPaPh9o2SI8MpDaYniNkfSUt6gxJQZzVhj2m+IWgWfWIuwInkMo3qDhIlwtUJ8IKELUFA8JLE8o6te5e+XJLPLVoV8XenyXsDY2ngUdG4jLV/uXgnDC+p4dhIW69oHwpGCfMSnCZF0zocKCkGKCHxw8Q13/bTgkkPu/O9Q1nB0sqnFPDt2g3hXEeqFxuAhfDzxNdHhOMG/9unfYoOEiiLceThysdvFbrOuyMb8sVB+YeLpR6A/Hmrl6l/EvDtXHIggl9PpQ7eJ+3xQtSl07UcNC7wzVLoTVBHcxEp5R/V4YSFix4Vf7Z8LQYs0L4zgt2DfoXqG/5ydDr3HIicTvQ/UxFxuSor4INhFp1GNbG6SJY2JBnwrV74fBBtvHK+dvGcbEY/p44U/ba1tbXwQvL3OqazZsEkJ9d7WfFEzizcPNGryCFVe/Twf3fklrM2G3C2OS0dhsSzbiWgSLOBXzpdp1fxv4lcJMUymqm3HfkkGygjHpywJLVwg282714jzG5KFYVknmxeLsMatI6txT0OOC75QxCXsFKzRxJVZ7zSB1Lsm2Pjv/uEGey6SPSXj7wfzjBvXi0zvP0lOaWgSW2FdbrF9WjvOekrE8odcQ0t5lEgJLNmVjhaZV5KV63cGbWdvlB1jkCiXEg8T2PpYnrPr9ZD+aGjdstxAzTS2CDh6kxCv2m38clbqixDNMep9YBYuFmdINF3/pz8GiC3OryAR0C2XNQsB7B5we3rrA51ODwqm/L6+wYKuKAWJMU+3rGm7MHsAeUG14ZRiTsNOzFUWJL1TsVBsrqDx+KONNQvWtsNezox3ZE4QV+Xu1vy9MyT265dPTQo0Vch4dxqR6ts+U+p7gPRjcmPocC03rRj3lCULR+8OPZ/+ay0O5kdhbukNwotmLO+f+vujDocZblOeFR4VuYdI743ssZ510oZYzkIxHzC85n2E4PazSrYJ4L/vp3m1fEtOJF74geN4ab+HuFxRjkA7vUg094eqB5LnVXnwvcOuPB1lPv+bl9gklOXq/DmW78VI5Rxf9mvGONOgNodp3xBPIkYpQWNdgsuXqjw8MpFfSvLYnIN0bCscbnndYdAqbjkR6sbZTnlB6fqgOHlK2UJJH17VlfCsomIbqqd8yvhFuEErOguqaheuLoG9dc87U5fTVsURdX4ZFd75T8h0nh7G+QyyK5/Vjk/ClTVE2NgfU51gqvWERXhqqgwJt+MuadG+qnLehOcAbLcUXelxQ7I2Nt+jGV5Ve6nm1Ba6wIOtRydY1LzeUwounVZ8hUu5nhtl5/kBC9BNCr6w7MkE1iFScjg51zbtM/bL2olD9hOn1gq7i7qHBCtpAuZbc2mJ0SeO8nILHhDlSFpr0HcupxVWwEve1SHcNHtIJIndW1VbuTjZLDynD8j1OXKl+1HEf9/R7uFTT88uCGMhQsrG7BSGDUUlhTaBqWyhlFMskGtw9KDKluoyNMRjLC0om8zbB/YVXi99/7ygJUzXHwrj7TNUbu0yOI7wwHOF2DTddZ0Lis/jr/KZv/ltBqyYJW0Z9Y7Vhjbl+qfdVcbLybe0CDeuMnsV0SRmlhtVv6nhkWzshu38vnsQ/qaKaglfYFxxpDzfszf7fE7udeIONqE+yX59sst9sbYVftJaFrW3tpMYKoDFkWJv9n852az089AKro8BRpwx/CPm/0f8y9ZJrK/Hl3c6PnHpW3q142ta2Nktra/8FWOH5PTAD+jIAAAAASUVORK5CYII='
        #self.logo_Logi = PyEmbeddedImage(logo_str.encode()).GetImage() # .Rescale(97,32), 原图大小是(97,32)
        info.SetIcon(wx.Icon(wx.Bitmap(self.logo_Logi)))

        info.SetName(app_name)
        info.SetVersion(f'({latest_ver})')
        info.SetCopyright('© Suzhou Engineering Group -- TDE Team')
        info.SetDescription('This software is compatible for both UTS1 and UTS2 *.csv format.')
        info.SetWebSite('https://drive.google.com/drive/folders/1jLG9KKM_CajmqWIAkFJ6QB63-q_kfiMf')
        info.SetLicence('This software is allowed for logitech internal use only.')
        info.AddDeveloper('Bright Zuo')
        info.AddDocWriter('Bright Zuo')
        wx.adv.AboutBox(info)

    def btn_Enter_FCT(self, evt):
        self.algorithm_Hist_custom = self.choice_algo.GetStringSelection()
        self.Index_var_custom      = self.comboBox_X.GetValue()
        self.n_digit_custom        = self.n_digit.GetValue()
        self.mark_color_custom     = self.mark_color.GetValue()
        self.empty_UID_included    = self.empty_UID.GetValue()
        self.debug_mode_custom     = self.debug_mode.GetValue()
        
        print('algorithm_Hist_custom:', self.algorithm_Hist_custom)
        print('Index_var_custom:',      self.Index_var_custom)
        print('n_digit_custom:',        self.n_digit_custom)
        print('mark_color_custom:',     self.mark_color_custom)
        print('empty_UID_included:',    self.empty_UID_included)
        print('debug_mode_custom:',     self.debug_mode_custom)
        self.Destroy()
        self.Refresh() # 特别注意: 发现有时这个Login界面在用户点击[Enter]后,下一个主界面已出现,但由于PC卡顿这个Login界面依旧存在,故这里刷新一下.
        
    def OnExit_login_GUI(self, event):
        self.Destroy()
        sys.exit()  # 当有两个(含)以上GUI时, 必须主动给第一个GUI设计关闭函数执行 sys.exit(), 响应用户使用鼠标来点击框架右上角的[关闭]或在任务栏右击再左击[关闭窗口]的事件.
        # os._exit(0)
        
class MyGUI(wx.Frame):
    
    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        self.Bind(event=wx.EVT_CLOSE, handler=self.OnExit_GUI)
        self.screen_W, self.screen_H   = wx.DisplaySize()    # 确认最新屏幕的分辨率
        self.left_panel_W              = 200
        self.temp_folder               = 'myFootprints'
        self.pure_LOG_folder           = os.path.join(self.temp_folder, '01_LOG_pure')
        self.Dashboard_data_folder     = os.path.join(self.temp_folder, '02_Dashboard_data')
        self.filter_LOG_folder         = os.path.join(self.temp_folder, '03_LOG_filter')
        self.Charts_data_folder        = os.path.join(self.temp_folder, '04_Chart_data')
        self.dashboard_csv             = os.path.join(self.Dashboard_data_folder, 'YieldRate_Top5Reason_Top5ErrorCode_Top5ErrorLine.csv')
        self.lpanel_bgc                = (112,146,190)  # 蓝灰色
        self.rpanel_bgc                = '#A7CAF0'      # 即 UTS2 bgc
        self.btn_bgc                   = (255,255,255)
        self.btn_fgc                   = (0,0,255)
        self.scroller_bgc              = (240,240,240)  #'#A7CAF0'
        self.H_grid                    = 25 + 21*1 + 20 # 20Px是预留给水平滚动条
        self.Hist_W_custom_max         = 770
        self.Hist_H_custom_max         = 470
        self.Hist_W_custom             = 700
        self.Hist_H_custom             = 470
        self.flag_Grid_custom          = True
        self.flag_Label_custom         = True
        UTS1_format                    = ['SeqNum','Status','Comment','Test_Start_Time','Test_Duration','Failed_Tests']
        UTS1_format_old                = ['SeqNum',' Status',' Comment',' Test_Start_Time',' Test_Duration',' Failed_Tests']
        UTS2_format                    = ['SeqNum','Status','Comment','ErrorLine','ErrorCode','FailValue','Test_Start_Time','UnixTime','DurationTime']
        self.UTS1_format_str           = ','.join(UTS1_format)
        self.UTS1_format_str_old       = ','.join(UTS1_format_old)
        self.UTS2_format_str           = ','.join(UTS2_format)
        self.miniFrame_query           = None
        self.miniFrame_PolyLine        = None
        self.miniFrame_PolyLine_Pass   = None
        self.miniFrame_fail_data       = None
        self.miniFrame_summary_7d      = None
        self.miniFrame_total_dashboard = None
        self.miniFrame_fail_dashboard  = None
        self.miniFrame_search          = None
        self.miniDialog_debug          = None
        
        self.SetSize(size=(gui_W,self.screen_H-50))
        self.Center()
        self.Maximize(maximize=True)
        #self.SetBackgroundColour('red')
        
        if os.path.isdir(self.temp_folder):
            shutil.rmtree(self.temp_folder)
            
        # ------------ 创建分割窗口
        self.ParentWindow = wx.SplitterWindow(self)
        self.lpanel       = wx.Panel(self.ParentWindow)                         # 创建左面板
        self.rpanel       = wx.Panel(self.ParentWindow,style=wx.BORDER_STATIC)  # 创建右面板
        self.lpanel.SetBackgroundColour(colour=self.lpanel_bgc)
        self.rpanel.SetBackgroundColour(colour=self.rpanel_bgc)
        self.ParentWindow.SplitVertically(window1=self.lpanel, window2=self.rpanel, sashPosition=self.left_panel_W)
        #self.ParentWindow.SetSashPosition(self.left_panel_W)   # 设定饰带的初始位置
        self.ParentWindow.SetMinimumPaneSize(self.left_panel_W) # 设定最小的窗口不能小于200
        
        # ------------ 调用左面板
        self.left_panel()
        
        # ------------ 调用右面板
        self.hbox_right = wx.BoxSizer(wx.HORIZONTAL)            # 这里是水平布局管理器
        self.right_panel()
        self.hbox_right.Add(self.scroller,          0, wx.ALL|wx.EXPAND, 0)
        self.hbox_right.Add(self.Project_Specs_pnl, 1, wx.ALL|wx.EXPAND, 0)
        self.rpanel.SetSizer(sizer=self.hbox_right)
        self.rpanel.Refresh()
        
        self.Show()
        
    def left_panel(self):        
        # ------------ staticBox_1
        self.widget_LOG = wx.TextCtrl(self.lpanel, style=wx.TE_MULTILINE|wx.TE_READONLY|wx.BORDER_STATIC)
        btn_open        = wx.Button(self.lpanel, label='Select', style=0) # wx.NO_BORDER
        btn_open.SetBackgroundColour(self.btn_bgc)
        btn_open.SetForegroundColour(self.btn_fgc)
        btn_open.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        btn_open.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        btn_open.Bind(wx.EVT_BUTTON, self.btn_open_FCT)
        staticBox_1      = wx.StaticBox(self.lpanel, label='Step-1: CSV File(s)')
        staticBoxSizer_1 = wx.StaticBoxSizer(box=staticBox_1, orient=wx.HORIZONTAL)
        staticBoxSizer_1.Add(window=self.widget_LOG, proportion=1, flag=wx.ALL|wx.EXPAND,           border=5)
        staticBoxSizer_1.Add(window=btn_open,        proportion=0, flag=wx.TOP|wx.BOTTOM|wx.EXPAND, border=5)
        
        # ------------ staticBox_2
        self.check_box_1 = wx.CheckBox(self.lpanel, label='Unique UID')
        self.check_box_2 = wx.CheckBox(self.lpanel, label='Include defect')
        self.check_box_1.SetValue(state=True)
        self.check_box_2.SetValue(state=True)
        self.check_box_1.Bind(wx.EVT_CHECKBOX, self.check_box_1_FCT)
        self.check_box_2.Bind(wx.EVT_CHECKBOX, self.check_box_2_FCT)
        Interval_breaks = wx.StaticText(self.lpanel, label='Interval breaks:')
        self.slider     = wx.Slider(self.lpanel, value=10, minValue=5, maxValue=20, style=wx.SL_AUTOTICKS|wx.SL_LABELS)# wx.SL_HORIZONTAL可使当前值在滑块的下方
        self.slider.SetTickFreq(freq=1)        # 相隔几个单位画一个刻度(即相邻刻度代表的大小)
        self.slider.Bind(wx.EVT_SLIDER, self.slider_FCT)
        hori_box = wx.BoxSizer(wx.HORIZONTAL)
        hori_box.Add(window=Interval_breaks, proportion=0, flag=wx.LEFT|wx.EXPAND, border=0)
        hori_box.Add(window=self.slider,     proportion=1, flag=wx.LEFT|wx.EXPAND, border=0)
        staticBox_2      = wx.StaticBox(self.lpanel, label='Step-2: Filters')
        staticBoxSizer_2 = wx.StaticBoxSizer(box=staticBox_2, orient=wx.VERTICAL)
        staticBoxSizer_2.Add(window=self.check_box_1, proportion=1, flag=wx.LEFT|wx.EXPAND, border=5)
        staticBoxSizer_2.Add(window=self.check_box_2, proportion=1, flag=wx.LEFT|wx.EXPAND, border=5)
        staticBoxSizer_2.Add(sizer=hori_box,          proportion=2, flag=wx.LEFT|wx.EXPAND, border=5)
        if login_GUI.algorithm_Hist_custom == 'Minitab(With Fit)':
            self.check_box_2.SetValue(state=False)
            self.check_box_2.Disable()
            
        # ------------ staticBox_3
        self.checkBox_all = wx.CheckBox(self.lpanel, label='Select all')
        self.checkBox_all.Disable()
        self.checkBox_all.Bind(wx.EVT_CHECKBOX, self.CheckBox_all_FCT)
        self.checkBox_special = wx.CheckBox(self.lpanel, label='Select #var only')
        self.checkBox_special.Disable()
        self.checkBox_special.Bind(wx.EVT_CHECKBOX, self.CheckBox_special_FCT)
        hori_box_select = wx.BoxSizer(wx.HORIZONTAL)
        hori_box_select.Add(window=self.checkBox_all,     proportion=0, flag=wx.LEFT|wx.EXPAND, border=0)
        hori_box_select.Add(window=self.checkBox_special, proportion=0, flag=wx.LEFT|wx.EXPAND, border=0)
        self.var_options = wx.CheckListBox(self.lpanel, choices=[])
        self.var_options.Bind(wx.EVT_CHECKLISTBOX, self.checkListBox_click_box)     # 只有手动用鼠标点击方框, 才会触发.
        self.var_options.Bind(wx.EVT_LISTBOX,      self.checkListBox_click_text)    # 只有手动用鼠标点击文本, 才会触发.
        staticBox_3      = wx.StaticBox(self.lpanel, label='Step-3: Variables')
        staticBoxSizer_3 = wx.StaticBoxSizer(box=staticBox_3, orient=wx.VERTICAL)
        staticBoxSizer_3.Add(sizer=hori_box_select,   proportion=0, flag=wx.LEFT|wx.TOP|wx.BOTTOM|wx.EXPAND, border=2)
        staticBoxSizer_3.Add(window=self.var_options, proportion=1, flag=wx.BOTTOM|wx.EXPAND, border=5)
        
        # ------------ staticBox_4
        # self.btn_analytics = wx.Button(self.lpanel, label='Analytics Report', style=0)# wx.NO_BORDER
        analytics_str = '/9j/4AAQSkZJRgABAQEASABIAAD/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAXACADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9Wv8AgjjrN5r37BPh24v7y8v7ltX1pTNczNNIQNVugAWYk8dB6CvePE3x18E+C/EP9j6z4x8K6Tqx2Ysr3VoLe4+f7n7t2DfN2457V+Xnwb/4Kwr/AME3v2KvhbpbeBJfGH/CVTeJdR81NWFj9m8nWriPZgxPuzuznjGO9fNX/BVDxlB8Xv8Ago/4X8WNp6Wf/CUaL4S1b7OxErW4niil8vfgbtu7GcDOOgoA/f68mNvaSyL96NCwz3wK/OL/AIJc/wDBYn4jftvftZTeAvFHh3wZpmkppN7fifTIrlbjfDJEqjMkrLtIc54z0rxrwp+278XtT/4LdzfD24+IfiKbwP8A8LBvdK/sRnj+yfZVSXbDjZnaMDvnjrXmf/Bvic/8FILr/sW9U/8AR8FAHF/FfQvC3xR+FPgrwb4sb4geG9e+G02vafcHTNL03Uba7+16pNcqys99Ew2ghSNvJzzWl8cj8NPjX8XvC3itr74rab/wjOj6JpH2UeH9Kl+0jTYo4xJu/tIbfM2Zxg7c96KKAOi0L4h/DXRf+ChL/HrzPitJI3ie48Sf2H/YelKuZVceT5/9o5wN/wB7bzjpVz/gnL40+HP7FX7U9v40t5Pip4mm1K1m0dLKTQ9LtFQ3U0WJC41Fj8u3pjnNFFAH/9k='
        analytics_pic = PyEmbeddedImage(data=analytics_str.encode()).GetImage().Rescale(32,23)
        self.btn_analytics = buttons.GenBitmapTextButton(self.lpanel, bitmap=wx.Bitmap(img=analytics_pic), label='Analytics Report',style=wx.ALIGN_CENTER)
        self.btn_analytics.SetBackgroundColour(self.btn_bgc)
        self.btn_analytics.SetForegroundColour(self.btn_fgc)
        self.btn_analytics.SetBezelWidth(1)
        self.btn_analytics.SetUseFocusIndicator(flag=False)
        self.btn_analytics.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        self.btn_analytics.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        self.btn_analytics.Disable()
        self.btn_analytics.Bind(wx.EVT_BUTTON, self.btn_analytics_report_FCT)
        staticBox_4      = wx.StaticBox(self.lpanel, label='Step-4: Histogram')
        staticBoxSizer_4 = wx.StaticBoxSizer(box=staticBox_4, orient=wx.HORIZONTAL)
        staticBoxSizer_4.Add(window=self.btn_analytics, proportion=1, flag=wx.TOP|wx.BOTTOM|wx.EXPAND, border=5)
        
        # ------------ staticBox_5
        # self.btn_dashboard = wx.Button(self.lpanel, label='Dashboard', style=0) # wx.NO_BORDER
        dashboard_str = '/9j/4AAQSkZJRgABAQEAYABgAAD/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAXACADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9yPj7+0J4L/Zc+FOq+OPiB4j0zwr4W0VA93f3sm1FJOFRQMs8jMQqogLMxAAJOK+L9c/4KyftDfGFXvvgX+xn8QPEvhhhvtNc8a6zbeFf7Rj7SRWk2ZtjdVL7SQc4HSvctJ+BNr+1Z+1bd/EXxxajVPDPws1CTSPAGi3SbrOHUIgUvtaeM5V7kSl7WBm/1KW8jrhp2I9g+OXx/wDBH7M/w9uPFnxA8VaH4P8ADdrIkUmoatdpbQB2PyoGY/M5wcKuScHA60Afm7c/8HH3i/8AZe+IGm6D+1F+zD49+ENrqkvkwaxp91/a1rI2cfIDHGsuOMiGWR8HhGPFfo98If2gvC/x4ivpvCt5PqlnpwiW4uvsssMMU0ibzbkyKpE8alfNiI3RMwVwrgqPz/8AiD+25q3/AAWi+P03wR/Z9ZrT4QeE7yC7+IHxWa0VnjCsGjstEMikJdyYO28xviAaSMDajt8y/sc/tP8Ajr/glx/wXq8RfADxbrEl78MvHuo2+h6PZLlLPS4Zo/M0ae3jLEI3zC2mOSZZHeWQs4yQD9wPDnh238MaYLS33CLzZZj7tJI0jH8WZj+NfHP/AAW8/wCCVWrf8FVP2fvDegeHfFVn4W8R+DtZOrWJ1GJ5dPvt8LwvHNs+dSFfKuobBBGCGJBRQB23/BIn/gnlN/wTL/Y1074b3uvQeJdam1G51rVr+3gMFs1zOVykKn5vLRERAzfM23OFyFXy/wDbf/4IX+Hf20/+ChPw/wDj5ceO9Z8N3HhF9NbUdHtbJJRq32C6NzAUnLgwEltr/K+VAxtPzUUUAf/Z'
        dashboard_pic = PyEmbeddedImage(data=dashboard_str.encode()).GetImage().Rescale(32,23)
        self.btn_dashboard = buttons.GenBitmapTextButton(self.lpanel, bitmap=wx.Bitmap(img=dashboard_pic), label='Dashboard',style=wx.ALIGN_CENTER)
        self.btn_dashboard.SetBackgroundColour(self.btn_bgc)
        self.btn_dashboard.SetForegroundColour(self.btn_fgc)
        self.btn_dashboard.SetBezelWidth(1)
        self.btn_dashboard.SetUseFocusIndicator(flag=False)
        self.btn_dashboard.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        self.btn_dashboard.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        self.btn_dashboard.Disable()
        self.btn_dashboard.Bind(wx.EVT_BUTTON, self.btn_dashboard_FCT)
        staticBox_5      = wx.StaticBox(self.lpanel, label='Step-5: Dashboard')
        staticBoxSizer_5 = wx.StaticBoxSizer(box=staticBox_5, orient=wx.HORIZONTAL)
        staticBoxSizer_5.Add(window=self.btn_dashboard, proportion=1, flag=wx.TOP|wx.BOTTOM|wx.EXPAND, border=5)
        
        vbox_left = wx.BoxSizer(orient=wx.VERTICAL)
        vbox_left.Add(sizer=staticBoxSizer_1, proportion=0, flag=wx.ALL|wx.EXPAND, border=5)
        vbox_left.Add(sizer=staticBoxSizer_2, proportion=0, flag=wx.ALL|wx.EXPAND, border=5)
        vbox_left.Add(sizer=staticBoxSizer_3, proportion=1, flag=wx.ALL|wx.EXPAND, border=5)
        vbox_left.Add(sizer=staticBoxSizer_4, proportion=0, flag=wx.ALL|wx.EXPAND, border=5)
        vbox_left.Add(sizer=staticBoxSizer_5, proportion=0, flag=wx.ALL|wx.EXPAND, border=5)
        
        self.lpanel.SetSizer(sizer=vbox_left)
        
    def right_panel(self):
        # 注意: 只有这两种情况，才会调用此函数: (1)第一次开启程序时. (2)用户在点击【Select】按钮时调用 btn_open_FCT(...)时. 
        self.screen_W, self.screen_H = wx.DisplaySize()     # 确认最新屏幕的分辨率
        self.scroller = wx.ScrolledWindow(self.rpanel, pos=(0,0), size=(gui_W-self.left_panel_W-20, self.screen_H-70)) # self.scroller的长度设置为gui_W-self.left_panel_W-20, -20是实验验证的结果
        self.scroller.SetScrollbars(pixelsPerUnitX=1, pixelsPerUnitY=1, noUnitsX=-1, noUnitsY=-1)
        self.scroller.SetBackgroundColour('white')
        
        pic_str = '/9j/4AAQSkZJRgABAQIAHAAcAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCADIAfQBAREA/8QAHAABAAMBAQEBAQAAAAAAAAAAAAYHCAUEAwIB/8QAWhAAAQMDAQMHAwwMCwYGAwAAAQACAwQFBhEHITEIEhNBUWFxFIGRIjI1NjdGYnN1obHDFRdCUlaChJSywdHSFhgjMzRTVXJ0krNDVJOVotNjpMLh8PFmpeP/2gAIAQEAAD8Av9ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERcHJszx/D46aS/V/kjakubEehkk5xbpr6xp04jio79u3Z5+EP/kqj/tqQYxm2O5j5V9gLh5Z5LzOm/kZI+bzteb69o115ruHYpAiIiIiIiIiIiKPZfmtkwm2CtvFQW9IS2GCMc6SYjiGju6ydAN2/eFVzeUrazUhrscrBBzt7xUNLtO3m6aa92qtXFcvs2ZWvy+zVXSsaebJG4c2SJ3Y5vV9B6iu6iIiIiIiIiIiIiLi5JllkxCjiq77W+SQTSdEx/RPk1doTpowE8AVGft27PPwh/wDJVH/bXaxvaDi+X1stJYrn5XPDH0r2eTyx6N1A11e0DiQpMiIiIiIiIiKiOUv7HY78bP8AQxZ3V/8AJl99P5J9ctAIiIiIiIiIiIix/tnu9Tddp91ZO8mKjc2mgZruY1oGuni4k+dQBWTsMvNTbNptFSxPPk9wZJBOzqIDC5p8Q5o8xPatbKvcv2xY9hV+fZ7lR3OWobG2Qupoo3M0dw3ueD8y4P8AGOw/+zb5/wACH/uqxcTyiizHHoL1b4qiKmmc9rW1DWteC1xadQCRxHau2iIiIiIiIiIipflI+020/KH1b1mhXRybvbldvk/6xi0uiIiIiIiIiKiOUv7HY78bP9DFndX/AMmX30/kn1y0AiIiIiIiIiIiLM+3bAK+iyKfKqGnfNbqwNdUmNuvQSAAEuHU06A69pI3btaYV57Bdn9eb0zLbjTyQUkEbhRCRuhme4FpeAfuQ0nf1kjTgtGLKG373UZ/8JD9BVXrW+wr3KLb8bP/AKjlZCIiIiIiIiIiKl+Uj7TbT8ofVvWaFdHJu9uV2+T/AKxi0uiIvJcrlS2i3y11bJ0cEQGpDS4kk6BoA3kkkAAbySAo5Dn9I6oe2qt9TSwRvDJpnTQSeTknmjpmRyOdGNd2pG77rRS5EREREVEcpf2Ox342f6GLO6v/AJMvvp/JPrloBEXEuuY41Y3mO53230srdxikqG8//Lrr8y4o2uYE6XoxklLztSNSx4Hp5ui79qyew3wgWu80FY4jXmQVDXOHi0HULrIiIi5F1yrH7GS26XqgpHga9HNUNa/zN11PoXB+23gfS9H/AAkpedw15r9PTzdF3rVlWP3whtrvVBVv+8hna53+XXVddEQgEEEag8QVx24njbKvytmP2ptTrr0woow/Xx01XYRZQ2/e6jP/AISH6CqvWt9hXuUW342f/UcrIRF4bne7VZohLdLlR0TDwdUzNjB8NTvUZm2tYHA/mPyWkJ+A17x6Q0hdK3Z7iV2kEVFkVtllJ0bGahrXHwB0JUi4jUIiIi5V1yaxWPddbxQ0btNeZPO1rj4NJ1Kj7trmBNl6M5JS87UDUMeR6ebouza8yxq9Pay2363VMjtwiZUN55/F11+ZdxFS/KR9ptp+UPq3rNCujk3e3K7fJ/1jFpOeeGmhfNPKyKJg1c+Rwa1o7yeCitZtQwegeWTZNQFwOh6F5l/QBX1t+0jDLm8MpcltxeeDZZhET4B+ilDXNewPY4Oa4agg6ghcPK6aplt1LVU1O6qfQ1kVW6mZ66VrD6oN7XAHnAdZaAq8EcU1fcXW+sbeKq409dTwUPQljqR1ROX/AMppG0hnNLS7pDq0sIbrztBbdLAaajhgMjpDFG1nPdxdoNNSvqiIiIiojlL+x2O/Gz/QxZ3V/wDJl99P5J9ctAKM5pnVmwW1eWXOUulk1FPSx75JnDsHUB1k7h46A5kzDa/lOWySReVut1vJ9TSUji3UfDdxd9HcFAeJ1KL+tc5jw9ji1zTqCDoQVZeF7bclxmaOC4zPu9t1AdFUP1lYPgPO/wAx1HhxWmsYym05fZo7paKjpYHbnNdufE7ra4dR/wDsahdlFw8ry20YbZ33K71HRx682ONg1kld960dZ+YdeizJmW2nJ8olfDR1D7TbtSGwUryHuHw5OJ8BoO5VwSXOLnEkk6knrX8X9BLXBzSQQdQR1L7+X1n+9z/8Qp5fWf73P/xCrV5PtVUTbR5Gyzyvb5BKdHPJHrmKTcpWeaD+DHRSyR6+V68xxGv8yqE8vrP97n/4hWg+TbPNPb8hMsr5NJYNOe4nTc9QLblV1MW1W4sjqJWNEUG5ryB/NtVZySySv58j3Pd2uOpX5X2jq6mJgZHUSsaOpryAtScn2WSbZxI6WRz3eXyjVx1PrWKza+vpLZQzVtdUR09LC3nySyO0a0d5Wcc82+XK5yyUOKF1BRAkGscP5aXvbr6wfP3jgqcqquprah9RV1EtRO86vkleXuce8neV8UUxxDabk2GzRiirnz0LdA6iqXF8RHY0fceLdPOtRYJtAtOe2s1NC4w1cQAqaSQ+riJ6+9p6j9B3KWIuPkuT2nErPJdLxUiGBu5rRvfI7qa0dZP/AN6BZmzTbdkmSyS01tldaLadwjgdpK8fCk4+Zug8VWb3vke58jnOe46lzjqSV+UU8xDa5lOJSxxtrHXC3t3Gkq3F4A+C7i3zbu4rTmE55Zs6tfldslLJ49BUUshAkhPeOsdhG4+OoVfcpH2m2n5Q+res0KcbNM6iwGtu1xdTGpqZqPoaaLXRpeXtOrj2AA8OPDvHFyfM7/l9Yai83CSYa6sgB5sUf91g3Dx49pK4KKXYdtHyLCqlhoKx0tEDrJRTuLonDr0H3J7x8/BavwvM7ZnFhZc7c4tIPMnp3kc+F/Ye7rB6x5wJEiIiIiIqI5S/sdjvxs/0MWd1f/Jl99P5J9crqybIaPFsdrLzXu/kKZnO5o4vcdzWjvJICxflGTXHLr9UXe5yl00p0YwE82JnUxo6gP2niVxl2bDiV/yeUx2W01NZodHPY3RjT2F50aPOVLX7C8/bD0gtMLnf1Yq4ud+lp8/UoXesevGO1YpbxbqiilO9omYQHDtaeBHguapTgWb1+C5HFcKZzn0ryGVdNrumj14f3hvIPUe4kLZtuuFLdrbTXCilEtLUxtlieOtpGoX4u10pLJaaq518vR0tLGZJHdw7O0ngB2rGGcZncM4yKa51ri2IaspqcH1MMeu4Dv6yes+YKNrqWTG71klSaezW2prZG+u6JmoZ/edwHnKmY2F5+Yef9iYQ7+rNXFzv0tPnUQv2K37GJxFerVU0ZcdGukb6hx+C4atPmK46K/NgmDXqhu7MqqY4GWyoo3xwkTBz36ubv0brp60666HuX75TXvW/K/qVQC0RyaPY7IvjYPoeuPtc2dZbkO0SuuVps0tTRyRxBsrZGAEhgB4uB4hVBfLDdMbuRt93pHUtWGh5jc4E6HgdxIXOUosuzrLchtkdytNmlqaOQkMlbIwAkHQ8XA8QtJ7FseuuM4M+gvNG6kqjWSSCNzmk80tbodxI6iqe227RJcjvslgt0+looJOa/mHdUTDi49rQdw856xpUqk2J4BkeaTOFnoS6Bh5slTKeZEw9hceJ7hqe5WXT8mq7Og1qchoo5tPWxwPe3XxJH0KLZRsRy3G6aSrjihudIwFzn0ZJexo63MIB9GqrddjFslr8SyClvFufpNC71TCfUysPrmO7j/79S2tYb1SZFYaK8ULudTVcQkbrxb2tPeDqD3hemvrqa12+or6yURU1NG6WV54Na0akrGe0DOK7Osjlr5y6OjjJZSU2u6Jn7x4k/qAUUXUsmOXnI6k09mtlTWyN9d0LCQz+8eDfOVMxsLz8w8/7Ewh39WauLnfpafOohfsUv2MTNivVrqaMuOjXSN1Y7wcNWnzFcdWpsPxTILllsF8t88lDbqJ+lRU83UTDrhAO52o49m48dFYfKR9ptp+UPq3rNCLq2PGb3ktQYbNa6mte31xiZq1n953AecqXu2HbQGwdJ9hYy7TXoxVw879LT51CrvY7pYK00d2oKijqBv5kzC3UdoPAjvC8CnmyPL5MTzqkL5S2grnNpappO7Rx0a78VxB17NR1rYaIiIiIiojlL+x2O/Gz/QxZ3V/8mX30/kn1y+XKPyN7qu141C8iNjPLJwPunElrAfABx/GCoVWDsn2dHPL9I6rL47RRc11S5p0MhPrY2nv0Op6gO0ha1oLfR2qhioqCmipqWFvNjiiaGtaPBelc+9WO25Fa5bbdaSOqpZRvY8cD2g8QR2jesf7RsGqMDyh9vc50tFKOlpJ3De9mvA9XOB3HzHrUQWluTrkb67Gq+wzvLn26USQ6n/ZyakgeDgT+MvPyjsjfS2a247A8g1jzUVAB4sZuaD3Fx18WBZxUy2aYJNnmTtoi58VvpwJayZvFrNdzR8J3Aec9S19Z7LbcftkVutVHFS0kQ0bHGPnJ4knrJ3le9eW5WyivFvmoLjSxVVLM3mvilbqCP29/UskbVtnrsDyJopee+01gL6V7t5Zp66MnrI1G/rBHeoCtB8nDJZJI7njM7y5sQ8spgT60Ehrx4alh85Xz5TXvW/K/qVQC0RyaPY7IvjYPoer3WUNv3uoz/wCEh+gqr1rfYV7lFt+Nn/1HLvbSMidi+AXa5xP5lQIuigI4iR55rSPDXXzLFXE6lSLB8WlzHL6CyxucyOZ3OnkH3Ebd7j46bh3kLaVrtdFZbZT263U7Kekp2BkcbBuA/WesnrK9aLMm3vBaew3anyG2wNio7g8sqI2DRrJ+OoHVzhqdO1pPWqbWi+ThkD57Vdcfmdr5M9tTAD96/c4eAIB/GK9/KJyN9uxWiscDy19ylLpdP6qPQ6edxb/lKzKpds5wefPMpjtwe6Kjib0tXM0b2Rg6aD4RO4ec9S2DZbJbcetcNttVJHS0sQ0axg495PEk9ZO9dBea4W6jutDLRXCmiqaWVvNkilaHNcPBUdXcnWGXNI30leYsckBkkYTrNGdf5tpPEHXc48ADrqdNbvtdrorNbYLdbqZlPSU7eZHEwbgP1nrJ4kqouUj7TbT8ofVvWaFIcIxabMsuobLG90bJnF00oGvRxtGrj46bh3kLZ9mstux+1w2210sdNSQjRrGDj3k9ZPWTvK96jubYhQZrjdRa6yNnSlpdTTkb4ZNNzgeztHWNVieqppaOrmpZ2Fk0L3RyNPU4HQj0hfLgdQt2Y5XuumL2i4PJLqqihnJPWXMDv1rpoiIiIiojlL+x2O/Gz/QxZ3V/8mX30/kn1ygG2uqdVbWLyCTzYeiiaD1ARN1+ck+dV+tb7CrZHb9llBM1uklbLLUSd555YP8ApY1WQiKneUXa4qnCKG5cz+Xo60NDuxj2kOHpaz0LMSt3k61L4toVXAD6ia3Sc4d4ewg/T6V5+UHUvm2liJx9TBQxMYO4lzvpcVVS1DydrZFS4FVV4a3pqysdznDjzWABo8xLj51byIqx292yKt2X1VW9rekoJ4ZmO6xzniMj0P8AmWTlZGwqqfT7V7bE0nSpinidp2CNz/pYFN+U171vyv6lUAtEcmj2OyL42D6Hq91lDb97qM/+Eh+gqr1rfYV7lFt+Nn/1HLi8o6pfHgdvgadGzXFvO7wI3nT06HzLMS9duutxs9Sam2V9VQzlpYZaaZ0Ti06EjVpB03Dd3Lq/w7zD8K75/wAxm/eT+HeYfhXfP+YzfvJ/DvMPwrvn/MZv3l5Ljk1/vFMKa53y5VsAcHiKpq5JGhw4HRxI13n0rlK0+T9WOptprYQ7QVVHLER26aP/APQvbyjKp0ufUNNqeZBbmEA/fOe8k+gD0Kn1pnk422KDDblctB09VW9GSOPMYxug9L3elXMiIipflI+020/KH1b1mhXLyb4mOze5yFoL2W4hp7NZGa/QtNIixNtEY2PaRkbWDQfZGY6d5eSVGVtjZy5z9m+NlxJP2OhG/sDAApOiIiIiKiOUv7HY78bP9DFndX/yZffT+SfXKCbcKJ1HtXury3RlQyGZneDG0H/qa5V2tW7Ar1Fcdm8VAHgz22eSJ7dd/Nc4vafD1RH4pVpIipTlH3mKDF7ZZmvHlFVVdOWg7xGxpG/xLh6Cs1q4eTlRvmzyvqtD0cFvcCfhOezQegO9C8/KGo30+0aKoIPMqaGN4PeHOaR8w9KqZaY5Od6iqcRuFnLh09HVdKG9scgGn/U13pCudEVVcoC8xUGzl1uLh01yqI42s6y1jhI4+ALWjzhZVVmbBqJ1VtUo5mt1FJTzTOPYCws+l4Uz5TXvW/K/qVQC0RyaPY7IvjYPoer3WUNv3uoz/wCEh+gqr1rfYV7lFt+Nn/1HLjco2lfLgVBUMBLYbiznjTgDG8a+nQedZhXUx7HrjlF5itNqjZJWStc5jHyBnO5o1O87uAJ8ymn2is+/suD87j/eT7RWff2XB+dx/vJ9orPv7Lg/O4/3k+0Vn39lwfncf7yfaKz7+y4PzuP95TPZXsry3F8/ortdqGKKjijla97ahjyC5hA3A68SuRyjqJ0WcW6s5ukc9vDNe1zXv1+ZzVTa0lyb7xFNjV1sznjp6aqFQG9ZY9oG7t0LD6QrtRERUvykfabaflD6t6zQro5N3tyu3yf9YxaXRFijaR7pWR/KE36RUXW19m/ua458nw/ohShEREREVEcpf2Ox342f6GLO6v8A5Mvvp/JPrl9+UdjD5qa25PAzUQDySpIHBpJLD4alw/GCzypds7zqrwLJG18TXTUco6OrpwdOkZ2j4Q4jzjrK1xjeVWXLbc2us1dHUR6DnsB0fEex7eIP/wAGq7KjmW5xYsLt5qbtWNbIRrFTMIdLKfgt7O87h2rIeZ5bXZrkk94rvUc71EMIOohjGujR28SSesklR9aj5P2MvtGGT3ioYWz3aQPYCN/Qs1DfSS4+BC8/KGxl9zxWkvtOwultkhbKAP8AZP0BPmcG+krMikOF5fX4TkkF3oQH80cyaFx0bNGeLT2cAQeogLXmJZvYszt7am01jHSc3WWmeQJYj2Ob+sbj2qRLi5LlllxK3OrbzWxwM0PMj11klPY1vEn/AOFZG2g5zWZ5kb7jO0w0sQ6Olp9dejZr19rjxJ/UAomtHcnPGH0lpuGSVDNDWEU9NqP9m06vPgXaD8Qrwcpr3rflf1KoBaI5NHsdkXxsH0PV7rKG373UZ/8ACQ/QVV61vsK9yi2/Gz/6jl39o2PPynAbta4W86ofF0kAHEyMIc0DxI086xSQQSCNCOIK9tnutXYrxSXShk5lVSytljPVqDwPaDwI7CtmYTnFpziyx1tBM1tQ1o8ppS71cDuwjrHYeB9IUmRVTtJ2z23FoZrZZJYq69EFpc086KmPa48HO+CPPpwPR2XbUaTOreKSrMdPfIGazQjcJQPu2d3aOrwViqptv+MPvWExXWnZzqi0yGRwA39C7QP9BDT4ArLKkGGZbXYVktPeKH1fM1ZNCXaNmjPFp+Yg9RAK17iWbWPNLc2qtNY17wAZaZ5AlhPY5v6+B6ipEuLkmV2TE7e6svNfFTs09QwnWSQ9jWjeSs913KAvkmaxXOjhEdli1j+x7z/OsJ3ucep/YRuHDfv10PjWS2zLLJDdrTOJaeTcQdzo3dbXDqI/9+BVXcpH2m2n5Q+res0K6OTd7crt8n/WMWl0RYo2ke6VkfyhN+kVF1tfZv7muOfJ8P6IUoRERERFRHKX9jsd+Nn+hizur/5Mvvp/JPrled3tVHfLRVWuviEtLVRmORvcesdhHEHqIWNc7we44LkElvq2ufTPJdS1QHqZmfqcOBHV4EExdfekrKqgqG1FHUzU07fWyQyFjh4Eb13nbQsyfD0Tspu5bpp/TH66eOuqj0881TM+aeV8srzq58ji5zj3k8V81Pdl+zirzu9tfMx8dlpng1U/DndfRtP3x+YHXsB19BBFTU8dPBG2OGJoYxjRoGtA0AA7NF+aulgrqOakqomy087HRyxu4OaRoQfMsfbS9ndbgd9c0NfLaKhxNHUka7uPMd2OHzjf2gQdfSnqJ6Sds9NNJDMw6tkjcWuae4hSEbQ8yEXRDKbvzdNP6Y/X066rgVVZU11Q6orKiaond66SZ5e4+JO9fFS3Z9gdfnl/ZRwB8VDEQ6rqtN0TOwdrjwA8/AFbIt1vpbTbaa30ULYaWmjbFExvU0DQKieU171vyv6lUAtEcmj2OyL42D6Hq91lDb97qM/+Eh+gqr1rfYV7lFt+Nn/1HKyFmDbds3msN4lyS2QF1qrXl84YP6NKTv17GuO8HqOo3btafXqt1zrrRWsrLdWT0lSz1ssEhY4ecdSn1Ht1zylgETrlBUaDQOmpmF3pAGvnXIv21PM8igfT117mbTPGjoadrYWkdh5oBI8SVDl6rZW1tuudNWW2aWGtikDoXxeuDurTt7NOtbYw6rvlditDUZHRspLo9n8tE0+gkfckjeW9XzDtTQx1EEkE0bZIpGlj2OGoc0jQgjsWQtqWziqwW+OkgY+Sy1TyaWfjzDx6Nx++HV2jf26QBfSnqJ6Sds9NNJDMw6tkjcWuae4hSEbQ8yEXRDKbvzdNP6Y/X066rgVVZU11Q6orKiaond66SZ5e4+JO9fFWhsMlyhubMZYhzre7m/ZIS69EIteJ+Hx5um/Xu1Vj8pH2m2n5Q+res0K6OTd7crt8n/WMWl0RYo2j+6VkfyhN+kVF1tfZx7muOfJ8P6IUoRERERFTXKAx285BQ2JlotlVXOhlmMgp4y/mAhmmungVRv2uM1/Be6/mzv2K6+T7jd6x/wDhF9mLXV0PT+TdF5REWc/m9Lrprx01HpV2LlZBjlqym0yW270jKinfvGu5zD1OaeIPeFnTMNgN+tEslRjz/stRbyIyQ2dg7CNwd4jeexVVX2yvtVQYLhRVNJMP9nUROjd6CF5V77XY7re5xDa7bVVshOnNgic/Tx0G5XBhfJ7uNZLHV5XMKKmB18jheHSv7nOHqWjw1PgtCWu1UFlt0NvttLFS0kI5scUY0A/ae0neV7EXhvFmt1/tk1tutJHVUkw0fHIPnB4gjqI3hZ4zPk+XWgkkq8WmFwpeIpZXBszB2AnRr/mPcVUdys1zs05gudvqqOUHTm1ETmHzajevCvXb7VcbtOILdQVNZL95TxOkPoAVs4dyf73dJY6nJJPsXRcTAxwdO8dm7UM8Tqe5aJsVgtmNWqK22ikjpqWPg1vFx63OPEk9pXSVJ8oLG71kH8HfsPa6uu6DynpfJ4i/mc7otNdOGuh9CpT7W+a/gvdfzZ37FeWwDHbzj9DfWXe2VVC6aWExiojLOeAH66a+IVyrNe2rDskvW0Sastljr6ymNNE0Swwuc3UA6jUKvPtb5r+C91/NnfsWmtjlrr7Ns1oKK5Uk1JVMlmLoZmFrgDISNx7lPV8qmmgrKWWmqYY5oJWlkkcjQ5r2niCDxCoLOOT3IZpK7D5mFjt5t9Q/QtPwHnq7nelUveMYvuPyuju1prKMg6c6WIhp8HcD5iuUv1HG+WRscbHPe46BrRqT5lN8c2RZlkj2mK1PoqZ3GorgYWgdwI5x8wK0BgOx6x4U6OumP2Ru4G6plZo2I/8Aht6vE7/DgrGReS52yhvNvmoLjSx1NJM3myRSDUEfqPfxCz3mnJ7uFJLJV4nMKymJJ8ineGys7muOgcPHQ+Kp+6WK7WSbobrbauik10AqIXM18NRv8y569VDba66VAgt9FUVcxOgjgic93oAVqYfsBv8AeJI6jIHfYmi1BMeodO8dw4N8Xbx2FaLx3G7TitpjttnpGU9O3edN7pHdbnHiT3/qVfbe7Fdb/ittp7Tb6mtmjree9kEZeWt5jhqdOrUhZ/8Atb5r+C91/NnfsVr7BMVv9gyq5VF2s9bRQyUXMY+eEsDnc9p0GvXoCtAIiyVnmB5ZX59fqukx25T081bK+OWOncWvaXHQg9ijv2t81/Be6/mzv2LWuB0lRQYDYaSrhfBUQ0UTJIpBo5jg0agjtUiRERERERERF85oIaiMxzxMljPFr2hwPmK8Ix2xiQyCzW8PI0LvJWakeOi6DGMjYGMa1rRwDRoAv0iKjdqm1rJsMzR9ptsVCaXyeOVpnhc5xJ113hw3ahQr+MNmv9Vavzd376u7ZRmNbm+HG53HoBVsqXwSCFpa0aBpG4k9TgpvJGyVhZIxr2Hi1w1BXPOO2MyiQ2a39IBoHeSs107NdF74oYoIxHDGyNg4NY0ADzBRLadlVVhuDVd2oRCaxskccImaXNJc8a6gEa+p53WqI/jDZr/VWr83d++pZs12w5Tl2eW+zV8dvFHMJXSmKEtcA2NzhoS4/dAK+0RERERF/CA5pa4Ag7iD1rnTY9ZKh3Oms9vkdrztX0zCde3eF6qaho6IEUtLBBrx6KMN19C9CIiIvy9jJGFj2tc08Q4agrnnHbGZBIbNby8DQO8lZqB46L3QwQ08YjgiZFGODWNDQPMF9EREREREREREREREREREREWduUlZHMudmvrGHmSxOpJHDgHNJc3XvIc7/KqJVtbCs7gxq/zWa5StioLmW8yV50bFMNw17A4HQntDe9alRFmfb7nUF6ukGNW6YSUtvkL6l7eDp9COaP7oJHi49iphXTycbK+pyq5XlzT0NHTdC0/DkI/9LXekLSyIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIo1nmJw5piFbZ5C1szx0lNIfuJW72nw6j3ErFtfQ1Vsr6ihrYXQ1NPIY5Y3je1wOhC86s/DduOR4tTR0NYxl2oI9Axk7y2Vg7Gyb93iD5lYQ5Sll8n5xsFeJvvBKzm/5uPzKB5ht3yHI6aSitsLLPRyAteYpC+Z47OfoNB4AHvVVL601NPWVUNLTRPlnmeI442DVz3E6AAdpK2Zs2w5uE4ZS2x/NNbIenq3t4GVwGoB6wAA3za9alyIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIirHansmps3iNztpjpr5G3Tnu3MqWgbmv7COp3mO7TTLl3stysFxkoLrRTUlVH66OVuh07QeBHeNxXhRF67Za6+818VDbaSaqqpToyKJvOJ/YO9ac2U7IIsPLLzejHPe3N9Qxp1ZSg8QD1u03E8BvA7TbCIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIuZfMds+SUfkl5t1PWw9Qlbvb3tdxae8EKrrvyc8aq3ufbLjX28k+sdpMweAOjvS4rh/xZf8A8u//AFv/APVdm1cnHHaWRr7nda+u0+4jDYWnx4n0EK0LDi9jxil8nstsp6NhGjjG31b/AO84+qd5yV10RERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERF//2Q=='
        pic     = PyEmbeddedImage(data=pic_str.encode()).GetImage() # .Rescale(500,200), 原图大小是(500,200)
        logi_logo_show = wx.StaticBitmap(parent=self.scroller, id=-1, bitmap=wx.Bitmap(img=pic), pos=(0,0), size=(gui_W-self.left_panel_W-20,self.screen_H-70), style=0) # 这里改变的是StaticBitmap这个控件在self.scroller上的位置和大小(图片在StaticBitmap控件上默认是居中显示)
        self.UTS_standard_format = wx.StaticText(logi_logo_show, label='', pos=(0,0), size=(gui_W-self.left_panel_W-20,95), style=wx.ALIGN_LEFT)
        self.Extracting = wx.StaticText(logi_logo_show, label='', pos=(0,100), size=(gui_W-self.left_panel_W-20,-1), style=wx.ALIGN_LEFT)
        self.Extracting.SetFont(font=wx.Font(pointSize=14, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        self.Extracting.SetForegroundColour('red')
        #self.Extracting.SetBackgroundColour('yellow')
        
        # 准备[项目概览] Overview 的面板
        # 注意理解1: gui_W-self.left_panel_W-20 是self.scroller的长度, 也恰恰是 self.Project_Specs_pnl 的起点.
        # 注意理解2: self.screen_W-gui_W+15, 其中的+15是实际实验中发现最右侧有15px的浅蓝色背景, 所以用偏差15px覆盖最右侧为白色.
        self.Project_Specs_pnl = wx.Panel(self.rpanel, -1, (gui_W-self.left_panel_W-20,0), (self.screen_W-gui_W+15, self.screen_H-70),style=wx.BORDER_STATIC)
        self.Project_Specs_pnl.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI', encoding=wx.FONTENCODING_DEFAULT))
        self.Project_Specs_pnl.SetBackgroundColour('white') # 'purple'
        self.Project_Specs_pnl.SetForegroundColour('grey')
                       
    def btn_open_FCT(self, event):
        """执行此函数后，将生成文件夹：LOG_pure"""
        
        self.UTS2_format = None
        self.SetTitle(f'{app_name}({latest_ver})     Algorithm: {login_GUI.algorithm_Hist_custom}    Index: {login_GUI.Index_var_custom}')
        default_dir = os.path.abspath('')   # 返回当前文件所在目录的绝对路径
        dlg = wx.FileDialog(parent=self, message='Please select your csv file(s)', defaultDir='', defaultFile='', wildcard='*.csv', style=wx.FD_OPEN|wx.FD_FILE_MUST_EXIST|wx.FD_MULTIPLE)
        res = dlg.ShowModal()
        if res == wx.ID_OK:               
            # ==================================== 清除上次缓存, 更新最新选择
            self.original_csv = sorted(dlg.GetPaths())  # -> list
            print(self.original_csv)
            self.widget_LOG.SetValue('\n'.join(self.original_csv))              # 精彩, list --> str
            self.widget_LOG.SetToolTip(tipString='\n\n'.join(self.original_csv))# 精彩, list --> str
            
            self.checkBox_all.SetValue(state=False)
            self.checkBox_special.SetValue(state=False)
            for i in range(self.var_options.GetCount()):
                self.var_options.Delete(n=0)
            
            self.checkBox_all.Disable()
            self.checkBox_special.Disable()
            self.btn_analytics.Disable()
            self.btn_dashboard.Disable()
            self.btn_analytics.Refresh()
            self.btn_dashboard.Refresh()
            
            self.hbox_right.Clear(delete_windows=True)  # 这里,已经Destroy self.scroller 和 self.Project_Specs_pnl       
            #if self.scroller:
            #    self.scroller.Destroy()
            #if self.Project_Specs_pnl:
            #    self.Project_Specs_pnl.Destroy()
            
            # ------------ 调用右面板
            self.right_panel()
            # ================================= 这里是右面板水平布局管理器的更新
            self.hbox_right.Add(self.scroller,          0, wx.ALL|wx.EXPAND, 0)
            self.hbox_right.Add(self.Project_Specs_pnl, 1, wx.ALL|wx.EXPAND, 0)
            self.hbox_right.Layout()
            self.rpanel.Refresh()
            
            if os.path.isdir(self.temp_folder):shutil.rmtree(self.temp_folder)
            if not os.path.isdir(self.pure_LOG_folder):os.makedirs(self.pure_LOG_folder)
            
            self.Date_range_report    = []
            self.Data_source_report   = []
            self.Business_unit_report = []
            self.Project_report       = []
            self.Stage_report         = []
            self.Station_report       = []
            self.File_report          = []
            self.Total_report         = 0
            self.Fail_report          = 0
            self.Yield_rate_report    = 0
                       
            # ==================================== 调用内嵌的 get_vars_with_latest_LSL_USL(...) 函数
            # 特别注意: self.vars_with_L_U, self.vars_with_L_U_original 这两个全局变量的原始数据只在用户执行[Step-1]时点击[Select]生成一次.
            self.Extracting.SetLabel(label='Extracting Variables ...')
            flag_LOG, self.vars_with_L_U = self.get_vars_with_latest_LSL_USL(LOG_folder=self.pure_LOG_folder, LOG_csv=self.original_csv, specfied_var=login_GUI.Index_var_custom)
            self.vars_with_L_U_original  = copy.deepcopy(self.vars_with_L_U) # 利用模块copy, 进行字典的深拷贝
            
            # ==================================== 调用内嵌的 Dashboard_data_preparation(...) 函数
            if flag_LOG:
                self.Extracting.SetLabel('Preparing Dashboard ...')
                if self.Dashboard_data_preparation():
                    for n, one_var in enumerate(list(self.vars_with_L_U.keys())):
                        self.var_options.Insert(item=one_var, pos=n)
                    self.checkBox_all.Enable()
                    self.checkBox_special.Enable()
                    self.btn_analytics.Enable()
                    
                    # ==================================== 更新[项目概览] Overview 的面板
                    self.Project_Specs_pnl.SetBackgroundColour(self.rpanel_bgc) #'tan'
                    the_size = -1

                    # 搜索控件
                    self.searchCtrl = wx.SearchCtrl(self.Project_Specs_pnl, pos=(5,5), size=(self.screen_W-gui_W,25))
                    self.searchCtrl.SetToolTip(tipString=f'Please input {login_GUI.Index_var_custom} to search its all test histories...')
                    self.searchCtrl.ShowCancelButton(show=True)                       # 默认是False, 无取消(X)按钮.
                    self.searchCtrl.Bind(wx.EVT_SEARCH, self.search_FCT)              # 用户点击了[搜索]按钮或敲了[回车],都会触发该事件函数
                    self.searchCtrl.Bind(wx.EVT_SEARCH_CANCEL, self.search_cancel_FCT)# 用户点击了[X]按钮,就会触发该事件函数
                    
                    # Project Specs
                    Project_Specs = wx.StaticText(self.Project_Specs_pnl, label='Project Specs', pos=(5,40), size=(the_size,25))
                    Project_Specs.SetForegroundColour('blue')
                    Static_Box = wx.StaticBox(self.Project_Specs_pnl, label='', pos=(5,70), size=(100,2), style=0)
                    Static_Box.SetBackgroundColour('grey')
                    
                    # Date range
                    Date_range = wx.StaticText(self.Project_Specs_pnl, label='Date range', pos=(5,80), size=(the_size,25))
                    the_label  = ', '.join(sorted(list(set(self.Date_range_report))))
                    Date_range = wx.StaticText(self.Project_Specs_pnl, label=the_label, pos=(5,110), size=(the_size,25))
                    Date_range.SetToolTip(tipString=the_label)
                    Date_range.SetForegroundColour('black')
                    
                    # Data source
                    Data_source = wx.StaticText(self.Project_Specs_pnl, label='Data source', pos=(5,155), size=(the_size,25))
                    the_label   = ', '.join(list(set(self.Data_source_report)))
                    Data_source = wx.StaticText(self.Project_Specs_pnl, label=the_label, pos=(5,185), size=(the_size,25))
                    Data_source.SetToolTip(tipString=the_label)
                    Data_source.SetForegroundColour('black' if self.UTS2_format else 'red')
                    
                    # Business unit
                    Business_unit = wx.StaticText(self.Project_Specs_pnl, label='Business unit', pos=(5,230), size=(the_size,25))
                    the_label     = ', '.join(list(set(self.Business_unit_report)))
                    Business_unit = wx.StaticText(self.Project_Specs_pnl, label=the_label.replace('&','&&'), pos=(5,260), size=(the_size,25))
                    Business_unit.SetToolTip(tipString=the_label)
                    Business_unit.SetForegroundColour('black' if self.UTS2_format else 'red')
                    
                    # Project
                    Project   = wx.StaticText(self.Project_Specs_pnl, label='Project', pos=(5,305), size=(the_size,25))
                    the_label = ', '.join(list(set(self.Project_report)))
                    Project   = wx.StaticText(self.Project_Specs_pnl, label=the_label, pos=(5,335), size=(the_size,25))
                    Project.SetToolTip(tipString=the_label)
                    Project.SetForegroundColour('black' if self.UTS2_format else 'red')
                    
                    # Stage
                    Stage     = wx.StaticText(self.Project_Specs_pnl, label='Stage', pos=(5,380), size=(the_size,25))
                    the_label = ', '.join(list(set(self.Stage_report)))
                    Stage     = wx.StaticText(self.Project_Specs_pnl, label=the_label, pos=(5,410), size=(the_size,25))
                    Stage.SetToolTip(tipString=the_label)
                    Stage.SetForegroundColour('black' if self.UTS2_format else 'red')
                    
                    # Station
                    Station   = wx.StaticText(self.Project_Specs_pnl, label='Station', pos=(5,455), size=(the_size,25))
                    the_label = ', '.join(list(set(self.Station_report)))
                    Station   = wx.StaticText(self.Project_Specs_pnl, label=the_label, pos=(5,485), size=(the_size,25))
                    Station.SetToolTip(tipString=the_label)
                    Station.SetForegroundColour('black' if self.UTS2_format else 'red')
                    
                    # File
                    File = wx.StaticText(self.Project_Specs_pnl, label='File', pos=(5,530), size=(the_size,25))
                    for each_file_name in [os.path.split(per_file)[1] for per_file in self.original_csv]:
                        self.File_report.append(each_file_name)
                    the_label = '\n'.join(self.File_report)
                    File      = wx.StaticText(self.Project_Specs_pnl, label=the_label.replace('&','&&'), pos=(5,560), size=(the_size,-1))
                    File.SetToolTip(tipString=the_label)
                    File.SetForegroundColour('black')
                    self.Project_Specs_pnl.Refresh()
                    
                    self.Extracting.SetLabel('Now, variables are already extracted and dashboard is also available.\n\nTo analyze variable, please go on to execute Step2 -> Step3 -> Step4.\nTo analyze DUT,        please go on to execute Step5.')
                    self.Extracting.SetForegroundColour('blue')
                else:
                    self.Extracting.SetLabel('')
                    self.widget_LOG.Clear()
                    self.widget_LOG.SetToolTip(tipString='')
                    self.widget_LOG.SetFocus()
            else:
                self.Extracting.SetLabel('')
                self.widget_LOG.Clear()
                self.widget_LOG.SetToolTip(tipString='')
                self.widget_LOG.SetFocus()
            self.Extracting.Refresh()
        elif res == wx.ID_CANCEL:
            print('用户点击了取消按钮,放弃了选择文件.')
        dlg.Destroy()
    
    def Dashboard_data_preparation(self):
        # 特别提醒: 这里不是按钮 btn_dashboard(注意:按钮btn_dashboard已绑定btn_dashboard_FCT)绑定的函数
        """执行此函数后，将生成文件夹: 02_Dashboard_data, 文件: YieldRate_Top5Reason_Top5ErrorCode_Top5ErrorLine.csv"""
        
        if not os.path.isdir(self.Dashboard_data_folder):
            os.makedirs(self.Dashboard_data_folder)
        
        # ==================================== 重读 01_LOG_pure 文件夹
        self.dashboard_data = []
        all_pure_subCSV = os.listdir(self.pure_LOG_folder)
        all_pure_subCSV.sort()
        dlg_pure = wx.ProgressDialog(title='Reading Pure CSV File(s)', message=f'Reading pure *.csv: 0/{len(all_pure_subCSV)}', maximum=len(all_pure_subCSV), parent=None, style=wx.PD_AUTO_HIDE)
        for m, each_pure_subCSV in enumerate(all_pure_subCSV, 1):
            dlg_pure.Update(value=m-1, newmsg=f'Reading pure *.csv: {m}/{len(all_pure_subCSV)}\n\n{each_pure_subCSV}')
            if len(all_pure_subCSV) == 1:
                dlg_pure.Pulse() #进度条不确定模式
            the_file = os.path.join(self.pure_LOG_folder, each_pure_subCSV)
            with open(file=the_file, mode='r', encoding='utf-8') as preread_obj:
                reader = csv.reader(preread_obj)
                read_1 = list(reader)
            # 注意: 这里必须确保当前这个干净的子csv里有 "UID" (即 login_GUI.Index_var_custom)列, 向下继续执行才是有意义的.
            if login_GUI.Index_var_custom in read_1[0]:
                with open(file=the_file, mode='r', encoding='utf-8') as read_obj:
                    rows = csv.DictReader(read_obj)
                    for each_row in rows:
                        UID_row = each_row[login_GUI.Index_var_custom]
                        
                        if not login_GUI.empty_UID_included:
                            if not UID_row:
                                continue
                        
                        DUT_Status          = each_row['Status']
                        DUT_Comment         = each_row['Comment'].split('->')[0]  # 这里兼容UTS1, 其是Comment->xxx格式
                        DUT_ErrorLine       = each_row['ErrorLine'] if self.UTS2_format else ''                       # 这里兼容UTS1, 其不存在'ErrorLine'这样的列
                        DUT_ErrorCode       = each_row['ErrorCode'] if self.UTS2_format else each_row['Failed_Tests'] # 这里兼容UTS1, 其是'Failed_Tests'
                        DUT_FailValue       = each_row['FailValue'] if self.UTS2_format else ''                       # 这里兼容UTS1, 其不存在'FailValue'这样的列
                        DUT_Test_Start_Time = each_row['Test_Start_Time']
                        DUT_UnixTime        = each_row['UnixTime'] if self.UTS2_format else ''                        # 这里兼容UTS1, 其不存在'UnixTime'这样的列
                        if DUT_Status in ['P','F']:     # 只关注在当前这个干净子csv文件的Status列的值为['P','F']的列
                            if self.UTS2_format:                                                                      # 这里兼容UTS1, 其不存在'UnixTime'这样的列
                                time_stamp  = int(DUT_UnixTime.strip())                  # Step-1: Unix时间戳
                                dt_object   = datetime.datetime.fromtimestamp(time_stamp)# Step-2: Unix时间戳转换成datetime对象
                                BeijingTime = dt_object.strftime('%Y-%m-%d %H:%M:%S')    # Step-3: datetime对象转换成时间字符串
                            else:
                                BeijingTime = ''
                            original_csv_file = '_'.join(os.path.splitext(each_pure_subCSV)[0].split('_')[:-2]) + os.path.splitext(each_pure_subCSV)[1]
                            self.dashboard_data.append([UID_row, DUT_Status, DUT_Comment, DUT_ErrorLine, DUT_ErrorCode, DUT_FailValue, DUT_Test_Start_Time, DUT_UnixTime, BeijingTime, original_csv_file])
        # print(self.dashboard_data)    # -> list
        # print('[Above]: self.dashboard_data '.center(100,'*'), end='\n\n')
        dlg_pure.Destroy()
        
        if self.dashboard_data:
            # key 使用lambda匿名函数取Unix时间戳进行从小到大排序
            self.dashboard_data.sort(key=lambda x:x[7], reverse=False) # 列表排序
            headers = [login_GUI.Index_var_custom, 'Status', 'Comment', 'ErrorLine', 'ErrorCode', 'FailValue', 'Test_Start_Time', 'UnixTime', 'BeijingTime', 'OriginalCSV']
            with open(file=self.dashboard_csv, mode='w', encoding='utf-8', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(headers)                # 注意: 这里是 writerow
                writer.writerows(self.dashboard_data)   # 注意: 这里是 writerows
            self.btn_dashboard.Enable()
            return True
        else:
            ori_csv = '\n'.join(self.original_csv)
            if not login_GUI.empty_UID_included:
                wx.MessageBox(message=f'Find no row meeting "{login_GUI.Index_var_custom}: non-empty & Status: P | F"\n\n{ori_csv}', caption='myWarning', style=wx.ICON_WARNING, parent=self)
            else:
                wx.MessageBox(message=f'Find no row meeting "Status: P | F"\n\n{ori_csv}', caption='myWarning', style=wx.ICON_WARNING, parent=self)
            return False
            
    def search_FCT(self, evt):
        # 清除上次的可能的缓存
        if self.miniFrame_search:
            self.miniFrame_search.Destroy()
        
        search_UID   = evt.GetString()
        serch_result = []
        for x in self.dashboard_data:
            if x[0] == search_UID:
                serch_result.append(x)
        if serch_result:
            # print(serch_result)
            visible_row_max = 30
            the_Height = int(30+21*len(serch_result))+20 if len(serch_result) <= visible_row_max else 30+21*visible_row_max+20
            self.miniFrame_search = wx.MiniFrame(parent=self.scroller, title=f'All test histories of DUT UID: {search_UID}', size=(1300+20+15, the_Height+25+10), style=wx.CAPTION|wx.CLOSE_BOX|wx.RESIZE_BORDER)  #|wx.STAY_ON_TOP
            self.miniFrame_search.SetBackgroundColour((240,240,240))
            
            # 绘制[搜索数据细节]的表格
            Search_Detail_table = wx.ListCtrl(self.miniFrame_search, -1, (0,0),(1300+20, the_Height), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            Search_Detail_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack=wx.Colour('red'), font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            Search_Detail_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            Search_Detail_table.SetBackgroundColour((240,240,240))
            Search_fieldnames = [login_GUI.Index_var_custom, 'Status', 'Comment', 'ErrorLine', 'ErrorCode', 'FailValue', 'Test_Start_Time', 'UnixTime', 'BeijingTime', 'OriginalCSV']
            Search_fieldnames.insert(0, 'No.')
            Search_data = []
            # 严重注意: 这里必须使用列表的深拷贝, 
            # 否则只使用 serch_result 就会导致 self.dashboard_data 的每一个子列表前也被加了一个"序号"元素, 第二次搜索就无法搜索到了.
            for i, each_row in enumerate(copy.deepcopy(serch_result),1): 
                each_row.insert(0,str(i))
                Search_data.append(each_row)
                
            # 首先插入表格眉头
            for n, fieldname in enumerate(Search_fieldnames, 0):
                Search_Detail_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=80) # Step-1: 必须先插入列
            Search_Detail_table.SetColumnWidth(col=0,  width=50)  # 修改指定的一列的宽度
            Search_Detail_table.SetColumnWidth(col=1,  width=160) # 修改指定的一列的宽度
            Search_Detail_table.SetColumnWidth(col=2,  width=55)  # 修改指定的一列的宽度
            Search_Detail_table.SetColumnWidth(col=3,  width=180)
            Search_Detail_table.SetColumnWidth(col=7,  width=115)
            Search_Detail_table.SetColumnWidth(col=8,  width=100)
            Search_Detail_table.SetColumnWidth(col=9,  width=150)
            Search_Detail_table.SetColumnWidth(col=10, width=450)
            
            # 然后插入下面的每一行
            for n, row_data_list in enumerate(Search_data, 0):
                index_row = Search_Detail_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                if row_data_list[2] == 'F':
                    Search_Detail_table.SetItemTextColour(item=n, col='red')
                for m in range(1, len(Search_fieldnames), 1):
                    Search_Detail_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
            
            self.miniFrame_search.Centre()
            self.miniFrame_search.Show()
            self.miniFrame_search.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
        
        else:
            wx.MessageBox(message=f'Find no result for "{search_UID}"', caption='myWarning', style=wx.ICON_WARNING, parent=self)
            
    def LIST_ITEM_ACTIVATED_Search_FCT(self, evt):
        # 清除上次的可能的缓存
        if self.miniFrame_search:
            self.miniFrame_search.Destroy()
        
        the_obt      = evt.GetEventObject()
        index_focus  = the_obt.GetFocusedItem()
        search_UID   = the_obt.GetItemText(item=index_focus, col=1).split('_')[-1]
        serch_result = []
        for x in self.dashboard_data:
            if x[0] == search_UID:
                serch_result.append(x)
        if serch_result:
            # print(serch_result)
            visible_row_max = 30
            the_Height = int(30+21*len(serch_result))+20 if len(serch_result) <= visible_row_max else 30+21*visible_row_max+20
            self.miniFrame_search = wx.MiniFrame(parent=self.scroller, title=f'All test histories of DUT UID: {search_UID}', size=(1300+20+15, the_Height+25+10), style=wx.CAPTION|wx.CLOSE_BOX|wx.RESIZE_BORDER)  #|wx.STAY_ON_TOP
            self.miniFrame_search.SetBackgroundColour((240,240,240))
            
            # 绘制[搜索数据细节]的表格
            Search_Detail_table = wx.ListCtrl(self.miniFrame_search, -1, (0,0),(1300+20, the_Height), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            Search_Detail_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack=wx.Colour('red'), font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            Search_Detail_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            Search_Detail_table.SetBackgroundColour('white')
            Search_fieldnames = [login_GUI.Index_var_custom, 'Status', 'Comment', 'ErrorLine', 'ErrorCode', 'FailValue', 'Test_Start_Time', 'UnixTime', 'BeijingTime', 'OriginalCSV']
            Search_fieldnames.insert(0, 'No.')
            Search_data = []
            # 严重注意: 这里必须使用列表的深拷贝, 
            # 否则只使用 serch_result 就会导致 self.dashboard_data 的每一个子列表前也被加了一个"序号"元素, 第二次搜索就无法搜索到了.
            for i, each_row in enumerate(copy.deepcopy(serch_result),1): 
                each_row.insert(0,str(i))
                Search_data.append(each_row)
                
            # 首先插入表格眉头
            for n, fieldname in enumerate(Search_fieldnames, 0):
                Search_Detail_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=80) # Step-1: 必须先插入列
            Search_Detail_table.SetColumnWidth(col=0,  width=50)  # 修改指定的一列的宽度
            Search_Detail_table.SetColumnWidth(col=1,  width=160) # 修改指定的一列的宽度
            Search_Detail_table.SetColumnWidth(col=2,  width=55)  # 修改指定的一列的宽度
            Search_Detail_table.SetColumnWidth(col=3,  width=180)
            Search_Detail_table.SetColumnWidth(col=7,  width=115)
            Search_Detail_table.SetColumnWidth(col=8,  width=100)
            Search_Detail_table.SetColumnWidth(col=9,  width=150)
            Search_Detail_table.SetColumnWidth(col=10, width=450)
            
            # 然后插入下面的每一行
            for n, row_data_list in enumerate(Search_data, 0):
                index_row = Search_Detail_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                if row_data_list[2] == 'F':
                    Search_Detail_table.SetItemTextColour(item=n, col='red')
                for m in range(1, len(Search_fieldnames), 1):
                    Search_Detail_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
            
            #self.miniFrame_search.Centre()
            self.miniFrame_search.Show()
            self.miniFrame_search.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
        else:
            wx.MessageBox(message=f'Find no result for "{search_UID}"', caption='myWarning', style=wx.ICON_WARNING, parent=self)
         
    def search_cancel_FCT(self, evt):
        self.searchCtrl.Clear()
        if self.miniFrame_search:
            self.miniFrame_search.Destroy()
        
    def btn_analytics_report_FCT(self, evt):
        """执行此函数后，将生成文件夹：首先 03_LOG_filter(由内嵌的4种函数生成), 然后 04_Chart_data"""
        
        self.SetTitle(f'{app_name}({latest_ver})    Algorithm: {login_GUI.algorithm_Hist_custom}    Index: {login_GUI.Index_var_custom}    Current_CSV_Format: {"UTS2" if self.UTS2_format else "UTS1"}')
        
        # ==================================== 获取用户在Step-3: Variables的最新选择
        self.final_var_options = self.var_options.GetCheckedStrings()
        print('final_var_options:', self.final_var_options, sep='\n', end='\n\n')
        if not self.final_var_options:
            wx.MessageBox(message='Find no variable selected\n\nPlease select at least one variable', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return
        self.H_grid = 25 + 21*len(self.final_var_options) + 20  # 20Px是预留给水平滚动条
        
        if not os.path.isdir(self.pure_LOG_folder): # 注意: self.pure_LOG_folder 只会在点击 [Select] 那次生成一次而已
            wx.MessageBox(message=f'Find no {self.pure_LOG_folder}', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return
        
        # ==================================== 利用模块copy, 进行字典的深拷贝, 每次先恢复原貌 
        self.vars_with_L_U = copy.deepcopy(self.vars_with_L_U_original)   
        vars_with_L_U_analytics = {}
        for per_var in self.final_var_options:
            vars_with_L_U_analytics[per_var] = self.vars_with_L_U[per_var]
        
        # ==================================== Debug Mode
        if login_GUI.debug_mode_custom:
            if self.miniDialog_debug:
                self.miniDialog_debug.Destroy()
            # 特别注意: self.H_grid 虽然本身已包括预留给水平滚动条20Px, 
            # 但在grid控件与 wx.Dialog 控件之间的实际磨合时, 发现 wx.Dialog 控件在尺寸设置上需要比grid控件额外高35Px, 宽40Px.
            this_Height = self.H_grid+35 if self.H_grid+35 < self.screen_H-50 else self.screen_H-50
            
            # ------------ (1)创建对话框, 表格
            self.miniDialog_debug = wx.Dialog(None, title='Debug for original LSL/USL', size=(250+20+40,this_Height), style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER)#只写wx.DEFAULT_DIALOG_STYLE,效果是右上角仅有一个"X".
            popup_dubug_table     = grid.Grid(self.miniDialog_debug, -1, (0,0), (250+20,self.H_grid), style=wx.WANTS_CHARS)
            table_fieldnames = ['Item', 'LSL / USL']
            table_data_debug = []
            for xx, each_option in enumerate(self.final_var_options, 1):
                one_row_data_debug = ['{:03d}'.format(xx), each_option, f'{self.vars_with_L_U_original[each_option][0]} / {self.vars_with_L_U_original[each_option][1]}']
                table_data_debug.append(one_row_data_debug)
                
            popup_dubug_table.CreateGrid(numRows=len(table_data_debug), numCols=len(table_fieldnames))
            #popup_dubug_table.EnableEditing(edit=False)#默认是可编辑的.
            
            # ------------ (2)设置标签Label
            popup_dubug_table.SetGridLineColour((171,171,171))                                     # 设置所有单元格线的颜色,默认值是(192,192,192,255)
            popup_dubug_table.SetColLabelSize(height=25)                                           # 设置列标签的高度, 而列标签的宽度随单元格的宽度
            popup_dubug_table.SetRowLabelSize(width=40)                                            # 设置行标签的宽度，而行标签的高度随单元格的高度
            popup_dubug_table.SetCornerLabelValue('No.')
            
            for n, per_fieldname in enumerate(table_fieldnames, 0):
                popup_dubug_table.SetColLabelValue(col=n, value=per_fieldname)
            
            for per_n in range(0, len(table_data_debug), 1):
                popup_dubug_table.SetRowLabelValue(row=per_n, value='{:03d}'.format(per_n+1))   
                
            popup_dubug_table.SetLabelBackgroundColour(colour=(248,249,250))                        # 设置标签的背景颜色
            popup_dubug_table.SetLabelTextColour(colour='blue')                                     # 设置标签的字体颜色
            popup_dubug_table.SetGridCursor(row=0, col=1)                                           # 设置网格光标在指定的单元格
            popup_dubug_table.SetCornerLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)    # 设置Corner标签左右以及上下对齐方式：左对齐，下沉
            popup_dubug_table.SetColLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)       # 设置column标签左右以及上下对齐方式：左对齐，下沉
            popup_dubug_table.SetRowLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)       # 设置row标签左右以及上下对齐方式：   右对齐，下沉
            popup_dubug_table.SetLabelFont(font=wx.Font(pointSize=10, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_BOLD, underline=False, faceName='Microsoft JhengHei UI'))
            
            # ------------ (3)设置单元格cell
            for per_n in range(0, len(table_fieldnames), 1):
                popup_dubug_table.SetColSize(col=per_n, width=70)  
            popup_dubug_table.SetColSize(col=0, width=160)
            popup_dubug_table.SetColSize(col=1, width=90)
            
            for per_n in range(0, len(table_data_debug), 1):
                popup_dubug_table.SetRowSize(row=per_n, height=21)
            
            for m, each_var_data in enumerate(table_data_debug, 0):
                for n in range(len(table_fieldnames)):
                    popup_dubug_table.SetCellValue(row=m, col=n, s=each_var_data[n+1])
                    popup_dubug_table.SetCellBackgroundColour(row=m, col=n, colour=(227,242,253))
                    popup_dubug_table.SetCellFont(row=m, col=n, font=wx.Font(10, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
                    if n == 0:
                        popup_dubug_table.SetReadOnly(row=m, col=0, isReadOnly=True) 
            self.miniDialog_debug.Centre()
            self.miniDialog_debug.ShowModal()
            
            # ------------ (4)读取用户的自定义 LSL/USL
            # ------------ 注意, 由于这里的for语句中不带有break,for循环语句是正常执行结束,所以下方的else一定会执行.
            for n in range(popup_dubug_table.GetNumberRows()):
                the_cell_var    = popup_dubug_table.GetCellValue(row=n,col=0) 
                the_cell_limits = popup_dubug_table.GetCellValue(row=n,col=1)
                try:
                    LSL_custom = the_cell_limits.split('/')[0].strip()
                    USL_custom = the_cell_limits.split('/')[1].strip()
                    if float(USL_custom) > float(LSL_custom):
                        pass
                    else:
                        wx.MessageBox(message=f'Your debugging LSL/USL is invalid due to below Error:\n\n{the_cell_var}: {the_cell_limits}\nLSL({LSL_custom}) ≥ USL({USL_custom})', caption='myWarning', style=wx.ICON_WARNING, parent=self)
                except:
                    try_crash_error = traceback.format_exc()
                    wx.MessageBox(message=f'Your debugging LSL/USL is invalid due to below Error:\n\n{the_cell_var}: {the_cell_limits}\n\n{try_crash_error}', caption='myWarning', style=wx.ICON_WARNING, parent=self)
                else:
                    vars_with_L_U_analytics[the_cell_var] = (LSL_custom, USL_custom)    # 暂时保存在 vars_with_L_U_analytics
            else:
                print(vars_with_L_U_analytics)
                print(' [Above]: vars_with_L_U_analytics '.center(100,'*'), end='\n\n')
                for each_var, each_L_U in vars_with_L_U_analytics.items():
                    self.vars_with_L_U[each_var] = each_L_U                             # 精彩, 最终更新覆盖全局变量 self.vars_with_L_U
        
        # ==================================== 获取用户在Step-2: Filters的最新设置
        self.Flag_1        = self.check_box_1.GetValue()    # 特别注意: 在这里去抓取Step-2的Filter, 非常合适.
        self.Flag_2        = self.check_box_2.GetValue()    # 特别注意: 在这里去抓取Step-2的Filter, 非常合适.
        self.Interval_user = self.slider.GetValue()         # 特别注意: 在这里去抓取Step-2的Filter, 非常合适.
        
        # ==================================== 初始化上次的缓存数据
        if self.scroller:   # 判断滚动面板存在是为了防止上一次程序因中途崩溃没有生成滚动面板
            self.hbox_right.Detach(window=self.scroller)
        if self.scroller:
            self.scroller.Destroy()
        try:    
            if os.path.isdir(self.filter_LOG_folder):shutil.rmtree(self.filter_LOG_folder)
            if os.path.isdir(self.Charts_data_folder):shutil.rmtree(self.Charts_data_folder)
        #except PermissionError as e:
        except Exception as e:
            wx.MessageBox(message=f'Please find below Error:\n\n{e}', caption='myWarning', style=wx.ICON_WARNING, parent=self)
            return
            
        if not os.path.isdir(self.filter_LOG_folder):os.makedirs(self.filter_LOG_folder)
        if not os.path.isdir(self.Charts_data_folder):os.makedirs(self.Charts_data_folder)
        for i in os.listdir(path=self.temp_folder):
            the_file = os.path.join(self.temp_folder,i)
            if os.path.isfile(the_file):
                os.remove(path=the_file)
                
        self.all_bin_typical_count_percentage = {}
        self.all_histogram = [] # [{'1.变量1'：histogram1}, {'2.变量2'：histogram2, ...},]
        self.active_algorithm_image = login_GUI.algorithm_Hist_custom   # 这个变量, 用得好!
        
        # ==================================== 调用内嵌的4种函数, 重读 01_LOG_pure 文件夹
        if self.Flag_1 and not self.Flag_2:
            flag_needed_data, self.needed_data = self.get_data_UniqueUID_ExcludeDefect(LOG_folder=self.pure_LOG_folder, known_vars_with_limits=vars_with_L_U_analytics, specfied_var=login_GUI.Index_var_custom)
        elif self.Flag_1 and self.Flag_2:
            flag_needed_data, self.needed_data = self.get_data_UniqueUID_IncludeDefect(LOG_folder=self.pure_LOG_folder, known_vars_with_limits=vars_with_L_U_analytics, specfied_var=login_GUI.Index_var_custom)
        elif not self.Flag_1 and not self.Flag_2:
            flag_needed_data, self.needed_data = self.get_data_NonUniqueUID_ExcludeDefect(LOG_folder=self.pure_LOG_folder, known_vars_with_limits=vars_with_L_U_analytics, specfied_var=login_GUI.Index_var_custom)
        elif not self.Flag_1 and self.Flag_2:
            flag_needed_data, self.needed_data = self.get_data_NonUniqueUID_IncludeDefect(LOG_folder=self.pure_LOG_folder, known_vars_with_limits=vars_with_L_U_analytics, specfied_var=login_GUI.Index_var_custom)
        
        if flag_needed_data:
            # ------------ 正式创建 scroller
            self.screen_W, self.screen_H = wx.DisplaySize()    # 确认最新屏幕的分辨率
            self.scroller = wx.ScrolledWindow(self.rpanel, -1, (0,0), (gui_W-self.left_panel_W-20, self.screen_H-70))
            self.scroller.SetScrollbars(pixelsPerUnitX=1, pixelsPerUnitY=1, noUnitsX=gui_W-self.left_panel_W-20-17, noUnitsY=self.H_grid+5+500*len(self.final_var_options)+60)
            self.scroller.SetScrollRate(xstep=0, ystep=30)
            self.scroller.SetBackgroundColour(self.scroller_bgc)
            
            # ------------ 生成以用户选择的变量为文件名的 04_Chart_data\variable.csv 档案
            dlg_var_csv = wx.ProgressDialog(title='Generating Variable.csv', message=f'Generating variable.csv: 0/{len(self.final_var_options)}', maximum=len(self.final_var_options), parent=None, style=wx.PD_AUTO_HIDE)
            for n, per_option in enumerate(self.final_var_options, 1):
                tmp_csv_name = f'{"{:03d}".format(n)}.{per_option}.csv'
                dlg_var_csv.Update(value=n, newmsg=f'Generating variable.csv: {n}/{len(self.final_var_options)}\n\n{tmp_csv_name}')
                chart_csv = os.path.join(self.Charts_data_folder, f'{tmp_csv_name}')
                with open(file=chart_csv, mode='w', encoding='utf-8', newline='') as write_obj:
                    UID_cell = login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID'
                    fieldnames_csv = [UID_cell, 'Status', per_option, per_option+'_Status', 'LSL', 'USL']
                    writer_csv = csv.DictWriter(write_obj, fieldnames=fieldnames_csv)
                    writer_csv.writeheader()
                    for the_key, the_dict in self.needed_data.items():
                        if the_dict[per_option]:            # 这一步只挑选出非空数字值进行保存, 服务于画图。
                            writer_csv.writerow({UID_cell:the_key,
                                                'Status':the_dict['Status'],
                                                per_option:the_dict[per_option],
                                                per_option+'_Status':the_dict[per_option+'_Status'],
                                                'LSL':self.vars_with_L_U[per_option][0],
                                                'USL':self.vars_with_L_U[per_option][1],
                                                })
            dlg_var_csv.Destroy()
            
            # ==================================== 再重新读取刚刚保存的 04_Chart_data\variable.csv 档案
            self.table_data = []
            dlg_var = wx.ProgressDialog(title='Analyzing Variable', message=f'Analyzing variable: 0/{len(self.final_var_options)}', maximum=len(self.final_var_options), parent=None, style=wx.PD_AUTO_HIDE)
            for xx, each_option in enumerate(self.final_var_options, 1):
                dlg_var.Update(value=xx, newmsg=f'Analyzing variable: {xx}/{len(self.final_var_options)}\n\n{each_option}')
                var_csv    = os.path.join(self.Charts_data_folder, f'{"{:03d}".format(xx)}.{each_option}.csv')
                var_status = []
                var_value  = []
                with open(file=var_csv, mode='r', encoding='utf-8') as read_obj:
                    rows = csv.DictReader(read_obj)
                    for row in rows:
                       var_status.append(row[each_option+'_Status'])
                       var_value.append(row[each_option])
                
                LSL_str = self.vars_with_L_U[each_option][0]    # str
                USL_str = self.vars_with_L_U[each_option][1]    # str
                
                if var_value:
                    # 下限,上限,最小值,最大值,平均值,总体标准差,精确度,准确度,过程能力指数,计数,-3d,+3d,Pass,Fail,Yield Rate
                    the_LSL   = float(LSL_str)
                    the_USL   = float(USL_str)
                    Min_float = min([float(m) for m in var_value])                              # 这里巧妙
                    Max_float = max([float(m) for m in var_value])                              # 这里巧妙
                    the_Min   = int(Min_float) if int(Min_float) == Min_float else Min_float    # 这里巧妙
                    the_Max   = int(Max_float) if int(Max_float) == Max_float else Max_float    # 这里巧妙
                    the_Avg   = np.mean([float(m) for m in var_value])
                    the_Std   = np.std([float(m) for m in var_value], ddof=1)               # ddof=0,即分母是N,计算的是总体标准差,对应的Excel函数是stdevp(); ddof=1,即分母是N-1,计算的是样本标准差,对应的Excel函数是stdev().
                    the_Cp    = (the_USL - the_LSL) / (6*the_Std)                           # Cp = (USL-LSL) / 6σ
                    the_Ca    = (the_Avg - 0.5*(the_USL+the_LSL)) / (0.5*(the_USL-the_LSL)) # Ca = (x̅-CL) / (0.5*(USL-LSL))
                    the_Cpk   = the_Cp * (1-abs(the_Ca))                                    # Cpk= Cp*(1-|Ca|)
                    the_Count = len(var_value)
                    the_ld    = the_Avg - 3*the_Std
                    the_rd    = the_Avg + 3*the_Std
                    the_Pass  = var_status.count('PASS') + var_status.count('1st Pass')
                    the_Fail  = var_status.count('FAIL')
                    the_Yield = the_Pass/the_Count
                    
                    # ±7σ 的计算, 转换成相应的背景颜色
                    left_7d  = the_Avg - 7*the_Std
                    left_6d  = the_Avg - 6*the_Std
                    left_5d  = the_Avg - 5*the_Std
                    left_4d  = the_Avg - 4*the_Std
                    left_3d  = the_Avg - 3*the_Std
                    left_2d  = the_Avg - 2*the_Std
                    left_1d  = the_Avg - 1*the_Std
                    right_1d = the_Avg + 1*the_Std
                    right_2d = the_Avg + 2*the_Std
                    right_3d = the_Avg + 3*the_Std
                    right_4d = the_Avg + 4*the_Std
                    right_5d = the_Avg + 5*the_Std
                    right_6d = the_Avg + 6*the_Std
                    right_7d = the_Avg + 7*the_Std
                    
                    left_7d_color_value   = ['#FF7F27', left_7d]    # 默认颜色为橙色'#FF7F27'
                    left_6d_color_value   = ['#FF7F27', left_6d]    # 默认颜色为橙色'#FF7F27'
                    left_5d_color_value   = ['#FF7F27', left_5d]    # 默认颜色为橙色'#FF7F27'
                    left_4d_color_value   = ['#FF7F27', left_4d]    # 默认颜色为橙色'#FF7F27'
                    left_3d_color_value   = ['#FF7F27', left_3d]    # 默认颜色为橙色'#FF7F27'
                    left_2d_color_value   = ['#FF7F27', left_2d]    # 默认颜色为橙色'#FF7F27'
                    left_1d_color_value   = ['#FF7F27', left_1d]    # 默认颜色为橙色'#FF7F27'
                    center_0d_color_value = ['#FF7F27', the_Avg]    # 默认颜色为橙色'#FF7F27'
                    right_1d_color_value  = ['#FF7F27', right_1d]   # 默认颜色为橙色'#FF7F27'
                    right_2d_color_value  = ['#FF7F27', right_2d]   # 默认颜色为橙色'#FF7F27'
                    right_3d_color_value  = ['#FF7F27', right_3d]   # 默认颜色为橙色'#FF7F27'
                    right_4d_color_value  = ['#FF7F27', right_4d]   # 默认颜色为橙色'#FF7F27'
                    right_5d_color_value  = ['#FF7F27', right_5d]   # 默认颜色为橙色'#FF7F27'
                    right_6d_color_value  = ['#FF7F27', right_6d]   # 默认颜色为橙色'#FF7F27'
                    right_7d_color_value  = ['#FF7F27', right_7d]   # 默认颜色为橙色'#FF7F27'
                    
                    left_7d_color_value[0]   = '#006837' if the_LSL <  left_7d <  the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    left_6d_color_value[0]   = '#006837' if the_LSL <  left_6d <  the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    left_5d_color_value[0]   = '#006837' if the_LSL <  left_5d <  the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    left_4d_color_value[0]   = '#006837' if the_LSL <  left_4d <  the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    left_3d_color_value[0]   = '#006837' if the_LSL <  left_3d <  the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    left_2d_color_value[0]   = '#006837' if the_LSL <  left_2d <  the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    left_1d_color_value[0]   = '#006837' if the_LSL <  left_1d <  the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    center_0d_color_value[0] = '#006837' if the_LSL <= the_Avg <= the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    right_1d_color_value[0]  = '#006837' if the_LSL <  right_1d < the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    right_2d_color_value[0]  = '#006837' if the_LSL <  right_2d < the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    right_3d_color_value[0]  = '#006837' if the_LSL <  right_3d < the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    right_4d_color_value[0]  = '#006837' if the_LSL <  right_4d < the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    right_5d_color_value[0]  = '#006837' if the_LSL <  right_5d < the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    right_6d_color_value[0]  = '#006837' if the_LSL <  right_6d < the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色
                    right_7d_color_value[0]  = '#006837' if the_LSL <  right_7d < the_USL else '#BD1929'     # '#006837'绿色; '#BD1929'红色

                    # 处理数据保留的位数
                    # 最小值
                    tmp_Min_str   = reserved[login_GUI.n_digit_custom].format(the_Min)
                    tmp_Min_float = float(tmp_Min_str)
                    if abs(the_Min) >= reserved_precision[login_GUI.n_digit_custom] or the_Min == 0:
                        reserved_Min = str(int(tmp_Min_float)) if int(tmp_Min_float) == tmp_Min_float else tmp_Min_str
                    else:
                        reserved_Min = reserved_scientific[login_GUI.n_digit_custom].format(the_Min)
                    
                    # 最大值
                    tmp_Max_str   = reserved[login_GUI.n_digit_custom].format(the_Max)
                    tmp_Max_float = float(tmp_Max_str)
                    if abs(the_Max) >= reserved_precision[login_GUI.n_digit_custom] or the_Max == 0:
                        reserved_Max = str(int(tmp_Max_float)) if int(tmp_Max_float) == tmp_Max_float else tmp_Max_str
                    else:
                        reserved_Max = reserved_scientific[login_GUI.n_digit_custom].format(the_Max)
                    
                    # 平均值
                    tmp_Avg_str   = reserved[login_GUI.n_digit_custom].format(the_Avg)
                    tmp_Avg_float = float(tmp_Avg_str)
                    if abs(the_Avg) >= reserved_precision[login_GUI.n_digit_custom] or the_Avg == 0:
                        reserved_Avg = str(int(tmp_Avg_float)) if int(tmp_Avg_float) == tmp_Avg_float else tmp_Avg_str
                    else:
                        reserved_Avg = reserved_scientific[login_GUI.n_digit_custom].format(the_Avg)
                    
                    # 标准差
                    reserved_Std  = str(the_Std).lower()
                    if reserved_Std not in ['nan', 'inf', '-inf']:
                        tmp_Std_str   = reserved[login_GUI.n_digit_custom].format(the_Std)
                        tmp_Std_float = float(tmp_Std_str)
                        if abs(the_Std) >= reserved_precision[login_GUI.n_digit_custom] or the_Std == 0:
                            reserved_Std = str(int(tmp_Std_float)) if int(tmp_Std_float) == tmp_Std_float else tmp_Std_str
                        else:
                            reserved_Std = reserved_scientific[login_GUI.n_digit_custom].format(the_Std)
                    
                    # Cp
                    reserved_Cp = str(the_Cp).lower()
                    if reserved_Cp not in ['nan', 'inf', '-inf']:
                        tmp_Cp_str   = reserved[login_GUI.n_digit_custom].format(the_Cp)
                        tmp_Cp_float = float(tmp_Cp_str)
                        if abs(the_Cp) >= reserved_precision[login_GUI.n_digit_custom] or the_Cp == 0:
                            reserved_Cp = str(int(tmp_Cp_float)) if int(tmp_Cp_float) == tmp_Cp_float else tmp_Cp_str
                        else:
                            reserved_Cp = reserved_scientific[login_GUI.n_digit_custom].format(the_Cp)
                    
                    # Ca
                    tmp_Ca_str   = reserved[login_GUI.n_digit_custom].format(the_Ca)
                    tmp_Ca_float = float(tmp_Ca_str)
                    if abs(the_Ca) >= reserved_precision[login_GUI.n_digit_custom] or the_Ca == 0:
                        reserved_Ca = str(int(tmp_Ca_float)) if int(tmp_Ca_float) == tmp_Ca_float else tmp_Ca_str
                    else:
                        reserved_Ca = reserved_scientific[login_GUI.n_digit_custom].format(the_Ca)
                    
                    # Cpk
                    reserved_Cpk = str(the_Cpk).lower()
                    if reserved_Cpk not in ['nan', 'inf', '-inf']:
                        tmp_Cpk_str   = reserved[login_GUI.n_digit_custom].format(the_Cpk)
                        tmp_Cpk_float = float(tmp_Cpk_str)
                        if abs(the_Cpk) >= reserved_precision[login_GUI.n_digit_custom] or the_Cpk == 0:
                            reserved_Cpk = str(int(tmp_Cpk_float)) if int(tmp_Cpk_float) == tmp_Cpk_float else tmp_Cpk_str
                        else:
                            reserved_Cpk = reserved_scientific[login_GUI.n_digit_custom].format(the_Cpk) 
                    
                    # -3d
                    reserved_ld = str(the_ld).lower()
                    if reserved_ld not in ['nan', 'inf', '-inf']:                 
                        tmp_ld_str   = reserved[login_GUI.n_digit_custom].format(the_ld)
                        tmp_ld_float = float(tmp_ld_str)
                        if abs(the_ld) >= reserved_precision[login_GUI.n_digit_custom] or the_ld == 0:                  
                            reserved_ld = str(int(tmp_ld_float)) if int(tmp_ld_float) == tmp_ld_float else tmp_ld_str
                        else:
                            reserved_ld = reserved_scientific[login_GUI.n_digit_custom].format(the_ld)     
                    
                    # +3d
                    reserved_rd = str(the_rd).lower()
                    if reserved_rd not in ['nan', 'inf', '-inf']:    
                        tmp_rd_str   = reserved[login_GUI.n_digit_custom].format(the_rd)
                        tmp_rd_float = float(tmp_rd_str)
                        if abs(the_rd) >= reserved_precision[login_GUI.n_digit_custom] or the_rd == 0:                    
                            reserved_rd = str(int(tmp_rd_float)) if int(tmp_rd_float) == tmp_rd_float else tmp_rd_str
                        else:
                            reserved_rd = reserved_scientific[login_GUI.n_digit_custom].format(the_rd)  
                    
                    
                    # 顺便处理一下 -7d ~ +7d
                    # left_7d
                    reserved_left_7d = str(left_7d).lower()
                    if reserved_left_7d not in ['nan', 'inf', '-inf']:                 
                        tmp_left_7d_str   = reserved[login_GUI.n_digit_custom].format(left_7d)
                        tmp_left_7d_float = float(tmp_left_7d_str)
                        if abs(left_7d) >= reserved_precision[login_GUI.n_digit_custom] or left_7d == 0:                  
                            reserved_left_7d = str(int(tmp_left_7d_float)) if int(tmp_left_7d_float) == tmp_left_7d_float else tmp_left_7d_str
                        else:
                            reserved_left_7d = reserved_scientific[login_GUI.n_digit_custom].format(left_7d)
                            
                    # left_6d
                    reserved_left_6d = str(left_6d).lower()
                    if reserved_left_6d not in ['nan', 'inf', '-inf']:                 
                        tmp_left_6d_str   = reserved[login_GUI.n_digit_custom].format(left_6d)
                        tmp_left_6d_float = float(tmp_left_6d_str)
                        if abs(left_6d) >= reserved_precision[login_GUI.n_digit_custom] or left_6d == 0:                  
                            reserved_left_6d = str(int(tmp_left_6d_float)) if int(tmp_left_6d_float) == tmp_left_6d_float else tmp_left_6d_str
                        else:
                            reserved_left_6d = reserved_scientific[login_GUI.n_digit_custom].format(left_6d)
                            
                    # left_5d
                    reserved_left_5d = str(left_5d).lower()
                    if reserved_left_5d not in ['nan', 'inf', '-inf']:                 
                        tmp_left_5d_str   = reserved[login_GUI.n_digit_custom].format(left_5d)
                        tmp_left_5d_float = float(tmp_left_5d_str)
                        if abs(left_5d) >= reserved_precision[login_GUI.n_digit_custom] or left_5d == 0:                  
                            reserved_left_5d = str(int(tmp_left_5d_float)) if int(tmp_left_5d_float) == tmp_left_5d_float else tmp_left_5d_str
                        else:
                            reserved_left_5d = reserved_scientific[login_GUI.n_digit_custom].format(left_5d)
                            
                    # left_4d
                    reserved_left_4d = str(left_4d).lower()
                    if reserved_left_4d not in ['nan', 'inf', '-inf']:                 
                        tmp_left_4d_str   = reserved[login_GUI.n_digit_custom].format(left_4d)
                        tmp_left_4d_float = float(tmp_left_4d_str)
                        if abs(left_4d) >= reserved_precision[login_GUI.n_digit_custom] or left_4d == 0:                  
                            reserved_left_4d = str(int(tmp_left_4d_float)) if int(tmp_left_4d_float) == tmp_left_4d_float else tmp_left_4d_str
                        else:
                            reserved_left_4d = reserved_scientific[login_GUI.n_digit_custom].format(left_4d)
                            
                    # left_3d
                    reserved_left_3d = str(left_3d).lower()
                    if reserved_left_3d not in ['nan', 'inf', '-inf']:                 
                        tmp_left_3d_str   = reserved[login_GUI.n_digit_custom].format(left_3d)
                        tmp_left_3d_float = float(tmp_left_3d_str)
                        if abs(left_3d) >= reserved_precision[login_GUI.n_digit_custom] or left_3d == 0:                  
                            reserved_left_3d = str(int(tmp_left_3d_float)) if int(tmp_left_3d_float) == tmp_left_3d_float else tmp_left_3d_str
                        else:
                            reserved_left_3d = reserved_scientific[login_GUI.n_digit_custom].format(left_3d)
                            
                    # left_2d
                    reserved_left_2d = str(left_2d).lower()
                    if reserved_left_2d not in ['nan', 'inf', '-inf']:                 
                        tmp_left_2d_str   = reserved[login_GUI.n_digit_custom].format(left_2d)
                        tmp_left_2d_float = float(tmp_left_2d_str)
                        if abs(left_2d) >= reserved_precision[login_GUI.n_digit_custom] or left_2d == 0:                  
                            reserved_left_2d = str(int(tmp_left_2d_float)) if int(tmp_left_2d_float) == tmp_left_2d_float else tmp_left_2d_str
                        else:
                            reserved_left_2d = reserved_scientific[login_GUI.n_digit_custom].format(left_2d)
                            
                    # left_1d
                    reserved_left_1d = str(left_1d).lower()
                    if reserved_left_1d not in ['nan', 'inf', '-inf']:                 
                        tmp_left_1d_str   = reserved[login_GUI.n_digit_custom].format(left_1d)
                        tmp_left_1d_float = float(tmp_left_1d_str)
                        if abs(left_1d) >= reserved_precision[login_GUI.n_digit_custom] or left_1d == 0:                  
                            reserved_left_1d = str(int(tmp_left_1d_float)) if int(tmp_left_1d_float) == tmp_left_1d_float else tmp_left_1d_str
                        else:
                            reserved_left_1d = reserved_scientific[login_GUI.n_digit_custom].format(left_1d)
                            
                    # reserved_Avg 已准备好
                    
                    # right_1d
                    reserved_right_1d = str(right_1d).lower()
                    if reserved_right_1d not in ['nan', 'inf', '-inf']:                 
                        tmp_right_1d_str   = reserved[login_GUI.n_digit_custom].format(right_1d)
                        tmp_right_1d_float = float(tmp_right_1d_str)
                        if abs(right_1d) >= reserved_precision[login_GUI.n_digit_custom] or right_1d == 0:                  
                            reserved_right_1d = str(int(tmp_right_1d_float)) if int(tmp_right_1d_float) == tmp_right_1d_float else tmp_right_1d_str
                        else:
                            reserved_right_1d = reserved_scientific[login_GUI.n_digit_custom].format(right_1d)
                            
                    # right_2d
                    reserved_right_2d = str(right_2d).lower()
                    if reserved_right_2d not in ['nan', 'inf', '-inf']:                 
                        tmp_right_2d_str   = reserved[login_GUI.n_digit_custom].format(right_2d)
                        tmp_right_2d_float = float(tmp_right_2d_str)
                        if abs(right_2d) >= reserved_precision[login_GUI.n_digit_custom] or right_2d == 0:                  
                            reserved_right_2d = str(int(tmp_right_2d_float)) if int(tmp_right_2d_float) == tmp_right_2d_float else tmp_right_2d_str
                        else:
                            reserved_right_2d = reserved_scientific[login_GUI.n_digit_custom].format(right_2d)
                            
                    # right_3d
                    reserved_right_3d = str(right_3d).lower()
                    if reserved_right_3d not in ['nan', 'inf', '-inf']:                 
                        tmp_right_3d_str   = reserved[login_GUI.n_digit_custom].format(right_3d)
                        tmp_right_3d_float = float(tmp_right_3d_str)
                        if abs(right_3d) >= reserved_precision[login_GUI.n_digit_custom] or right_3d == 0:                  
                            reserved_right_3d = str(int(tmp_right_3d_float)) if int(tmp_right_3d_float) == tmp_right_3d_float else tmp_right_3d_str
                        else:
                            reserved_right_3d = reserved_scientific[login_GUI.n_digit_custom].format(right_3d)
                            
                    # right_4d
                    reserved_right_4d = str(right_4d).lower()
                    if reserved_right_4d not in ['nan', 'inf', '-inf']:                 
                        tmp_right_4d_str   = reserved[login_GUI.n_digit_custom].format(right_4d)
                        tmp_right_4d_float = float(tmp_right_4d_str)
                        if abs(right_4d) >= reserved_precision[login_GUI.n_digit_custom] or right_4d == 0:                  
                            reserved_right_4d = str(int(tmp_right_4d_float)) if int(tmp_right_4d_float) == tmp_right_4d_float else tmp_right_4d_str
                        else:
                            reserved_right_4d = reserved_scientific[login_GUI.n_digit_custom].format(right_4d)
                            
                    # right_5d
                    reserved_right_5d = str(right_5d).lower()
                    if reserved_right_5d not in ['nan', 'inf', '-inf']:                 
                        tmp_right_5d_str   = reserved[login_GUI.n_digit_custom].format(right_5d)
                        tmp_right_5d_float = float(tmp_right_5d_str)
                        if abs(right_5d) >= reserved_precision[login_GUI.n_digit_custom] or right_5d == 0:                  
                            reserved_right_5d = str(int(tmp_right_5d_float)) if int(tmp_right_5d_float) == tmp_right_5d_float else tmp_right_5d_str
                        else:
                            reserved_right_5d = reserved_scientific[login_GUI.n_digit_custom].format(right_5d)
                            
                    # right_6d
                    reserved_right_6d = str(right_6d).lower()
                    if reserved_right_6d not in ['nan', 'inf', '-inf']:                 
                        tmp_right_6d_str   = reserved[login_GUI.n_digit_custom].format(right_6d)
                        tmp_right_6d_float = float(tmp_right_6d_str)
                        if abs(right_6d) >= reserved_precision[login_GUI.n_digit_custom] or right_6d == 0:                  
                            reserved_right_6d = str(int(tmp_right_6d_float)) if int(tmp_right_6d_float) == tmp_right_6d_float else tmp_right_6d_str
                        else:
                            reserved_right_6d = reserved_scientific[login_GUI.n_digit_custom].format(right_6d)
                            
                    # right_7d
                    reserved_right_7d = str(right_7d).lower()
                    if reserved_right_7d not in ['nan', 'inf', '-inf']:                 
                        tmp_right_7d_str   = reserved[login_GUI.n_digit_custom].format(right_7d)
                        tmp_right_7d_float = float(tmp_right_7d_str)
                        if abs(right_7d) >= reserved_precision[login_GUI.n_digit_custom] or right_7d == 0:                  
                            reserved_right_7d = str(int(tmp_right_7d_float)) if int(tmp_right_7d_float) == tmp_right_7d_float else tmp_right_7d_str
                        else:
                            reserved_right_7d = reserved_scientific[login_GUI.n_digit_custom].format(right_7d)

                    left_7d_color_value[1]   = reserved_left_7d
                    left_6d_color_value[1]   = reserved_left_6d
                    left_5d_color_value[1]   = reserved_left_5d
                    left_4d_color_value[1]   = reserved_left_4d
                    left_3d_color_value[1]   = reserved_left_3d
                    left_2d_color_value[1]   = reserved_left_2d
                    left_1d_color_value[1]   = reserved_left_1d
                    center_0d_color_value[1] = reserved_Avg
                    right_1d_color_value[1]  = reserved_right_1d
                    right_2d_color_value[1]  = reserved_right_2d
                    right_3d_color_value[1]  = reserved_right_3d
                    right_4d_color_value[1]  = reserved_right_4d
                    right_5d_color_value[1]  = reserved_right_5d
                    right_6d_color_value[1]  = reserved_right_6d
                    right_7d_color_value[1]  = reserved_right_7d
                    
                    reserved_Yield = reserved_percent[login_GUI.n_digit_custom].format(the_Yield).replace('.'+'0'*login_GUI.n_digit_custom,'')
                    
                    one_row_data = ['{:03d}'.format(xx),
                                    each_option, 
                                    f'{LSL_str} / {USL_str}',
                                    f'{reserved_Min} / {reserved_Max}',
                                    reserved_Avg,
                                    reserved_Std,
                                    reserved_Cp,
                                    reserved_Ca,
                                    reserved_Cpk,
                                    f'{the_Count}',
                                    reserved_ld,
                                    reserved_rd,
                                    f'{the_Pass}',
                                    f'{the_Fail}',
                                    reserved_Yield,
                                    ]
           
                    if self.Flag_1 and not self.Flag_2:
                        First_Pass  = var_status.count('1st Pass')
                        First_Yield = First_Pass/the_Count
                        one_row_data.append(f'{First_Pass}')
                        one_row_data.append(reserved_percent[login_GUI.n_digit_custom].format(First_Yield).replace('.'+'0'*login_GUI.n_digit_custom,''))
                    one_row_data.append(left_7d_color_value)
                    one_row_data.append(left_6d_color_value)
                    one_row_data.append(left_5d_color_value)
                    one_row_data.append(left_4d_color_value)
                    one_row_data.append(left_3d_color_value)
                    one_row_data.append(left_2d_color_value)
                    one_row_data.append(left_1d_color_value)
                    one_row_data.append(center_0d_color_value)
                    one_row_data.append(right_1d_color_value)
                    one_row_data.append(right_2d_color_value)
                    one_row_data.append(right_3d_color_value)
                    one_row_data.append(right_4d_color_value)
                    one_row_data.append(right_5d_color_value)
                    one_row_data.append(right_6d_color_value)
                    one_row_data.append(right_7d_color_value)
                    
                    self.table_data.append(one_row_data)
                    
                    # 及时绘制出对应每个变量的 Spec子表格
                    Spec_table = wx.ListCtrl(self.scroller, -1, (0,self.H_grid+5+500*(xx-1)),(290,90), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
                    Spec_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
                    Spec_table.SetFont(font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
                    Spec_fieldnames = ['Spec', '']
                    for n, fieldname in enumerate(Spec_fieldnames, 0):
                        Spec_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=170) # Step-1: 必须先插入列
                    Spec_table.SetColumnWidth(col=0, width=120)   # 修改指定的一列的宽度
                    Spec_data = [['LSL:', LSL_str],['USL:', USL_str]]
                    for n, row_data_list in enumerate(Spec_data, 0):
                        index_row = Spec_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                        for m in range(1, len(Spec_fieldnames), 1):
                            Spec_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
                    
                    # 及时绘制出对应每个变量的 Result子表格
                    Result_table = wx.ListCtrl(self.scroller, -1, (0,self.H_grid+5+90+500*(xx-1)),(290,380), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
                    Result_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
                    Result_table.SetFont(font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
                    Result_fieldnames = ['Result', '']
                    for n, fieldname in enumerate(Result_fieldnames, 0):
                            Result_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=170) # Step-1: 必须先插入列
                    Result_table.SetColumnWidth(col=0, width=120)   # 修改指定的一列的宽度
                    Result_data = [['Min:',        reserved_Min],
                                   ['Max:',        reserved_Max],
                                   ['Avg:',        reserved_Avg],
                                   ['Std:',        reserved_Std],
                                   ['-3d:',        reserved_ld],
                                   ['+3d:',        reserved_rd],
                                   ['Cp:',         reserved_Cp],
                                   ['Ca:',         reserved_Ca],
                                   ['Cpk:',        reserved_Cpk],
                                   ['Pass:',       f'{the_Pass}'],
                                   ['Fail:',       f'{the_Fail}'],
                                   ['Yield Rate:', reserved_Yield],
                                   ]
                    for n, row_data_list in enumerate(Result_data, 0):
                        index_row = Result_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                        for m in range(1, len(Result_fieldnames), 1):
                            Result_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
                    if reserved_Std == 'nan':
                        Result_table.SetItem(index=3, column=1, label='')
                    elif reserved_Std == 'inf':
                        Result_table.SetItem(index=3, column=1, label='∞')
                    elif reserved_Std == '-inf':
                        Result_table.SetItem(index=3, column=1, label='-∞') 
                    
                    if reserved_ld == 'nan':
                        Result_table.SetItem(index=4, column=1, label='')
                    elif reserved_ld == 'inf':
                        Result_table.SetItem(index=4, column=1, label='∞')
                    elif reserved_ld == '-inf':
                        Result_table.SetItem(index=4, column=1, label='-∞')
                    
                    if reserved_rd == 'nan':
                        Result_table.SetItem(index=5, column=1, label='')
                    elif reserved_rd == 'inf':
                        Result_table.SetItem(index=5, column=1, label='∞')
                    elif reserved_rd == '-inf':
                        Result_table.SetItem(index=5, column=1, label='-∞')
                    
                    if reserved_Cp == 'nan':
                        Result_table.SetItem(index=6, column=1, label='')
                    elif reserved_Cp == 'inf':
                        Result_table.SetItem(index=6, column=1, label='∞')
                    elif reserved_Cp == '-inf':
                        Result_table.SetItem(index=6, column=1, label='-∞')                        
                    
                    if reserved_Cpk == 'nan':
                        Result_table.SetItem(index=8, column=1, label='')
                    elif reserved_Cpk == 'inf':
                        Result_table.SetItem(index=8, column=1, label='∞')
                    elif reserved_Cpk == '-inf':
                        Result_table.SetItem(index=8, column=1, label='-∞')    
                    
                    if login_GUI.mark_color_custom:
                        if the_ld < the_LSL:
                            Result_table.SetItemTextColour(item=4, col='red')
                        if the_rd > the_USL:
                            Result_table.SetItemTextColour(item=5, col='red')
                        if the_Cpk < 1.33:
                            Result_table.SetItemTextColour(item=8, col='red')
                
                else: # 当某个变量没有抓到任何值时, 会执行这里.
                    one_row_data = ['{:03d}'.format(xx),
                                    each_option,
                                    f'{LSL_str} / {USL_str}',
                                    'Empty / Empty',
                                    'Empty',
                                    'Empty',
                                    'Empty',
                                    'Empty',
                                    'Empty',
                                    'Empty',
                                    'Empty',
                                    'Empty',
                                    'Empty',
                                    'Empty',
                                    'Empty',
                                    ]
                    if self.Flag_1 and not self.Flag_2:
                        one_row_data.append('Empty')
                        one_row_data.append('Empty')
                    
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    one_row_data.append(['#BD1929','Empty'])      #BD1929'红色
                    
                    self.table_data.append(one_row_data)
                    
                    # 及时绘制出对应每个变量的 Spec子表格
                    Spec_table = wx.ListCtrl(self.scroller, -1, (0,self.H_grid+5+500*(xx-1)),(290,90), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
                    Spec_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
                    Spec_table.SetFont(font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
                    Spec_fieldnames = ['Spec', '']
                    for n, fieldname in enumerate(Spec_fieldnames, 0):
                        Spec_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=170) # Step-1: 必须先插入列
                    Spec_table.SetColumnWidth(col=0, width=120)   # 修改指定的一列的宽度
                    Spec_data = [['LSL:', LSL_str],['USL:', USL_str]]
                    for n, row_data_list in enumerate(Spec_data, 0):
                        index_row = Spec_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                        for m in range(1, len(Spec_fieldnames), 1):
                            Spec_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
                    
                    # 及时绘制出对应每个变量的 Result子表格
                    Result_table = wx.ListCtrl(self.scroller, -1, (0,self.H_grid+5+90+500*(xx-1)),(290,380), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
                    Result_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
                    Result_table.SetFont(font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
                    Result_fieldnames = ['Result', '']
                    for n, fieldname in enumerate(Result_fieldnames, 0):
                            Result_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=170) # Step-1: 必须先插入列
                    Result_table.SetColumnWidth(col=0, width=120)   # 修改指定的一列的宽度
                    Result_data = [['Min:',         'Empty'],
                                    ['Max:',        'Empty'],
                                    ['Avg:',        'Empty'],
                                    ['Std:',        'Empty'],
                                    ['-3d:',        'Empty'],
                                    ['+3d:',        'Empty'],
                                    ['Cp:',         'Empty'],
                                    ['Ca:',         'Empty'],
                                    ['Cpk:',        'Empty'],
                                    ['Pass:',       'Empty'],
                                    ['Fail:',       'Empty'],
                                    ['Yield Rate:', 'Empty'],
                                    ]
                    for n, row_data_list in enumerate(Result_data, 0):
                        index_row = Result_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                        for m in range(1, len(Result_fieldnames), 1):
                            Result_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
                        Result_table.SetItemTextColour(item=n, col='red')
            dlg_var.Destroy()
            print('汇总表格的数据为: table_data', self.table_data, sep='\n', end='\n\n')
            
            # ==================================== 这里向下是一定会执行先画出总结的表格, 哪怕都是 'Empty'
            self.summary_table = grid.Grid(self.scroller, -1, (0,0), (self.scroller.Size[0]-20, self.H_grid), style=wx.WANTS_CHARS)
            table_fieldnames = ['Item', 'LSL / USL', 'Min / Max', 'Avg.', 'Std.', 'CP', 'CA', 'CPK', 'Count', '-3d', '+3d', 'Pass', 'Fail', 'Yield']
            if self.Flag_1 and not self.Flag_2:
                table_fieldnames.append('1st Pass')
                table_fieldnames.append('1st Yield')
            table_fieldnames += ['-7','-6','-5','-4','-3','-2','-1','0','1','2','3','4','5','6','7']
            self.summary_table.CreateGrid(numRows=len(self.table_data), numCols=len(table_fieldnames))
            self.summary_table.EnableEditing(edit=False)
            self.summary_table.Bind(grid.EVT_GRID_CELL_LEFT_DCLICK, self.OnCellLeftDClick)
            self.summary_table.Bind(grid.EVT_GRID_CELL_RIGHT_DCLICK, self.OnCellRightDClick)
            self.summary_table.Bind(grid.EVT_GRID_LABEL_RIGHT_CLICK, self.OnLabelRightClick)

            # ---------------------------------------- 设置标签Label
            self.summary_table.SetGridLineColour((171,171,171))                                     # 设置所有单元格线的颜色,默认值是(192,192,192,255)
            self.summary_table.SetColLabelSize(height=25)                                           # 设置列标签的高度, 而列标签的宽度随单元格的宽度
            self.summary_table.SetRowLabelSize(width=40)                                            # 设置行标签的宽度，而行标签的高度随单元格的高度
            self.summary_table.SetCornerLabelValue('No.')
            # self.summary_table.SetColLabelValue(col=1, value="这是第2列")                          # 设置第2列标签
            for n, per_fieldname in enumerate(table_fieldnames, 0):
                self.summary_table.SetColLabelValue(col=n, value=per_fieldname)
            # self.summary_table.SetRowLabelValue(row=2, value="这是第3行")                          # 设置第3行标签
            for per_n in range(0, len(self.table_data), 1):
                self.summary_table.SetRowLabelValue(row=per_n, value='{:03d}'.format(per_n+1))   
            self.summary_table.SetLabelBackgroundColour(colour=(248,249,250))                       # 设置标签的背景颜色
            self.summary_table.SetLabelTextColour(colour=('blue'))                                  # 设置标签的字体颜色
            self.summary_table.SetCornerLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)   # 设置Corner标签左右以及上下对齐方式：左对齐，下沉
            self.summary_table.SetColLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)      # 设置column标签左右以及上下对齐方式：左对齐，下沉
            self.summary_table.SetRowLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)      # 设置row标签左右以及上下对齐方式：   右对齐，下沉
            self.summary_table.SetLabelFont(font=wx.Font(pointSize=10, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_BOLD, underline=False, faceName='Microsoft JhengHei UI'))
            
            # ---------------------------------------- 设置单个单元格cell
            # self.summary_table.SetColSize(col=1, width=120)                                       # 设置第2列的宽度
            for per_n in range(0, len(table_fieldnames), 1):
                self.summary_table.SetColSize(col=per_n, width=70)  
            self.summary_table.SetColSize(col=0, width=160)
            self.summary_table.SetColSize(col=1, width=90)
            self.summary_table.SetColSize(col=2, width=130)
            self.summary_table.SetColSize(col=13, width=60)
            self.summary_table.SetColSize(col=len(table_fieldnames)-15, width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-14, width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-13, width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-12, width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-11, width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-10, width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-9,  width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-8,  width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-7,  width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-6,  width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-5,  width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-4,  width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-3,  width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-2,  width=50)
            self.summary_table.SetColSize(col=len(table_fieldnames)-1,  width=50)
            
            # self.summary_table.SetRowSize(row=1, height=80)                                       # 设置第2行的高度
            for per_n in range(0, len(self.table_data), 1):
                self.summary_table.SetRowSize(row=per_n, height=21)
            # self.summary_table.SetCellValue(row=1, col=1, s='ABC')                                 #设置第2行第2列的值,这个值一定要是字符或字符串格式,单元格默认可编辑和可溢出
            # self.summary_table.SetCellBackgroundColour(row=1, col=1, colour=wx.CYAN)               # 设置指定单元格的背景颜色
            # self.summary_table.SetCellTextColour(row=1, col=1, colour=wx.RED)                      # 设置指定单元格的字体颜色
            # self.summary_table.SetCellFont(row=1, col=1, font=wx.Font(10, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            
            for m, each_var_data in enumerate(self.table_data, 0):
                for n in range(len(table_fieldnames)-15):
                    self.summary_table.SetCellValue(row=m, col=n, s=each_var_data[n+1])
                    # self.summary_table.SetCellBackgroundColour(row=m, col=n, colour=(227,242,253))
                    self.summary_table.SetCellFont(row=m, col=n, font=wx.Font(10, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
                for n in range(15,0,-1):
                    self.summary_table.SetCellValue(row=m, col=len(table_fieldnames)-n, s=each_var_data[-n][1])
                    self.summary_table.SetCellFont(row=m, col=len(table_fieldnames)-n, font=wx.Font(8, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
                    
                # Case1: LSL/USL都为空即没有值时的字体颜色强制设置成红色
                if each_var_data[3] == 'Empty / Empty':
                    for i in range(2, len(table_fieldnames)-15):
                        self.summary_table.SetCellTextColour(row=m, col=i, colour=wx.RED)
                
                # Case2: 有值时, 要考虑到 std., CP, CPK, -3d, +3d, 不能显示写成 'nan', 'inf', '-inf'
                else:
                    # std.
                    if each_var_data[5] == 'nan':
                        self.summary_table.SetCellValue(row=m, col=4, s='')
                    elif each_var_data[5] == 'inf':
                        self.summary_table.SetCellValue(row=m, col=4, s='∞')
                    elif each_var_data[5] == '-inf':
                        self.summary_table.SetCellValue(row=m, col=4, s='-∞')
                    
                    # CP
                    if each_var_data[6] == 'nan':
                        self.summary_table.SetCellValue(row=m, col=5, s='')
                    elif each_var_data[6] == 'inf':
                        self.summary_table.SetCellValue(row=m, col=5, s='∞')
                    elif each_var_data[6] == '-inf':
                        self.summary_table.SetCellValue(row=m, col=5, s='-∞')
                    
                    # CPK
                    if each_var_data[8] == 'nan':
                        self.summary_table.SetCellValue(row=m, col=7, s='')
                    elif each_var_data[8] == 'inf':
                        self.summary_table.SetCellValue(row=m, col=7, s='∞')
                    elif each_var_data[8] == '-inf':
                        self.summary_table.SetCellValue(row=m, col=7, s='-∞')    
                    
                    # -3d
                    if each_var_data[10] == 'nan':
                        self.summary_table.SetCellValue(row=m, col=9, s='')
                    elif each_var_data[10] == 'inf':
                        self.summary_table.SetCellValue(row=m, col=9, s='∞')
                    elif each_var_data[10] == '-inf':
                        self.summary_table.SetCellValue(row=m, col=9, s='-∞')
                    
                    # +3d
                    if each_var_data[11] == 'nan':
                        self.summary_table.SetCellValue(row=m, col=10, s='')
                    elif each_var_data[11] == 'inf':
                        self.summary_table.SetCellValue(row=m, col=10, s='∞')
                    elif each_var_data[11] == '-inf':
                        self.summary_table.SetCellValue(row=m, col=10, s='-∞')    
                    
                    # Case3: 有值时, 不满足±3σ理论和Cpk<1.33的字体颜色强制设置成红色
                    if login_GUI.mark_color_custom:
                        if float(each_var_data[10]) < float(each_var_data[2].split('/')[0]):
                            self.summary_table.SetCellTextColour(row=m, col=9, colour=wx.RED)
                        if float(each_var_data[11]) > float(each_var_data[2].split('/')[1]):
                            self.summary_table.SetCellTextColour(row=m, col=10, colour=wx.RED)
                        if float(each_var_data[8]) < 1.33:
                            self.summary_table.SetCellTextColour(row=m, col=7, colour=wx.RED)
                    
                    # Case4: 有值时, [Fail]列不等于0时的字体颜色强制设置成红色
                    if each_var_data[13] != '0':
                        self.summary_table.SetCellTextColour(row=m, col=12, colour=wx.RED)
                        
                # 统一设定±7σ的背景颜色设置
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-15, colour=each_var_data[-15][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-14, colour=each_var_data[-14][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-13, colour=each_var_data[-13][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-12, colour=each_var_data[-12][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-11, colour=each_var_data[-11][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-10, colour=each_var_data[-10][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-9,  colour=each_var_data[-9][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-8,  colour=each_var_data[-8][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-7,  colour=each_var_data[-7][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-6,  colour=each_var_data[-6][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-5,  colour=each_var_data[-5][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-4,  colour=each_var_data[-4][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-3,  colour=each_var_data[-3][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-2,  colour=each_var_data[-2][0])
                self.summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-1,  colour=each_var_data[-1][0])

            # ==================================== 这里向下是一定会执行画出直方图, 哪怕都是 'Empty'
            # ------------ 即刻开启进度对话框, 借助pandas模块又一次重新读取刚刚保存好的 04_Chart_data\variable.csv 档案
            # 重点理解: wx.PD_AUTO_HIDE的效果是结束时进度条对话框自动消失(但依然活在PC的运行内存中),注意其区别与 dlg_hist.Destroy(),后者使得控件在PC的运行内存中彻底不存在.
            dlg_hist  = wx.ProgressDialog(title='Drawing Histogram', message=f'Drawing histogram: 0/{len(self.final_var_options)}', maximum=len(self.final_var_options), parent=None, style=wx.PD_CAN_ABORT|wx.PD_AUTO_HIDE)
            keepGoing = (True, True)
            for i,j in enumerate(self.final_var_options, 1):    # 注意: 这里使用了 For ... (break)...else 语法结构.
                tmp_var_csv  = f'{"{:03d}".format(i)}.{j}.csv'
                print(f'{tmp_var_csv}')
                #keepGoing = dlg_hist.Update(value=i, newmsg=f'Completed: {i}/{len(self.final_var_options)}')
                print('keepGoing:', keepGoing)
                if keepGoing[0]:
                    raw_LSL      = self.vars_with_L_U[j][0]     # str
                    raw_USL      = self.vars_with_L_U[j][1]     # str
                    var_LSL      = float(raw_LSL)
                    var_USL      = float(raw_USL)
                    
                    var_csv_file = os.path.join(self.Charts_data_folder, tmp_var_csv)
                    pd_data      = pd.read_csv(var_csv_file, header=0, encoding='utf-8')
                    var_data     = pd_data[j]       # 注意: <class 'pandas.core.series.Series'>, 不是list.
                    var_data_min = var_data.min()   # 注意: <class 'numpy.float64'>
                    var_data_max = var_data.max()   # 注意: <class 'numpy.float64'>
                    
                    if login_GUI.algorithm_Hist_custom == 'LogiNet2.0': # 采用与 LogiNet2.0 一致的算法
                        final_min = min(var_LSL, var_data_min)
                        final_max = max(var_USL, var_data_max)
                        duration  = (final_max-final_min)/self.Interval_user
                        bin_spec  = [round(final_min+duration*n,9) for n in range(self.Interval_user+1)]# 注意: 这里分bin时, 用9位小数去计算, 以规避出现[0.00, 0.00, 0.00, ...]
                        
                        try:
                            # 注意: numpy模块的 np.histogram(...)切割区间时是左闭右开, 最后一个区间会自动是左闭右闭区间，而且bins中默认允许有相同的值.
                            # hist_data, hist_binspec = np.histogram(a=var_data, bins=bin_spec, range=None, density=False, weights=None)
                            # max_group = np.max(hist_data)
                            
                            # 注意: pandas模块的 pd.cut(...)切割区间时是左开右闭, 第一个区间需要人为设置为左闭右闭区间, 而且bins中默认不允许有相同的值.
                            sequence  = pd.cut(x=var_data, bins=bin_spec, duplicates='raise', include_lowest=True) # 注意: 若采用默认的include_lowest=False,是左开右闭区间,则第一个区间统计会不准确.
                            hist_data = sequence.value_counts(sort=False)   # 注意: <class 'pandas.core.series.Series'>, 默认的sort=True,会从大到小排列后显示.
                            max_group = max(hist_data)                      # 注意: <class 'int'>
                            
                            one_hist  = self.PolyHistogram_FCT(specified_hist=hist_data,
                                                                specified_binspec=bin_spec,
                                                                specified_LSL=var_LSL,
                                                                specified_USL=var_USL,
                                                                specified_max_group=max_group,
                                                                specified_title=os.path.splitext(tmp_var_csv)[0],
                                                                specified_xLabel='Data Point',
                                                                specified_pos=(350, self.H_grid+5+500*(i-1)),
                                                                #specified_xAxis=(var_LSL, var_USL),
                                                                specified_xAxis=(var_data_min if var_data_min < var_LSL else var_LSL, var_data_max if var_data_max > var_USL else var_USL),
                                                                )
                            self.all_histogram.append(one_hist)
                        except:
                            try_crash_error = traceback.format_exc()
                            wx.MessageBox(message=f'Please find below Error:\n\nAlgorithm: {login_GUI.algorithm_Hist_custom}\nVariable: {j}\nLSL / USL: {raw_LSL} / {raw_USL}\nbins = {bin_spec}\n\n{try_crash_error}', caption='myWarning: ValueError', style=wx.ICON_WARNING, parent=self)
                            dlg_hist.Destroy()
                            break
                    elif login_GUI.algorithm_Hist_custom == 'LogiNet2.0(LSL~USL)':   # 采用与 LogiNet2.0(LSL~USL) 一致的算法
                        duration = (var_USL-var_LSL)/self.Interval_user
                        bin_spec = [round(var_LSL+duration*n,9) for n in range(self.Interval_user+1)]   # 注意: 这里分bin时, 用9位小数去计算, 以规避出现[0.00, 0.00, 0.00, ...]
                        if var_data_min < var_LSL:
                            add_left = math.ceil((var_LSL-var_data_min)/duration)
                            for n in range(1, add_left+1):
                                bin_spec.insert(0,var_LSL-duration*n)               # 这里是向前 insert
                        if var_data_max > var_USL:
                            add_right = math.ceil((var_data_max-var_USL)/duration)
                            for n in range(1, add_right+1):
                                bin_spec.append(var_USL+duration*n)                 # 这里是向后 append
                        try:
                            # 注意: numpy模块的 np.histogram(...)切割区间时是左闭右开, 最后一个区间会自动是左闭右闭区间，而且bins中默认允许有相同的值.
                            # hist_data, hist_binspec = np.histogram(a=var_data, bins=bin_spec, range=None, density=False, weights=None)
                            # max_group = np.max(hist_data)
                            
                            # 注意: pandas模块的 pd.cut(...)切割区间时是左开右闭, 第一个区间需要人为设置为左闭右闭区间, 而且bins中默认不允许有相同的值.
                            sequence  = pd.cut(x=var_data, bins=bin_spec, duplicates='raise', include_lowest=True) # 注意: 若采用默认的include_lowest=False,是左开右闭区间,则第一个区间统计会不准确.
                            hist_data = sequence.value_counts(sort=False)   # 注意: <class 'pandas.core.series.Series'>, 默认的sort=True,会从大到小排列后显示.
                            max_group = max(hist_data)                      # 注意: <class 'int'>
                            
                            one_hist  = self.PolyHistogram_FCT(specified_hist=hist_data,
                                                                specified_binspec=bin_spec,
                                                                specified_LSL=var_LSL,
                                                                specified_USL=var_USL,
                                                                specified_max_group=max_group,
                                                                specified_title=os.path.splitext(tmp_var_csv)[0],
                                                                specified_xLabel='Data Point',
                                                                specified_pos=(350, self.H_grid+5+500*(i-1)),
                                                                specified_xAxis=(var_LSL, var_USL),
                                                                #specified_xAxis=(var_data_min if var_data_min < var_LSL else var_LSL, var_data_max if var_data_max > var_USL else var_USL),
                                                                )
                            self.all_histogram.append(one_hist)
                        except:
                            try_crash_error = traceback.format_exc()
                            wx.MessageBox(message=f'Please find below Error:\n\nAlgorithm: {login_GUI.algorithm_Hist_custom}\nVariable: {j}\nLSL / USL: {raw_LSL} / {raw_USL}\nbins = {bin_spec}\n\n{try_crash_error}', caption='myWarning: ValueError', style=wx.ICON_WARNING, parent=self)
                            dlg_hist.Destroy()
                            break
                    
                    elif login_GUI.algorithm_Hist_custom == 'Minitab(Simple)':   # 采用与 Minitab(Simple) 一致的算法
                        figure = Figure(figsize=(self.Hist_W_custom/100,self.Hist_H_custom/100), dpi=100, linewidth=0.5)
                        ax1    = figure.add_subplot(111)    # 即 nrows=1, ncols=1, index=1, 而且: num must be an integer with ncols <= num <= nrows, not 0
                        ax1.grid(visible=True, which='both', axis='both', color='grey', linestyle='-', linewidth=0.1 if self.flag_Grid_custom else 0)
                        
                        # ======================== 绘制直方图(纵坐标是Frequency)
                        hist_data, bin_spec, _ = ax1.hist(x=var_data,
                                                        bins=self.Interval_user,
                                                        range=None,
                                                        density=False,
                                                        weights=None,
                                                        cumulative=False,
                                                        bottom=0,
                                                        histtype='bar',
                                                        align='mid',
                                                        orientation='vertical',
                                                        rwidth=None,
                                                        log=False,
                                                        color='cornflowerblue', # 矢车菊
                                                        label='Histogram',
                                                        stacked=False,
                                                        edgecolor='black',
                                                        linewidth=0.5,
                                                        alpha=1,                # 透明度为0代表不显示, 1代表最清晰显示.
                                                        )
                        frequency_max_hist_yAxis = np.max(hist_data)    # <class 'numpy.float64'>, 带小数点的小数
                        print('frequency_max_hist_yAxis:', frequency_max_hist_yAxis)
                        bin_spec = bin_spec.tolist()
                        ax1.set_title(label=os.path.splitext(tmp_var_csv)[0], fontsize=14, color='b')
                        # ====== 设置X轴的取值范围, 刻度显示采用永远的10个刻度区间.
                        final_min = min(var_LSL, var_data_min)
                        final_max = max(var_USL, var_data_max)
                        ax1.set_xlim(left=final_min-(final_max-final_min)/10*0.05, right=final_max+(final_max-final_min)/10*0.05)                                   # 设置X轴的取值范围 
                        ax1.set_xticks(ticks=[final_min+(final_max-final_min)/10 * i for i in range(11)]) # 设置X轴的刻度范围,1D array-like               
                        # ====== 设置Y轴的取值范围, 刻度显示采用默认即可.
                        ax1.set_ylabel(ylabel='Frequency', fontsize=10, color='b')
                        ax1.set_ylim(bottom=0, top=frequency_max_hist_yAxis*1.05)
                        # ====== 添加标签, 在每个柱子上标记出柱子的高度(即个数)
                        if self.flag_Label_custom:
                            for c, height_bar in enumerate(hist_data,0):
                                ax1.text(x=bin_spec[c], y=height_bar, s=str(int(height_bar)), fontsize=8, ha='left', color='purple')
                        # ====== 绘制竖直线
                        #函数原型: axvline(x=0, ymin=0, ymax=1, **kwargs)
                        #x : float, default: 0
                        #    x position in data coordinates of the vertical line.
                        #ymin : float, default: 0
                        #    Should be between 0 and 1, 0 being the bottom of the plot, 1 the top of the plot.
                        #ymax : float, default: 1
                        #   Should be between 0 and 1, 0 being the bottom of the plot, 1 the top of the plot.
                        ax1.axvline(x=var_LSL, ymin=0, ymax=0.95, color='red', linestyle='--', label='LSL,USL', linewidth=1.5)
                        ax1.axvline(x=var_USL, ymin=0, ymax=0.95, color='red', linestyle='--', label='',        linewidth=1.5)
                        ax1.text(x=var_LSL, y=frequency_max_hist_yAxis, s='LSL', fontsize=10, ha='center', color='r')
                        ax1.text(x=var_USL, y=frequency_max_hist_yAxis, s='USL', fontsize=10, ha='center', color='r')
                        
                        figure.legend()
                        
                        # ======================== 正式将直方图和正态分布的概率密度曲线画到画布上
                        # ======================== 但是,这里发现了一个Bug: 当 canvas 的个数大于63时,从第64个canvas开始不能正常显示.
                        # pnl = wx.Panel(self.scroller, pos=(350, self.H_grid+5+500*(i-1)), size=(self.Hist_W_custom,self.Hist_H_custom))
                        # canvas = FigureCanvas(parent=pnl, id=-1, figure=figure)
                        # self.all_histogram.append({ax1.get_title():canvas})
                        # ======================== 最终,这里修复了一个Bug: 将图片直接通过控件wx.StaticBitmap放在self.scroller.
                        image_saved = os.path.join(self.temp_folder, f'{os.path.splitext(tmp_var_csv)[0]}.jpg')
                        figure.savefig(fname=image_saved)
                        hist_show = wx.StaticBitmap(self.scroller, bitmap=wx.Bitmap(img=wx.Image(name=image_saved)), pos=(350, self.H_grid+5+500*(i-1)), size=(self.Hist_W_custom,self.Hist_H_custom))
                        self.all_histogram.append({ax1.get_title():figure})
                        
                    elif login_GUI.algorithm_Hist_custom == 'Minitab(With Fit)':   # 采用与 Minitab(With Fit) 一致的算法
                        figure = Figure(figsize=(self.Hist_W_custom/100,self.Hist_H_custom/100), dpi=100, linewidth=0.5)
                        ax1    = figure.add_subplot(111)    # 即 nrows=1, ncols=1, index=1, 而且: num must be an integer with ncols <= num <= nrows, not 0
                        ax1.grid(visible=True, which='both', axis='both', color='grey', linestyle='-', linewidth=0.1 if self.flag_Grid_custom else 0)
                        # ======================== 绘制直方图(纵坐标是Density)
                        # pd: probability density 概率密度
                        # 注意: 这里的概率密度图不会被显示, 画它的目的只为得到 pd_max_hist_yAxis, 然后与正态分布的概率密度图的 pd_max_normal 做比较, 最终设置右侧Y轴的刻度.
                        hist_data, bin_spec, _ = ax1.hist(x=var_data,
                                                        bins=self.Interval_user,
                                                        range=None,
                                                        density=True,
                                                        weights=None,
                                                        cumulative=False,
                                                        bottom=0,
                                                        histtype='bar',
                                                        align='mid',
                                                        orientation='vertical',
                                                        rwidth=None,
                                                        log=False,
                                                        color='cornflowerblue', # 矢车菊
                                                        label=None,
                                                        stacked=False,
                                                        edgecolor='black',
                                                        linewidth=0.5,
                                                        alpha=0,                # 透明度为0代表不显示, 1代表最清晰显示.
                                                        )
                        pd_max_hist_yAxis = np.max(hist_data)   # <class 'numpy.float64'>, 带小数点的小数
                        print('pd_max_hist_yAxis:', pd_max_hist_yAxis)

                        # ======================== 绘制直方图(纵坐标是Frequency)
                        hist_data, bin_spec, _ = ax1.hist(x=var_data,
                                                        bins=self.Interval_user,
                                                        range=None,
                                                        density=False,
                                                        weights=None,
                                                        cumulative=False,
                                                        bottom=0,
                                                        histtype='bar',
                                                        align='mid',
                                                        orientation='vertical',
                                                        rwidth=None,
                                                        log=False,
                                                        color='cornflowerblue', # 矢车菊
                                                        label='Histogram',
                                                        stacked=False,
                                                        edgecolor='black',
                                                        linewidth=0.5,
                                                        alpha=1,                # 透明度为0代表不显示, 1代表最清晰显示.
                                                        )
                        frequency_max_hist_yAxis = np.max(hist_data)    # <class 'numpy.float64'>, 带小数点的小数
                        print('frequency_max_hist_yAxis:', frequency_max_hist_yAxis)
                        bin_spec = bin_spec.tolist()
                        ax1.set_title(label=os.path.splitext(tmp_var_csv)[0], fontsize=14, color='b')
                        # ====== 设置X轴的取值范围, 刻度显示采用永远的10个刻度区间.
                        ax1.set_xlim(left=var_LSL, right=var_USL)                                   # 设置X轴的取值范围 
                        ax1.set_xticks(ticks=[var_LSL+(var_USL-var_LSL)/10 * i for i in range(11)]) # 设置X轴的刻度范围,1D array-like               
                        # ====== 设置Y轴的取值范围, 刻度显示采用默认即可.
                        # 注意: 由于借助 ax1 画了两次 Histogram, 然而左侧Y轴的刻度会默认以两次画直方图时的最大值来自动设置.
                        # 但是，我需要的是左侧的Y轴坐标必须以 (0,frequency_max_hist_yAxis) 即频数来设置.
                        ax1.set_ylabel(ylabel='Frequency', fontsize=10, color='b')
                        ax1.set_ylim(bottom=0, top=frequency_max_hist_yAxis*1.05)
                        # ====== 添加标签, 在每个柱子上标记出柱子的高度(即个数)
                        if self.flag_Label_custom:
                            for c, height_bar in enumerate(hist_data,0):
                                ax1.text(x=bin_spec[c], y=height_bar, s=str(int(height_bar)), fontsize=8, ha='left', color='purple')
                        
                        # ======================== 绘制正态分布的概率密度曲线
                        # 特别注意(1): 当只有一笔有效数据时,由于标准差sigma为nan(因为分母是N-1)无法计算,所以就不会绘制出正态分布的概率密度曲线
                        # 特别注意(2): 当有效数据都相等时,由于标准差sigma为0,所以就不会绘制出正态分布的概率密度曲线
                        ax2 = ax1.twinx() # 创建第二个坐标轴
                        mu, sigma = var_data.mean(), var_data.std() # 默认 .std(ddof=1)
                        print(f'mu: {mu}, sigma: {sigma}')
                        if not any([math.isnan(sigma), math.isinf(sigma)]):
                            if sigma != 0:
                                x = np.linspace(start=mu-6*sigma, stop=mu+6*sigma, num=500)
                                ax2.plot(x, 1/(sigma * np.sqrt(2 * np.pi)) * np.exp(- (x - mu)**2 / (2 * sigma**2)), linewidth=1.5, color='brown', label='Normal')
                                # 获取Axes中的Line2D对象,提取y值,获得正态分布曲线上纵坐标的概率密度y最大值
                                lines = ax2.get_lines()
                                all_y_values = [line.get_ydata() for line in lines]
                                pd_max_normal = np.max(all_y_values[0])
                                print('pd_max_normal:', pd_max_normal)
                                ax2.set_ylabel(ylabel='Density', fontsize=10, color='brown')
                                # ====== 添加标签, 在X轴上标记出 -6σ, -3σ, 3σ, 6σ
                                ax1.text(x=mu-6*sigma, y=0, s='-6σ', fontsize=12, ha='center', color='g')
                                ax1.text(x=mu-3*sigma, y=0, s='-3σ', fontsize=12, ha='center', color='g')
                                ax1.text(x=mu+3*sigma, y=0, s='3σ',  fontsize=12, ha='center', color='g')
                                ax1.text(x=mu+6*sigma, y=0, s='6σ',  fontsize=12, ha='center', color='g')
                                # ====== 设置Y轴的取值范围, 刻度显示采用默认即可.
                                if pd_max_hist_yAxis >= pd_max_normal:
                                    ax2.set_ylim(bottom=0, top=pd_max_hist_yAxis*1.05)
                                else:
                                    final_ax1_yTop = frequency_max_hist_yAxis + (pd_max_normal*1.05-pd_max_hist_yAxis) * (frequency_max_hist_yAxis/pd_max_hist_yAxis)
                                    if not any([math.isnan(final_ax1_yTop), math.isinf(final_ax1_yTop)]):   # ValueError: Axis limits cannot be NaN or Inf
                                        ax1.set_ylim(bottom=0, top=final_ax1_yTop)
                                        ax2.set_ylim(bottom=0, top=pd_max_normal*1.05)
                        figure.legend()
                        
                        # ======================== 正式将直方图和正态分布的概率密度曲线画到画布上
                        # ======================== 但是,这里发现了一个Bug: 当 canvas 的个数大于63时,从第64个canvas开始不能正常显示.
                        # pnl = wx.Panel(self.scroller, pos=(350, self.H_grid+5+500*(i-1)), size=(self.Hist_W_custom,self.Hist_H_custom))
                        # canvas = FigureCanvas(parent=pnl, id=-1, figure=figure)
                        # self.all_histogram.append({ax1.get_title():canvas})
                        # ======================== 最终,这里修复了一个Bug: 将图片直接通过控件wx.StaticBitmap放在self.scroller.
                        image_saved = os.path.join(self.temp_folder, f'{os.path.splitext(tmp_var_csv)[0]}.jpg')
                        figure.savefig(fname=image_saved)
                        hist_show = wx.StaticBitmap(self.scroller, bitmap=wx.Bitmap(img=wx.Image(name=image_saved)), pos=(350, self.H_grid+5+500*(i-1)), size=(self.Hist_W_custom,self.Hist_H_custom))
                        self.all_histogram.append({ax1.get_title():figure})
                                               
                    print('(1)Histogram drawn')
                    print(f'(2)bin_spec: {bin_spec}')
                    if login_GUI.algorithm_Hist_custom in ['LogiNet2.0', 'LogiNet2.0(LSL~USL)']:
                        hist_data = hist_data.tolist()
                    elif login_GUI.algorithm_Hist_custom in ['Minitab(Simple)', 'Minitab(With Fit)']:
                        hist_data = [int(a) for a in hist_data]
                    print(f'(3)hist_data: {hist_data}')
                    count_total = sum(hist_data)
                    print(f'(4)count_total: {count_total}')
                    
                    # ------------ 顺便提前准备好供用户查询分组细节的数据
                    len_hist_data = len(hist_data)
                    bin_typical_count_percentage = []
                    for n, each_count in enumerate(hist_data, 0):
                        the_typical    = round(0.5*(bin_spec[n] + bin_spec[n+1]),5)                                               # 中心值保留5位小数
                        the_percentage = '0%' if count_total == 0 else '{:.2%}'.format(each_count/count_total).replace('.00','')  # 百分比保留2位小数,当2位小数是00时则只保留整数.
                        bin_typical_count_percentage.append([f'[{bin_spec[n]}, {bin_spec[n+1]}]' if n == 0 else f'({bin_spec[n]}, {bin_spec[n+1]}]',
                                                            str(the_typical),
                                                            str(each_count),
                                                            the_percentage])
                    self.all_bin_typical_count_percentage[os.path.splitext(tmp_var_csv)[0]] = bin_typical_count_percentage
                    print(f'(5)bin_typical_count_percentage: {bin_typical_count_percentage}\n')
                    
                    # ------------ 创建一个按钮, 供用户查询分组细节, 注意如下写法并不会覆盖已创建的按钮及其按钮事件
                    btn_query = wx.Button(self.scroller, label='>>', pos=(0,self.H_grid+5+500*(i-1)+470), size=(25,25), style=wx.NO_BORDER, name=os.path.splitext(tmp_var_csv)[0])
                    btn_query.SetCursor(wx.Cursor(wx.CURSOR_HAND))
                    btn_query.SetBackgroundColour(self.scroller_bgc)
                    btn_query.Bind(wx.EVT_BUTTON, self.btn_query_group_FCT)
                    
                    # ------------ 正式更新进度条
                    keepGoing = dlg_hist.Update(value=i, newmsg=f'Completed: {i}/{len(self.final_var_options)}')
                else:
                    dlg_hist.Destroy()
                    break
            else:
                dlg_hist.Destroy()
            # print('all_bin_typical_count_percentage:', self.all_bin_typical_count_percentage, end='\n\n')
            # print('all_histogram:', self.all_histogram, end='\n\n')
            
            # ------------ 创建一个导出图片的按钮
            position_Y   = self.H_grid+5+500*(len(self.final_var_options)-1)+470+30
            btn_export_1 = wx.Button(self.scroller, label='Export Images', pos=(2,position_Y), size=(140,35), style=0) # 0 或 wx.NO_BORDER
            btn_export_1.SetBackgroundColour('steel blue')
            btn_export_1.SetForegroundColour(self.btn_bgc)
            btn_export_1.SetCursor(wx.Cursor(wx.CURSOR_HAND))
            btn_export_1.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
            btn_export_1.SetToolTip(tipString=f'Save all histograms in\n{os.path.abspath(self.temp_folder)}')
            btn_export_1.Bind(wx.EVT_BUTTON, self.btn_export_images_FCT)
            
            # ------------ 创建一个导出 pdf 的按钮
            btn_export_2 = wx.Button(self.scroller, label='Export PDF', pos=(152,position_Y), size=(140,35), style=0) # 0 或 wx.NO_BORDER
            btn_export_2.SetBackgroundColour('steel blue')
            btn_export_2.SetForegroundColour(self.btn_bgc)
            btn_export_2.SetCursor(wx.Cursor(wx.CURSOR_HAND))
            btn_export_2.SetFont(font=wx.Font(pointSize=12, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
            btn_export_2.SetToolTip(tipString=f'Save pdf file in\n{script_abspath}')
            btn_export_2.Bind(wx.EVT_BUTTON, self.btn_export_pdf_FCT)
            
            # ------------ 创建控件专门用于设置直方图
            Algorithm         = wx.StaticText(self.scroller, label='Algorithm:',pos=(360,position_Y+3), size=(60,25))
            self.updated_algo = wx.ComboBox(self.scroller, value=login_GUI.algorithm_Hist_custom, pos=(425,position_Y), size=(150,25), choices=['LogiNet2.0', 'LogiNet2.0(LSL~USL)', 'Minitab(Simple)', 'Minitab(With Fit)'],style=wx.TE_READONLY)
            if login_GUI.algorithm_Hist_custom == 'LogiNet2.0':
                self.updated_algo.SetToolTip(tipString=f'LogiNet2.0:\n\nInterval={self.Interval_user},\n(1)data divided into {self.Interval_user} equal groups from min(LSL,Min) to max(USL,Max).\n(2)X axis ticks divided into {self.Interval_user} equal groups from limits [min(LSL,Min),max(USL,Max)].')
            elif login_GUI.algorithm_Hist_custom == 'LogiNet2.0(LSL~USL)':
                self.updated_algo.SetToolTip(tipString=f'LogiNet2.0(LSL~USL):\n\nInterval={self.Interval_user},\n(1)data divided into {self.Interval_user} equal groups from LSL to USL.\n(2)X axis ticks divided into {self.Interval_user} equal groups from limits [LSL,USL].')
            elif login_GUI.algorithm_Hist_custom == 'Minitab(Simple)':
                self.updated_algo.SetToolTip(tipString=f'Minitab(Simple):\n\nInterval={self.Interval_user},\n(1)data divided into {self.Interval_user} equal groups from Min to Max.\n(2)X axis ticks always divided into fixed 10 equal groups from limits [min(LSL,Min),max(USL,Max)].')
            elif login_GUI.algorithm_Hist_custom == 'Minitab(With Fit)':
                self.updated_algo.SetToolTip(tipString=f'Minitab(With Fit): forcely exclude defect data\n\nInterval={self.Interval_user},\n(1)data divided into {self.Interval_user} equal groups from Min to Max.\n(2)X axis ticks always divided into fixed 10 equal groups from limits [LSL,USL].')
            self.updated_algo.Bind(wx.EVT_TEXT, self.ComboBox_Algorithm_FCT)
            
            self.flag_Label = wx.CheckBox(self.scroller, label='Show Label in histogram', pos=(590,position_Y-25), size=(160,25))
            self.flag_Label.Bind(wx.EVT_CHECKBOX, self.CheckBox_flag_Label_FCT)
            self.flag_Label.SetValue(state=self.flag_Label_custom)
            if login_GUI.algorithm_Hist_custom in ['LogiNet2.0','LogiNet2.0(LSL~USL)']:
                self.flag_Label.Hide()
            elif login_GUI.algorithm_Hist_custom in ['Minitab(Simple)','Minitab(With Fit)']:
                self.flag_Label.Show()

            self.flag_Grid = wx.CheckBox(self.scroller, label='Show grid in histogram', pos=(590,position_Y), size=(155,25))
            self.flag_Grid.Bind(wx.EVT_CHECKBOX, self.CheckBox_flag_Grid_FCT)
            self.flag_Grid.SetValue(state=self.flag_Grid_custom)
                           
            Hist_W_H    = wx.StaticText(self.scroller, label='Hist W_H:', pos=(760,position_Y+3), size=(60,25))
            self.Hist_W = wx.SpinCtrl(self.scroller, value='',            pos=(825,position_Y), size=(50,25), style=wx.SP_ARROW_KEYS|wx.BORDER_STATIC, min=100, max=self.Hist_W_custom_max, initial=self.Hist_W_custom)
            self.Hist_W.SetToolTip(tipString=f'Support int ∈ [100,{self.Hist_W_custom_max}]')
            self.Hist_W.Bind(wx.EVT_SPINCTRL, self.SpinCtrl_Hist_W_FCT)
            self.Hist_H = wx.SpinCtrl(self.scroller, value='',            pos=(880,position_Y), size=(50,25), style=wx.SP_ARROW_KEYS|wx.BORDER_STATIC, min=100, max=self.Hist_H_custom_max, initial=self.Hist_H_custom)
            self.Hist_H.SetToolTip(tipString=f'Support int ∈ [100,{self.Hist_H_custom_max}]')
            self.Hist_H.Bind(wx.EVT_SPINCTRL, self.SpinCtrl_Hist_H_FCT)
            self.scroller.Refresh()
                        
            # ================================= 这里是右面板水平布局管理器的更新
            self.hbox_right.Insert(index=0, window=self.scroller, proportion=0, flag=wx.ALL|wx.EXPAND, border=0)
            self.hbox_right.Layout()
            self.rpanel.Refresh()
            
            self.Refresh()
    
    def ComboBox_Algorithm_FCT(self, evt):
        login_GUI.algorithm_Hist_custom = self.updated_algo.GetValue()
        self.check_box_1.SetValue(state=True)
        if login_GUI.algorithm_Hist_custom == 'LogiNet2.0':
            self.check_box_2.SetValue(state=True)
            self.check_box_2.Enable()
            self.flag_Label.Hide()
            self.updated_algo.SetToolTip(tipString=f'LogiNet2.0:\n\nInterval={self.Interval_user},\n(1)data divided into {self.Interval_user} equal groups from min(LSL,Min) to max(USL,Max).\n(2)X axis ticks divided into {self.Interval_user} equal groups from limits [min(LSL,Min),max(USL,Max)].')
        elif login_GUI.algorithm_Hist_custom == 'LogiNet2.0(LSL~USL)':
            self.check_box_2.SetValue(state=True)
            self.check_box_2.Enable()
            self.flag_Label.Hide()
            self.updated_algo.SetToolTip(tipString=f'LogiNet2.0(LSL~USL):\n\nInterval={self.Interval_user},\n(1)data divided into {self.Interval_user} equal groups from LSL to USL.\n(2)X axis ticks divided into {self.Interval_user} equal groups from limits [LSL,USL].')
        elif login_GUI.algorithm_Hist_custom == 'Minitab(Simple)':
            self.check_box_2.SetValue(state=True)
            self.check_box_2.Enable()
            self.flag_Label.Show()
            self.updated_algo.SetToolTip(tipString=f'Minitab(Simple):\n\nInterval={self.Interval_user},\n(1)data divided into {self.Interval_user} equal groups from Min to Max.\n(2)X axis ticks always divided into fixed 10 equal groups from limits [min(LSL,Min),max(USL,Max)].')
        elif login_GUI.algorithm_Hist_custom == 'Minitab(With Fit)':
            self.check_box_2.SetValue(state=False)
            self.check_box_2.Disable()
            self.flag_Label.Show()
            self.updated_algo.SetToolTip(tipString=f'Minitab(With Fit): forcely exclude defect data\n\nInterval={self.Interval_user},\n(1)data divided into {self.Interval_user} equal groups from Min to Max.\n(2)X axis ticks always divided into fixed 10 equal groups from limits [LSL,USL].')
    
    def SpinCtrl_Hist_W_FCT(self, evt):
        self.Hist_W_custom = self.Hist_W.GetValue()
        
    def SpinCtrl_Hist_H_FCT(self, evt):
        self.Hist_H_custom = self.Hist_H.GetValue()

    def CheckBox_flag_Grid_FCT(self, evt):
        self.flag_Grid_custom = self.flag_Grid.GetValue()
        
    def CheckBox_flag_Label_FCT(self, evt):
        self.flag_Label_custom = self.flag_Label.GetValue()
        
    def btn_dashboard_FCT(self, evt):
        
        if not os.path.isfile(self.dashboard_csv):
            wx.MessageBox(message=f'Find no {self.dashboard_csv}', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return
        
        # ==================================== 初始化上次的缓存数据
        if self.scroller:   # 判断滚动面板存在是为了防止上一次程序因中途崩溃没有生成滚动面板
            self.hbox_right.Detach(window=self.scroller)
        if self.scroller:
            self.scroller.Destroy()
            
        # ==================================== 创建 Dashboard 面板
        self.screen_W, self.screen_H = wx.DisplaySize()             # 确认最新屏幕的分辨率
        self.scroller = wx.ScrolledWindow(self.rpanel, pos=(0,0), size=(gui_W-self.left_panel_W-20, self.screen_H-70))
        self.scroller.SetScrollbars(pixelsPerUnitX=1, pixelsPerUnitY=1, noUnitsX=gui_W-self.left_panel_W-20-17, noUnitsY=1020)
        self.scroller.SetScrollRate(xstep=0, ystep=10)
        self.scroller.SetBackgroundColour('tan')    # self.rpanel_bgc
        
        # ======================== staticBox_01 for [Yield rate]
        staticBox_01 = wx.StaticBox(self.scroller, label='Yield rate', pos=(10,5), size=(730,200))
        staticBox_01.SetFont(font=wx.Font(pointSize=14, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        
        # 创建 Dashboard
        self.speed = SM.SpeedMeter(parent=staticBox_01, id=-1, pos=(10,25), size=(320,320), 
                            agwStyle=SM.SM_DRAW_PARTIAL_FILLER|SM.SM_DRAW_HAND|SM.SM_DRAW_MIDDLE_TEXT|SM.SM_DRAW_SECONDARY_TICKS,
                            bufferedstyle=SM.SM_BUFFERED_DC,
                            mousestyle=0)
        self.speed.SetSpeedBackground('white')  # self.rpanel_bgc
        self.speed.SetFillerColour(colour=wx.GREEN)
        self.speed.SetHandColour(wx.BLUE)
        
        intervals = range(0, 101, 20)
        self.speed.SetIntervals(intervals=intervals)
        colours = [wx.BLACK]*5
        self.speed.SetIntervalColours(colours=colours)       # 需要 style=SM.SM_DRAW_SECTORS 并且没有 SM.SM_DRAW_GRADIENT

        ticks = [str(interval) for interval in intervals]
        self.speed.SetTicks(ticks=ticks)
        self.speed.SetTicksColour('gray')
        self.speed.SetNumberOfSecondaryTicks(ticknum=9)
        self.speed.SetTicksFont(font=wx.Font(12, wx.FONTFAMILY_SWISS, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL))
        self.speed.DrawExternalArc(draw=False)               # 默认是 True,指定是否希望绘制外部(较粗的)弧线。
        self.speed.SetArcColour(colour=wx.BLUE)              # 需要 DrawExternalArc(draw=True)
        
        self.speed.SetMiddleText('95%')
        self.speed.SetMiddleTextFont(font=wx.Font(24, wx.FONTFAMILY_SWISS, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD, faceName='Microsoft JhengHei UI'))
        self.speed.SetMiddleTextColour(colour=wx.BLUE)
        self.speed.SetSpeedValue(95)
        
        # 绘制表格 table_1 (注意: 这里只建立表格, 然后通过 [Apply] 按钮事件来刷新数据)
        self.table_1 = wx.ListCtrl(staticBox_01, -1, (350,25), (220,150), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
        self.table_1.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
        self.table_1.SetFont(font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        self.table_1.Bind(wx.EVT_LIST_ITEM_ACTIVATED,   self.LIST_ITEM_ACTIVATED_Yield_dashboard)
        self.table_1.Bind(wx.EVT_LIST_ITEM_RIGHT_CLICK, self.LIST_ITEM_RIGHT_CLICK_Fail_dashboard)
        fieldnames_1 = ['Result', 'Count']
        for n, fieldname in enumerate(fieldnames_1, 0):
            self.table_1.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=100) # Step-1: 必须先插入列
        self.table_1.SetColumnWidth(col=0, width=120)   # 修改指定的一列的宽度
        data_table_1 = [['Total:', ''],['Pass:', ''],['Fail:', ''], ['Yield rate:', '']]
        for n, row_data_list in enumerate(data_table_1, 0):
            index_row = self.table_1.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
            for m in range(1, len(fieldnames_1), 1):
                self.table_1.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
        
        # 创建 可选按钮 (注意: self.cb_1_1 和 self.cb_1_2 要利用绑定的函数来实现互斥操作)
        self.cb_1_1 = wx.CheckBox(staticBox_01, label='Unique UID', pos=(590,25))
        self.cb_1_2 = wx.CheckBox(staticBox_01, label='FPY', pos=(590,55))
        self.cb_1_1.SetValue(state=True)
        self.cb_1_1.Bind(wx.EVT_CHECKBOX, self.cb_1_1_FCT)
        self.cb_1_2.Bind(wx.EVT_CHECKBOX, self.cb_1_2_FCT)
        
        # 创建 Apply_1 按钮
        btn_Apply_1 = wx.Button(staticBox_01, label='Apply', pos=(590,135), size=(120,40), style=wx.NO_BORDER) # 0 或 wx.NO_BORDER
        btn_Apply_1.SetBackgroundColour('steel blue')
        btn_Apply_1.SetForegroundColour(self.btn_bgc)
        btn_Apply_1.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        btn_Apply_1.SetFont(font=wx.Font(pointSize=14, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        btn_Apply_1.Bind(wx.EVT_BUTTON, self.btn_Apply_1_FCT)
        
        # ======================== staticBox_02 for [Top 5 reason]
        staticBox_02 = wx.StaticBox(self.scroller, label='Top 5 reason', pos=(10,245), size=(730,225))
        staticBox_02.SetFont(font=wx.Font(pointSize=14, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        
        # 创建 Top_5_reason 呈现表 (注意: 这里只建立表格, 然后通过按钮事件来刷新数据)
        self.Top5Reason_table = wx.ListCtrl(staticBox_02, -1, (10,30), (560,180), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
        self.Top5Reason_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
        self.Top5Reason_table.SetFont(font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        fieldnames_reason = ['reason', 'Count']
        for n, fieldname in enumerate(fieldnames_reason, 0):
            self.Top5Reason_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=100) # Step-1: 必须先插入列
        self.Top5Reason_table.SetColumnWidth(col=0, width=460)   # 修改指定的一列的宽度
        data_table_reason = [['', ''],['', ''],['', ''], ['', ''], ['', '']]
        for n, row_data_list in enumerate(data_table_reason, 0):
            index_row = self.Top5Reason_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
            for m in range(1, len(fieldnames_reason), 1):
                self.Top5Reason_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
        
        # 创建 可选按钮
        self.cb_2 = wx.CheckBox(staticBox_02, label='Unique UID', pos=(590,25))
        self.cb_2.Bind(wx.EVT_CHECKBOX, self.btn_Apply_2_FCT)
        self.cb_2.SetValue(state=True)
               
        # ======================== staticBox_03 for [Top 5 error code]
        staticBox_03 = wx.StaticBox(self.scroller, label='Top 5 error code', pos=(10,510), size=(730,225))
        staticBox_03.SetFont(font=wx.Font(pointSize=14, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        
        # 创建 Top_5_error_code 呈现表 (注意: 这里只建立表格, 然后通过按钮事件来刷新数据)
        self.Top5ErrorCode_table = wx.ListCtrl(staticBox_03, -1, (10,30), (560,180), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
        self.Top5ErrorCode_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
        self.Top5ErrorCode_table.SetFont(font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        fieldnames_errorcode = ['error code', 'Count']
        for n, fieldname in enumerate(fieldnames_errorcode, 0):
            self.Top5ErrorCode_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=100) # Step-1: 必须先插入列
        self.Top5ErrorCode_table.SetColumnWidth(col=0, width=460)   # 修改指定的一列的宽度
        data_table_errorcode = [['', ''],['', ''],['', ''], ['', ''], ['', '']]
        for n, row_data_list in enumerate(data_table_errorcode, 0):
            index_row = self.Top5ErrorCode_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
            for m in range(1, len(fieldnames_errorcode), 1):
                self.Top5ErrorCode_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
        
        # 创建 可选按钮
        self.cb_3 = wx.CheckBox(staticBox_03, label='Unique UID', pos=(590,25))
        self.cb_3.Bind(wx.EVT_CHECKBOX, self.btn_Apply_3_FCT)
        self.cb_3.SetValue(state=True)
        
        # ======================== staticBox_04 for [Top 5 error line]
        staticBox_04 = wx.StaticBox(self.scroller, label='Top 5 error line', pos=(10,775), size=(730,225))
        staticBox_04.SetFont(font=wx.Font(pointSize=14, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        
        # 创建 Top_5_error_line 呈现表 (注意: 这里只建立表格, 然后通过按钮事件来刷新数据)
        self.Top5ErrorLine_table = wx.ListCtrl(staticBox_04, -1, (10,30), (560,180), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
        self.Top5ErrorLine_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
        self.Top5ErrorLine_table.SetFont(font=wx.Font(pointSize=15, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        fieldnames_errorline = ['error line', 'Count']
        for n, fieldname in enumerate(fieldnames_errorline, 0):
            self.Top5ErrorLine_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=100) # Step-1: 必须先插入列
        self.Top5ErrorLine_table.SetColumnWidth(col=0, width=460)   # 修改指定的一列的宽度
        data_table_errorcode = [['', ''],['', ''],['', ''], ['', ''], ['', '']]
        for n, row_data_list in enumerate(data_table_errorcode, 0):
            index_row = self.Top5ErrorLine_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
            for m in range(1, len(fieldnames_errorline), 1):
                self.Top5ErrorLine_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
        
        # 创建 可选按钮
        self.cb_4 = wx.CheckBox(staticBox_04, label='Unique UID', pos=(590,25))
        self.cb_4.Bind(wx.EVT_CHECKBOX, self.btn_Apply_4_FCT)
        self.cb_4.SetValue(state=True)
        
        # 刷新 Dashboard
        self.btn_Apply_1_FCT('')
        self.btn_Apply_2_FCT('')
        self.btn_Apply_3_FCT('')
        self.btn_Apply_4_FCT('')
        
        # ================================= 这里是右面板水平布局管理器的更新
        self.hbox_right.Insert(index=0, window=self.scroller, proportion=0, flag=wx.ALL|wx.EXPAND, border=0)
        self.hbox_right.Layout()
        self.rpanel.Refresh()
        
        self.Refresh()
        
    def LIST_ITEM_ACTIVATED_Yield_dashboard(self, evt):
        index_focus = self.table_1.GetFocusedItem()
        if index_focus == 0:
            ret = self.btn_Apply_1_FCT('')
            itemText = self.table_1.GetItemText(item=index_focus, col=1)
            print(f'Valid index:{index_focus}, Valid itemText:{itemText}')
            if not int(itemText) > 0:
                return
                
            ret_flag       = ret[0]  # True
            self.ret_value = ret[1]  # [['4383F89D6CDAAE02', 'F', 'I_MCU_2G402', '185', 'E-ECDE7', '-0.0858965', '13:44:34', '1684734274', 2023-05-22 13:44:34', '*.csv'],...]
            if not all([ret_flag, self.ret_value]):
                return
                
            if int(itemText) != len(self.ret_value):
                wx.MessageBox(message=f'算法错误:算法1(Total {int(itemText)}) ≠ 算法2(Total {len(self.ret_value)})\n\n请联系程序开发者: Bright Zuo', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return
                
            visible_row_max = 30
            the_Height = int(30+21*int(itemText))+20 if int(itemText) <= visible_row_max else 30+21*visible_row_max+20
            self.miniFrame_total_dashboard = wx.MiniFrame(parent=self.scroller, title='Total Data Detail (Dashboard)', size=(1300+20+15, the_Height+25+10), style=wx.CAPTION|wx.CLOSE_BOX|wx.RESIZE_BORDER)  #|wx.STAY_ON_TOP
            self.miniFrame_total_dashboard.SetBackgroundColour((240,240,240))
            
            # 绘制[所有数据细节]的表格
            Total_Detail_table = wx.ListCtrl(self.miniFrame_total_dashboard, -1, (0,0),(1300+20, the_Height), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            Total_Detail_table.SetHeaderAttr(attr=wx.ItemAttr(colText='Blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            Total_Detail_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            Total_Detail_table.SetBackgroundColour((240,240,240))
            Total_Detail_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            Total_fieldnames = [login_GUI.Index_var_custom, 'Status', 'Comment', 'ErrorLine', 'ErrorCode', 'FailValue', 'Test_Start_Time', 'UnixTime', 'BeijingTime', 'OriginalCSV']
            Total_fieldnames.insert(0, 'No.')
            Total_data = []
            for i, each_row in enumerate(self.ret_value,1):
                each_row.insert(0,str(i))
                Total_data.append(each_row)
                
            # 首先插入表格眉头
            for n, fieldname in enumerate(Total_fieldnames, 0):
                Total_Detail_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=80) # Step-1: 必须先插入列
            Total_Detail_table.SetColumnWidth(col=0,  width=50)     # 'No.', 修改指定的一列的宽度
            Total_Detail_table.SetColumnWidth(col=1,  width=160)    # 'UID', 修改指定的一列的宽度
            Total_Detail_table.SetColumnWidth(col=2,  width=55)     # 'Status'
            Total_Detail_table.SetColumnWidth(col=7,  width=115)    # 'Test_Start_Time'
            Total_Detail_table.SetColumnWidth(col=8,  width=100)    # 'UnixTime'
            Total_Detail_table.SetColumnWidth(col=9,  width=150)    # 'BeijingTime'
            Total_Detail_table.SetColumnWidth(col=10, width=350)    # 'OriginalCSV'
            
            # 然后插入下面的每一行
            for n, row_data_list in enumerate(Total_data, 0):
                index_row = Total_Detail_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                if row_data_list[2] == 'F':
                    Total_Detail_table.SetItemTextColour(item=n, col='red')
                for m in range(1, len(Total_fieldnames), 1):
                    Total_Detail_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
            
            self.miniFrame_total_dashboard.Centre()
            self.miniFrame_total_dashboard.Show()
            self.miniFrame_total_dashboard.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
            
        elif index_focus == 1:
            ret = self.btn_Apply_1_FCT('')
            itemText = self.table_1.GetItemText(item=index_focus, col=1)
            print(f'Valid index:{index_focus}, Valid itemText:{itemText}')
            if not int(itemText) > 0:
                return
                
            ret_flag       = ret[0]  # True
            self.ret_value = ret[2]  # [['4383F89D6CD92C01', 'P', '', '', '', '', '14:44:52', '1684737892', 2023-05-22 14:44:52', '*.csv'],...]
            if not all([ret_flag, self.ret_value]):
                return
                
            if int(itemText) != len(self.ret_value):
                wx.MessageBox(message=f'算法错误:算法1(Pass {int(itemText)}) ≠ 算法2(Pass {len(self.ret_value)})\n\n请联系程序开发者: Bright Zuo', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return
                
            visible_row_max = 30
            the_Height = int(30+21*int(itemText))+20 if int(itemText) <= visible_row_max else 30+21*visible_row_max+20
            self.miniFrame_total_dashboard = wx.MiniFrame(parent=self.scroller, title='Pass Data Detail (Dashboard)', size=(1300+20+15, the_Height+25+10), style=wx.CAPTION|wx.CLOSE_BOX|wx.RESIZE_BORDER)  #|wx.STAY_ON_TOP
            self.miniFrame_total_dashboard.SetBackgroundColour((240,240,240))
            
            # 绘制[所有数据细节]的表格
            Pass_Detail_table = wx.ListCtrl(self.miniFrame_total_dashboard, -1, (0,0),(1300+20, the_Height), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            Pass_Detail_table.SetHeaderAttr(attr=wx.ItemAttr(colText='Blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            Pass_Detail_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            Pass_Detail_table.SetBackgroundColour((240,240,240))
            Pass_Detail_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            Total_fieldnames = [login_GUI.Index_var_custom, 'Status', 'Comment', 'ErrorLine', 'ErrorCode', 'FailValue', 'Test_Start_Time', 'UnixTime', 'BeijingTime', 'OriginalCSV']
            Total_fieldnames.insert(0, 'No.')
            Total_data = []
            for i, each_row in enumerate(self.ret_value,1):
                each_row.insert(0,str(i))
                Total_data.append(each_row)
                
            # 首先插入表格眉头
            for n, fieldname in enumerate(Total_fieldnames, 0):
                Pass_Detail_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=80) # Step-1: 必须先插入列
            Pass_Detail_table.SetColumnWidth(col=0,  width=50)      # 'No.', 修改指定的一列的宽度
            Pass_Detail_table.SetColumnWidth(col=1,  width=160)     # 'UID', 修改指定的一列的宽度
            Pass_Detail_table.SetColumnWidth(col=2,  width=55)      # 'Status'
            Pass_Detail_table.SetColumnWidth(col=7,  width=115)     # 'Test_Start_Time'
            Pass_Detail_table.SetColumnWidth(col=8,  width=100)     # 'UnixTime'
            Pass_Detail_table.SetColumnWidth(col=9,  width=150)     # 'BeijingTime'
            Pass_Detail_table.SetColumnWidth(col=10, width=350)     # 'OriginalCSV'
            
            # 然后插入下面的每一行
            for n, row_data_list in enumerate(Total_data, 0):
                index_row = Pass_Detail_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                for m in range(1, len(Total_fieldnames), 1):
                    Pass_Detail_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
            
            self.miniFrame_total_dashboard.Centre()
            self.miniFrame_total_dashboard.Show()
            self.miniFrame_total_dashboard.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
            
        elif index_focus == 2:
            ret = self.btn_Apply_1_FCT('')
            itemText = self.table_1.GetItemText(item=index_focus, col=1)
            print(f'Valid index:{index_focus}, Valid itemText:{itemText}')
            if not int(itemText) > 0:
                return
                
            ret_flag       = ret[0]  # True
            self.ret_value = ret[3]  # [['4383F89D6CF0AC30', 'F', 'I_DeadMode', '290', 'E-2927B', '216.685', '17:04:25', '1684746265', '2023-05-22 17:04:25', '*.csv'],...]
            
            if not all([ret_flag, self.ret_value]):
                return
                
            if int(itemText) != len(self.ret_value):
                wx.MessageBox(message=f'算法错误:算法1(Fail {int(itemText)}) ≠ 算法2(Fail {len(self.ret_value)})\n\n请联系程序开发者: Bright Zuo', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return
                
            visible_row_max = 30
            the_Height = int(30+21*int(itemText))+20 if int(itemText) <= visible_row_max else 30+21*visible_row_max+20
            self.miniFrame_fail_dashboard = wx.MiniFrame(parent=self.scroller, title='Fail Data Detail (Dashboard)', size=(1300+20+15, the_Height+25+10), style=wx.CAPTION|wx.CLOSE_BOX|wx.RESIZE_BORDER)  #|wx.STAY_ON_TOP
            self.miniFrame_fail_dashboard.SetBackgroundColour((240,240,240))
            
            # 绘制[失效数据细节]的表格
            Fail_Detail_table = wx.ListCtrl(self.miniFrame_fail_dashboard, -1, (0,0),(1300+20, the_Height), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            Fail_Detail_table.SetHeaderAttr(attr=wx.ItemAttr(colText='Blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            Fail_Detail_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            Fail_Detail_table.SetBackgroundColour((240,240,240))
            Fail_Detail_table.SetForegroundColour((255,0,0))
            Fail_Detail_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            Fail_fieldnames = [login_GUI.Index_var_custom, 'Status', 'Comment', 'ErrorLine', 'ErrorCode', 'FailValue', 'Test_Start_Time', 'UnixTime', 'BeijingTime', 'OriginalCSV']
            Fail_fieldnames.insert(0, 'No.')
            Fail_data = []
            for i, each_row in enumerate(self.ret_value,1):
                each_row.insert(0,str(i))
                Fail_data.append(each_row)
                
            # 首先插入表格眉头
            for n, fieldname in enumerate(Fail_fieldnames, 0):
                Fail_Detail_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=80) # Step-1: 必须先插入列
            Fail_Detail_table.SetColumnWidth(col=0,  width=50)      # 'No.', 修改指定的一列的宽度
            Fail_Detail_table.SetColumnWidth(col=1,  width=160)     # 'UID', 修改指定的一列的宽度
            Fail_Detail_table.SetColumnWidth(col=2,  width=55)      # 'Status'
            Fail_Detail_table.SetColumnWidth(col=7,  width=115)     # 'Test_Start_Time'
            Fail_Detail_table.SetColumnWidth(col=8,  width=100)     # 'UnixTime'
            Fail_Detail_table.SetColumnWidth(col=9,  width=150)     # 'BeijingTime'
            Fail_Detail_table.SetColumnWidth(col=10, width=350)     # 'OriginalCSV'
            
            # 然后插入下面的每一行
            for n, row_data_list in enumerate(Fail_data, 0):
                index_row = Fail_Detail_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                for m in range(1, len(Fail_fieldnames), 1):
                    Fail_Detail_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
            
            self.miniFrame_fail_dashboard.Centre()
            self.miniFrame_fail_dashboard.Show()
            self.miniFrame_fail_dashboard.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
            
    def LIST_ITEM_RIGHT_CLICK_Fail_dashboard(self, evt):
        index_focus = self.table_1.GetFocusedItem()
        if index_focus == 2:
            ret = self.btn_Apply_1_FCT('')
            itemText = self.table_1.GetItemText(item=index_focus, col=1)
            print(f'Valid index:{index_focus}, Valid itemText:{itemText}')
            if not int(itemText) > 0:
                return
                
            ret_flag       = ret[0]  # True
            self.ret_value = ret[3]  # [['4383F89D6CF0AC30', 'F', 'I_DeadMode', '290', 'E-2927B', '216.685', '17:04:25', '1684746265', '2023-05-22 17:04:25'],...]
            if not all([ret_flag, self.ret_value]):
                return
                
            if int(itemText) != len(self.ret_value):
                wx.MessageBox(message=f'算法错误:算法1(Fail {int(itemText)}) ≠ 算法2(Fail {len(self.ret_value)})\n\n请联系程序开发者: Bright Zuo', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return
            
            all_reason  = [i[2] for i in self.ret_value]    
            reason_list = list(set(all_reason))
            # if '' in reason_list:reason_list.remove('')
            reason_qty  = {}
            for each_reason in reason_list:
                reason_qty[each_reason] = all_reason.count(each_reason)
            # key 使用lambda匿名函数取value进行从大到小排序
            final_reason_qty = sorted(reason_qty.items(), key=lambda x:x[1], reverse=True)  # 字典变成了列表, [('AA', 4), ('BB', 2), ('CC', 1)...]
            
            visible_row_max = 30
            the_Height = int(30+21*len(final_reason_qty))+20 if len(final_reason_qty) <= visible_row_max else 30+21*visible_row_max+20
            self.miniFrame_fail_dashboard = wx.MiniFrame(parent=self.scroller, title='Fail Data Category (Dashboard)', size=(300+20+15, the_Height+25+10), style=wx.CAPTION|wx.CLOSE_BOX|wx.RESIZE_BORDER)  #|wx.STAY_ON_TOP
            self.miniFrame_fail_dashboard.SetBackgroundColour((240,240,240))
            
            # 绘制[失效数据类型]的表格
            self.Fail_Category_table = wx.ListCtrl(self.miniFrame_fail_dashboard, -1, (0,0),(300+20, the_Height), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            self.Fail_Category_table.SetHeaderAttr(attr=wx.ItemAttr(colText='red', colBack='blue', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            self.Fail_Category_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            self.Fail_Category_table.SetBackgroundColour((240,240,240))
            self.Fail_Category_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_onefailitem_dashboard)
            Fail_fieldnames = ['Comment(Reason)', 'Count']
                
            # 首先插入表格眉头
            for n, fieldname in enumerate(Fail_fieldnames, 0):
                self.Fail_Category_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=50) # Step-1: 必须先插入列
            self.Fail_Category_table.SetColumnWidth(col=0, width=250)  # 修改指定的一列的宽度
            
            # 然后插入下面的每一行
            for n, row_data_list in enumerate(final_reason_qty, 0):
                index_row = self.Fail_Category_table.InsertItem(index=n, label=row_data_list[0])             # Step-2: 再插入行,顺便设置了此行第一列的值
                for m in range(1, len(Fail_fieldnames), 1):
                    self.Fail_Category_table.SetItem(index=index_row, column=m, label=str(row_data_list[m])) # Step-3: 再设置插入行的(除了第一列)其余列的值
            
            self.miniFrame_fail_dashboard.Centre()
            self.miniFrame_fail_dashboard.Show()
            self.miniFrame_fail_dashboard.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
    
    def LIST_ITEM_ACTIVATED_onefailitem_dashboard(self, evt):
        index_focus = self.Fail_Category_table.GetFocusedItem()
        fail_item   = self.Fail_Category_table.GetItemText(item=index_focus, col=0)
        itemText    = self.Fail_Category_table.GetItemText(item=index_focus, col=1)
        
        # 实际上, 此时界面上一定存在 self.miniFrame_fail_dashboard
        if self.miniFrame_fail_dashboard:
            self.miniFrame_fail_dashboard.Destroy()

        visible_row_max = 30
        the_Height = int(30+21*int(itemText))+20 if int(itemText) <= visible_row_max else 30+21*visible_row_max+20
        self.miniFrame_fail_dashboard = wx.MiniFrame(parent=self.scroller, title=f'"{fail_item}", failed {itemText} pcs', size=(1300+20+15, the_Height+25+10), style=wx.CAPTION|wx.CLOSE_BOX|wx.RESIZE_BORDER)  #|wx.STAY_ON_TOP
        self.miniFrame_fail_dashboard.SetBackgroundColour((240,240,240))
        
        # 绘制[某一指定fail测项的统计]的表格
        Fail_Item_table = wx.ListCtrl(self.miniFrame_fail_dashboard, -1, (0,0),(1300+20, the_Height), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
        Fail_Item_table.SetHeaderAttr(attr=wx.ItemAttr(colText='red', colBack='blue', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
        Fail_Item_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        Fail_Item_table.SetBackgroundColour((240,240,240))
        Fail_Item_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
        Fail_fieldnames = [login_GUI.Index_var_custom, 'Status', 'Comment', 'ErrorLine', 'ErrorCode', 'FailValue', 'Test_Start_Time', 'UnixTime', 'BeijingTime', 'OriginalCSV']
        Fail_fieldnames.insert(0, 'No.')
        Fail_data = []
        x = 0
        for each_row in self.ret_value:
            if each_row[2] == fail_item: 
                x +=1
                each_row.insert(0,str(x))
                Fail_data.append(each_row)
            
        # 首先插入表格眉头
        for n, fieldname in enumerate(Fail_fieldnames, 0):
            Fail_Item_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=80) # Step-1: 必须先插入列
        Fail_Item_table.SetColumnWidth(col=0,  width=50)  # 修改指定的一列的宽度
        Fail_Item_table.SetColumnWidth(col=1,  width=160) # 修改指定的一列的宽度
        Fail_Item_table.SetColumnWidth(col=2,  width=55)  # 修改指定的一列的宽度
        Fail_Item_table.SetColumnWidth(col=3,  width=180)
        Fail_Item_table.SetColumnWidth(col=7,  width=115)
        Fail_Item_table.SetColumnWidth(col=8,  width=100)
        Fail_Item_table.SetColumnWidth(col=9,  width=150)
        Fail_Item_table.SetColumnWidth(col=10, width=450)
        
        # 然后插入下面的每一行
        for n, row_data_list in enumerate(Fail_data, 0):
            index_row = Fail_Item_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
            for m in range(1, len(Fail_fieldnames), 1):
                Fail_Item_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
        
        self.miniFrame_fail_dashboard.Centre()
        self.miniFrame_fail_dashboard.Show()
        self.miniFrame_fail_dashboard.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
        
    def OnCellLeftDClick(self, evt):
        row_clicked  = evt.GetRow()
        col_clicked  = evt.GetCol()
        the_object   = evt.GetEventObject()
        the_colLabel = the_object.GetColLabelValue(col=col_clicked)
        itemText_1   = the_object.GetRowLabelValue(row=row_clicked)
        itemText_2   = the_object.GetCellValue(coords=(evt.GetRow(),0))
        itemText_3   = the_object.GetCellValue(coords=(row_clicked,col_clicked))
        print(f'左双击单元格: ({row_clicked},{col_clicked}), {itemText_3}')
        print(f'相应的变量为: {itemText_1}.{itemText_2}\n')

        # ======================== (1)左双击的是[Count]列
        if the_colLabel == 'Count':
            if itemText_3 in ['0', 'Empty',]:
                return
            
            #if self.miniFrame_PolyLine:
            #    self.miniFrame_PolyLine.Destroy()
                
            self.miniFrame_PolyLine = wx.MiniFrame(parent=self.scroller, title=f'{itemText_1}.{itemText_2} (Trend Chart)', size=(1000+400+20+10, 320+20+320+25+10), style=wx.CAPTION|wx.CLOSE_BOX)  #|wx.STAY_ON_TOP
            self.miniFrame_PolyLine.SetBackgroundColour((240,240,240))
            
            # 读取对应的 csv file
            chart_var_file = os.path.join(gui.Charts_data_folder, f'{itemText_1}.{itemText_2}.csv')
            if not os.path.isfile(chart_var_file):
                wx.MessageBox(message=f'Find no {chart_var_file}', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return
            
            points_LOG  = []
            n_UID_Value = []
            with open(file=chart_var_file, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for n, row in enumerate(rows, 1):
                    points_LOG.append([n, row[itemText_2]])
                    n_UID_Value.append([str(n), row[login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID'], row[itemText_2]])
                LSL_str, USL_str = row['LSL'], row['USL']
                LSL,     USL     = float(row['LSL']), float(row['USL'])
                
            # 画折线图(Trend Chart)
            horizon_L = []
            horizon_U = []
            for i in range(1, len(points_LOG)+1, 1): # range(start, stop[, step])
                horizon_L.append([i, LSL])
                horizon_U.append([i, USL])
                
            line_LSL = wxPyPlot.PolyLine(points=horizon_L, colour='red', width=1, style=wx.PENSTYLE_LONG_DASH, legend='LSL')
            line_USL = wxPyPlot.PolyLine(points=horizon_U, colour='red', width=1, style=wx.PENSTYLE_LONG_DASH, legend='USL')
            line_LOG = wxPyPlot.PolyLine(points=points_LOG, colour='blue', width=2, style=wx.PENSTYLE_SOLID, legend=itemText_2)
            line_objects_list = [line_LSL, line_USL, line_LOG]
            Result_graphics = wxPyPlot.PlotGraphics(objects=line_objects_list,title=f'{itemText_2} (Trend Chart Based on Time Ascending)',xLabel='',yLabel=f'[{LSL_str}, {USL_str}]')
            Trend_chart_pc  = wxPyPlot.PlotCanvas(self.miniFrame_PolyLine, pos=(0,0), size=(1000,320)) # 此处导入绘图画布
            Trend_chart_pc.Draw(graphics=Result_graphics, xAxis=(0,50) if len(points_LOG) <= 50 else (0,len(points_LOG)), yAxis=(LSL-(USL-LSL)/20, USL+(USL-LSL)/20))
            Trend_chart_pc.SetBackgroundColour((240,240,240))
            Trend_chart_pc.xSpec              = 50                         # 水平X轴,将用户定义的the_xAxis范围内数值分割50组
            Trend_chart_pc.ySpec              = 10                         # 竖直Y轴,将用户定义的the_yAxis范围内数值分割10组
            Trend_chart_pc.fontSizeLegend     = 10                         # 默认是7, 图例字体的大小
            Trend_chart_pc.showScrollbars     = True                       # 默认是False, 滚动条. Me: 发现这个必须设置True, 否则图不能自动适应展开!!!
            Trend_chart_pc.enableAntiAliasing = True                       # 默认是False, 抗锯齿
            Trend_chart_pc.enableLegend       = False                      # 默认是False
            Trend_chart_pc.enableTicks        = (True,True,False, False)   # 默认(bottom, left, top, right)=(False,False,False,False)
            # Trend_chart_pc.enableCenterLines = 'Horizontal'              # 默认是False(两个方向中心线的有无一起设置相同), 'Horizontal'(只有水平中心线), 'Vertical'(只有竖直中心线)
            
            # 从小到大
            ascending_points_LOG = sorted(points_LOG, key=lambda x:float(x[1]), reverse=False)
            final_points_LOG     = []
            for n, (i,j) in enumerate(ascending_points_LOG,1):
                final_points_LOG.append([n, j])
            line_LOG = wxPyPlot.PolyLine(points=final_points_LOG, colour='blue', width=2, style=wx.PENSTYLE_SOLID, legend=itemText_2)
            line_objects_list = [line_LSL, line_USL, line_LOG]
            Result_graphics = wxPyPlot.PlotGraphics(objects=line_objects_list,title=f'{itemText_2} (Trend Chart Based on Value Ascending)',xLabel='',yLabel=f'[{LSL_str}, {USL_str}]')
            Trend_chart_pc  = wxPyPlot.PlotCanvas(self.miniFrame_PolyLine, pos=(0,340), size=(1000,320)) # 此处导入绘图画布
            Trend_chart_pc.Draw(graphics=Result_graphics, xAxis=(0,30), yAxis=(LSL-(USL-LSL)/20, USL+(USL-LSL)/20))
            Trend_chart_pc.SetBackgroundColour((240,240,240))
            Trend_chart_pc.xSpec              = 30                         # 水平X轴,将用户定义的the_xAxis范围内数值分割30组
            Trend_chart_pc.ySpec              = 10                         # 竖直Y轴,将用户定义的the_yAxis范围内数值分割10组
            Trend_chart_pc.fontSizeLegend     = 10                         # 默认是7, 图例字体的大小
            Trend_chart_pc.showScrollbars     = True                       # 默认是False, 滚动条. Me: 发现这个必须设置True, 否则图不能自动适应展开!!!
            Trend_chart_pc.enableAntiAliasing = True                       # 默认是False, 抗锯齿
            Trend_chart_pc.enableLegend       = False                      # 默认是False
            Trend_chart_pc.enableTicks        = (True,True,False, False)   # 默认(bottom, left, top, right)=(False,False,False,False)
            # Trend_chart_pc.enableCenterLines = 'Horizontal'              # 默认是False(两个方向中心线的有无一起设置相同), 'Horizontal'(只有水平中心线), 'Vertical'(只有竖直中心线)
            
                        
            # ------------ 创建一个表格, 显示折线图的细节数据
            var_name = wx.StaticText(self.miniFrame_PolyLine, -1, label=itemText_2, pos=(1000,0), size=(400+20,20), style=wx.ALIGN_CENTER)
            DD_table = wx.ListCtrl(self.miniFrame_PolyLine, -1, (1000,20),(400+20,280), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            DD_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            DD_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            DD_table.SetBackgroundColour((240,240,240))
            DD_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            DD_fieldnames = ['X_axis', login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID', 'Value']
                   
            for n, fieldname in enumerate(DD_fieldnames, 0):
                DD_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=150) # Step-1: 必须先插入列
            DD_table.SetColumnWidth(col=0, width=55)    # 修改指定的一列的宽度
            DD_table.SetColumnWidth(col=1, width=195)   # 修改指定的一列的宽度
            
            for n, row_data_list in enumerate(n_UID_Value, 0):
                index_row = DD_table.InsertItem(index=n, label=row_data_list[0])        # Step-2: 再插入行,顺便设置了此行第一列的值
                if float(row_data_list[2]) < LSL or float(row_data_list[2]) > USL:
                    DD_table.SetItemTextColour(item=n, col='red')
                for m in range(1, len(DD_fieldnames), 1):
                    DD_table.SetItem(index=index_row, column=m, label=row_data_list[m]) # Step-3: 再设置插入行的(除了第一列)其余列的值
            
            # 从小到大
            var_name = wx.StaticText(self.miniFrame_PolyLine, -1, label=itemText_2, pos=(1000,340), size=(400+20,20), style=wx.ALIGN_CENTER)
            DD_table = wx.ListCtrl(self.miniFrame_PolyLine, -1, (1000,360),(400+20,280), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            DD_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            DD_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            DD_table.SetBackgroundColour((240,240,240))
            DD_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            DD_fieldnames = ['X_axis', login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID', 'Value']
                   
            for n, fieldname in enumerate(DD_fieldnames, 0):
                DD_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=150) # Step-1: 必须先插入列
            DD_table.SetColumnWidth(col=0, width=55)    # 修改指定的一列的宽度
            DD_table.SetColumnWidth(col=1, width=195)   # 修改指定的一列的宽度
            
            ascending_n_UID_Value = sorted(n_UID_Value, key=lambda x:float(x[2]), reverse=False)
            final_n_UID_Value     = []
            for n, (i,j,k) in enumerate(ascending_n_UID_Value,1):
                final_n_UID_Value.append([str(n), j, k])
            for n, row_data_list in enumerate(final_n_UID_Value, 0):
                index_row = DD_table.InsertItem(index=n, label=row_data_list[0])        # Step-2: 再插入行,顺便设置了此行第一列的值
                if float(row_data_list[2]) < LSL or float(row_data_list[2]) > USL:
                    DD_table.SetItemTextColour(item=n, col='red')
                for m in range(1, len(DD_fieldnames), 1):
                    DD_table.SetItem(index=index_row, column=m, label=row_data_list[m]) # Step-3: 再设置插入行的(除了第一列)其余列的值
            
            #self.miniFrame_PolyLine.Centre()
            self.miniFrame_PolyLine.Show()
            self.miniFrame_PolyLine.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
        
        # ======================== (2)左双击的是[Pass]列
        elif the_colLabel == 'Pass':
            if itemText_3 in ['0', 'Empty',]:
                return
            
            #if self.miniFrame_PolyLine_Pass:
            #    self.miniFrame_PolyLine_Pass.Destroy()
                
            self.miniFrame_PolyLine_Pass = wx.MiniFrame(parent=self.scroller, title=f'{itemText_1}.{itemText_2} (Pass Trend Chart)', size=(1000+400+20+10, 320+20+320+25+10), style=wx.CAPTION|wx.CLOSE_BOX)  #|wx.STAY_ON_TOP
            self.miniFrame_PolyLine_Pass.SetBackgroundColour((240,240,240))
            
            # 读取对应的 csv file
            chart_var_file = os.path.join(gui.Charts_data_folder, f'{itemText_1}.{itemText_2}.csv')
            if not os.path.isfile(chart_var_file):
                wx.MessageBox(message=f'Find no {chart_var_file}', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return
            
            points_LOG  = []
            n_UID_Value = []
            with open(file=chart_var_file, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                n_Pass = 0
                for row in rows:
                    if row[itemText_2 + '_Status'] in ['PASS', '1st Pass']: # 注意: 要兼容'1st Pass'
                        n_Pass += 1
                        points_LOG.append([n_Pass, row[itemText_2]])
                        n_UID_Value.append([str(n_Pass), row[login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID'], row[itemText_2]])
                LSL_str, USL_str = row['LSL'], row['USL']
                LSL,     USL     = float(row['LSL']), float(row['USL'])

            # 画折线图(Pass Trend Chart)
            horizon_L = []
            horizon_U = []
            for i in range(1, len(points_LOG)+1, 1): # range(start, stop[, step])
                horizon_L.append([i, LSL])
                horizon_U.append([i, USL])        
            
            line_LSL = wxPyPlot.PolyLine(points=horizon_L, colour='red', width=1, style=wx.PENSTYLE_LONG_DASH, legend='LSL')
            line_USL = wxPyPlot.PolyLine(points=horizon_U, colour='red', width=1, style=wx.PENSTYLE_LONG_DASH, legend='USL')
            line_LOG = wxPyPlot.PolyLine(points=points_LOG, colour='blue', width=2, style=wx.PENSTYLE_SOLID, legend=itemText_2)
            line_objects_list = [line_LSL, line_USL, line_LOG]
            Result_graphics = wxPyPlot.PlotGraphics(objects=line_objects_list,title=f'{itemText_2} (Pass Trend Chart Based on Time Ascending)',xLabel='',yLabel=f'[{LSL_str}, {USL_str}]')
            Trend_chart_pc  = wxPyPlot.PlotCanvas(self.miniFrame_PolyLine_Pass, pos=(0,0), size=(1000,320)) # 此处导入绘图画布
            Trend_chart_pc.Draw(graphics=Result_graphics, xAxis=(0,50) if len(points_LOG) <= 50 else (0,len(points_LOG)), yAxis=(LSL-(USL-LSL)/20, USL+(USL-LSL)/20))
            Trend_chart_pc.SetBackgroundColour((240,240,240))
            Trend_chart_pc.xSpec              = 50                         # 水平X轴,将用户定义的the_xAxis范围内数值分割50组
            Trend_chart_pc.ySpec              = 10                         # 竖直Y轴,将用户定义的the_yAxis范围内数值分割10组
            Trend_chart_pc.fontSizeLegend     = 10                         # 默认是7, 图例字体的大小
            Trend_chart_pc.showScrollbars     = True                       # 默认是False, 滚动条. Me: 发现这个必须设置True, 否则图不能自动适应展开!!!
            Trend_chart_pc.enableAntiAliasing = True                       # 默认是False, 抗锯齿
            Trend_chart_pc.enableLegend       = False                      # 默认是False
            Trend_chart_pc.enableTicks        = (True,True,False, False)   # 默认(bottom, left, top, right)=(False,False,False,False)
            # Trend_chart_pc.enableCenterLines = 'Horizontal'              # 默认是False(两个方向中心线的有无一起设置相同), 'Horizontal'(只有水平中心线), 'Vertical'(只有竖直中心线)
            
            # 从小到大
            ascending_points_LOG = sorted(points_LOG, key=lambda x:float(x[1]), reverse=False)
            final_points_LOG     = []
            for n, (i,j) in enumerate(ascending_points_LOG,1):
                final_points_LOG.append([n, j])
            line_LOG = wxPyPlot.PolyLine(points=final_points_LOG, colour='blue', width=2, style=wx.PENSTYLE_SOLID, legend=itemText_2)
            line_objects_list = [line_LSL, line_USL, line_LOG]
            Result_graphics = wxPyPlot.PlotGraphics(objects=line_objects_list,title=f'{itemText_2} (Pass Trend Chart Based on Value Ascending)',xLabel='',yLabel=f'[{LSL_str}, {USL_str}]')
            Trend_chart_pc  = wxPyPlot.PlotCanvas(self.miniFrame_PolyLine_Pass, pos=(0,340), size=(1000,320)) # 此处导入绘图画布
            Trend_chart_pc.Draw(graphics=Result_graphics, xAxis=(0,30), yAxis=(LSL-(USL-LSL)/20, USL+(USL-LSL)/20))
            Trend_chart_pc.SetBackgroundColour((240,240,240))
            Trend_chart_pc.xSpec              = 30                         # 水平X轴,将用户定义的the_xAxis范围内数值分割30组
            Trend_chart_pc.ySpec              = 10                         # 竖直Y轴,将用户定义的the_yAxis范围内数值分割10组
            Trend_chart_pc.fontSizeLegend     = 10                         # 默认是7, 图例字体的大小
            Trend_chart_pc.showScrollbars     = True                       # 默认是False, 滚动条. Me: 发现这个必须设置True, 否则图不能自动适应展开!!!
            Trend_chart_pc.enableAntiAliasing = True                       # 默认是False, 抗锯齿
            Trend_chart_pc.enableLegend       = False                      # 默认是False
            Trend_chart_pc.enableTicks        = (True,True,False, False)   # 默认(bottom, left, top, right)=(False,False,False,False)
            # Trend_chart_pc.enableCenterLines = 'Horizontal'              # 默认是False(两个方向中心线的有无一起设置相同), 'Horizontal'(只有水平中心线), 'Vertical'(只有竖直中心线)
            
            
            # ------------ 创建一个表格, 显示折线图的细节数据
            var_name = wx.StaticText(self.miniFrame_PolyLine_Pass, -1, label=itemText_2, pos=(1000,0), size=(400+20,20), style=wx.ALIGN_CENTER)
            DD_table = wx.ListCtrl(self.miniFrame_PolyLine_Pass, -1, (1000,20),(400+20,280), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            DD_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            DD_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            DD_table.SetBackgroundColour((240,240,240))
            DD_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            DD_fieldnames = ['X_axis', login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID', 'Value']
                   
            for n, fieldname in enumerate(DD_fieldnames, 0):
                DD_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=150) # Step-1: 必须先插入列
            DD_table.SetColumnWidth(col=0, width=55)    # 修改指定的一列的宽度
            DD_table.SetColumnWidth(col=1, width=195)   # 修改指定的一列的宽度
            
            for n, row_data_list in enumerate(n_UID_Value, 0):
                index_row = DD_table.InsertItem(index=n, label=row_data_list[0])        # Step-2: 再插入行,顺便设置了此行第一列的值
                for m in range(1, len(DD_fieldnames), 1):
                    DD_table.SetItem(index=index_row, column=m, label=row_data_list[m]) # Step-3: 再设置插入行的(除了第一列)其余列的值
                    
            # 从小到大
            var_name = wx.StaticText(self.miniFrame_PolyLine_Pass, -1, label=itemText_2, pos=(1000,340), size=(400+20,20), style=wx.ALIGN_CENTER)
            DD_table = wx.ListCtrl(self.miniFrame_PolyLine_Pass, -1, (1000,360),(400+20,280), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            DD_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            DD_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            DD_table.SetBackgroundColour((240,240,240))
            DD_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            DD_fieldnames = ['X_axis', login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID', 'Value']
                   
            for n, fieldname in enumerate(DD_fieldnames, 0):
                DD_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=150) # Step-1: 必须先插入列
            DD_table.SetColumnWidth(col=0, width=55)    # 修改指定的一列的宽度
            DD_table.SetColumnWidth(col=1, width=195)   # 修改指定的一列的宽度
            
            ascending_n_UID_Value = sorted(n_UID_Value, key=lambda x:float(x[2]), reverse=False)
            final_n_UID_Value     = []
            for n, (i,j,k) in enumerate(ascending_n_UID_Value,1):
                final_n_UID_Value.append([str(n), j, k])
            for n, row_data_list in enumerate(final_n_UID_Value, 0):
                index_row = DD_table.InsertItem(index=n, label=row_data_list[0])        # Step-2: 再插入行,顺便设置了此行第一列的值
                for m in range(1, len(DD_fieldnames), 1):
                    DD_table.SetItem(index=index_row, column=m, label=row_data_list[m]) # Step-3: 再设置插入行的(除了第一列)其余列的值
            
            #self.miniFrame_PolyLine_Pass.Centre()
            self.miniFrame_PolyLine_Pass.Show()
            self.miniFrame_PolyLine_Pass.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
        
        # ======================== (3)左双击的是[Fail]列        
        elif the_colLabel == 'Fail':
            if itemText_3 in ['0', 'Empty',]:
                return
            
            #if self.miniFrame_fail_data:
            #    self.miniFrame_fail_data.Destroy()
            
            visible_row_max = 30
            the_Height      = int(30+21*int(itemText_3))+20 if int(itemText_3) <= visible_row_max else 30+21*visible_row_max+20
            self.miniFrame_fail_data = wx.MiniFrame(parent=self.scroller, title=f'{itemText_1}.{itemText_2} (Fail Data)', size=(540+20+5, the_Height+25+0), style=wx.CAPTION|wx.CLOSE_BOX)  #|wx.STAY_ON_TOP
            self.miniFrame_fail_data.SetBackgroundColour((240,240,240))
            
            # 读取对应的 csv file
            fail_var_file = os.path.join(gui.Charts_data_folder, f'{itemText_1}.{itemText_2}.csv')
            if not os.path.isfile(fail_var_file):
                wx.MessageBox(message=f'Find no {fail_var_file}', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return
            
            csv_data = []
            with open(file=fail_var_file, mode='r', encoding='utf-8') as f_obj:
                reader = csv.reader(f_obj) # Me: 2023-04-05的心得: iterator, 若文件为空, 则结果是[[]]; 若不为空，则结果是[['R1C1', 'R1C2', 'R1C3'],['R2C1', 'R2C2', 'R2C3'], ...]
                # 特别注意: 下面这两句不能顶格写,否则会报错: ValueError: I/O operation on closed file.
                for n, row in enumerate(reader,0):
                    if n == 0:
                        del row[1]
                        del row[2] # 注意: 这一行的 row 是已经删除原 row 列表的第1个元素后的新 row
                        csv_data.append(row)
                    else:
                        if row[3] == 'FAIL':
                            del row[1]
                            del row[2] # 注意: 这一行的 row 是已经删除原 row 列表的第1个元素后的新 row
                            csv_data.append(row)
            
            # 绘制失效数据的子表格
            Fail_table = wx.ListCtrl(self.miniFrame_fail_data, -1, (0,0),(540+20, the_Height), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            Fail_table.SetHeaderAttr(attr=wx.ItemAttr(colText='red', colBack='blue', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            Fail_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            Fail_table.SetBackgroundColour((240,240,240))
            Fail_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            Fail_fieldnames = csv_data[0]
            Fail_data_temp  = csv_data[1:]
            Fail_fieldnames.insert(0, 'No.')
            Fail_data = []
            for i, each_row in enumerate(Fail_data_temp,1):
                each_row.insert(0,str(i))
                Fail_data.append(each_row)
                
            # 首先插入表格眉头
            for n, fieldname in enumerate(Fail_fieldnames, 0):
                Fail_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=70) # Step-1: 必须先插入列
            Fail_table.SetColumnWidth(col=0, width=55)  # 修改指定的一列的宽度
            Fail_table.SetColumnWidth(col=1, width=195) # 修改指定的一列的宽度
            Fail_table.SetColumnWidth(col=2, width=150) # 修改指定的一列的宽度
            # 然后插入下面的每一行
            for n, row_data_list in enumerate(Fail_data, 0):
                index_row = Fail_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
                for m in range(1, len(Fail_fieldnames), 1):
                    Fail_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
            
            #self.miniFrame_fail_data.Centre()
            self.miniFrame_fail_data.Show()
            self.miniFrame_fail_data.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
        
        # ======================== (4)左双击的是[1st Pass]列
        elif the_colLabel == '1st Pass':
            if itemText_3 in ['0', 'Empty',]:
                return
            
            #if self.miniFrame_PolyLine_1st_Pass:
            #    self.miniFrame_PolyLine_1st_Pass.Destroy()
                
            self.miniFrame_PolyLine_1st_Pass = wx.MiniFrame(parent=self.scroller, title=f'{itemText_1}.{itemText_2} (1st Pass Trend Chart)', size=(1000+400+20+10, 320+20+320+25+10), style=wx.CAPTION|wx.CLOSE_BOX)  #|wx.STAY_ON_TOP
            self.miniFrame_PolyLine_1st_Pass.SetBackgroundColour((240,240,240))
            
            # 读取对应的 csv file
            chart_var_file = os.path.join(gui.Charts_data_folder, f'{itemText_1}.{itemText_2}.csv')
            if not os.path.isfile(chart_var_file):
                wx.MessageBox(message=f'Find no {chart_var_file}', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return
            
            points_LOG  = []
            n_UID_Value = []
            with open(file=chart_var_file, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                n_1st_Pass = 0
                for row in rows:
                    if row[itemText_2 + '_Status'] in ['1st Pass']: # 注意: 只看'1st Pass'
                        n_1st_Pass += 1
                        points_LOG.append([n_1st_Pass, row[itemText_2]])
                        n_UID_Value.append([str(n_1st_Pass), row[login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID'], row[itemText_2]])
                LSL_str, USL_str = row['LSL'], row['USL']
                LSL,     USL     = float(row['LSL']), float(row['USL'])

            # 画折线图(1st Pass Trend Chart)
            horizon_L = []
            horizon_U = []
            for i in range(1, len(points_LOG)+1, 1): # range(start, stop[, step])
                horizon_L.append([i, LSL])
                horizon_U.append([i, USL])        
            
            line_LSL = wxPyPlot.PolyLine(points=horizon_L, colour='red', width=1, style=wx.PENSTYLE_LONG_DASH, legend='LSL')
            line_USL = wxPyPlot.PolyLine(points=horizon_U, colour='red', width=1, style=wx.PENSTYLE_LONG_DASH, legend='USL')
            line_LOG = wxPyPlot.PolyLine(points=points_LOG, colour='blue', width=2, style=wx.PENSTYLE_SOLID, legend=itemText_2)
            line_objects_list = [line_LSL, line_USL, line_LOG]
            Result_graphics = wxPyPlot.PlotGraphics(objects=line_objects_list,title=f'{itemText_2} (1st Pass Trend Chart Based on Time Ascending)',xLabel='',yLabel=f'[{LSL_str}, {USL_str}]')
            Trend_chart_pc  = wxPyPlot.PlotCanvas(self.miniFrame_PolyLine_1st_Pass, pos=(0,0), size=(1000,320)) # 此处导入绘图画布
            Trend_chart_pc.Draw(graphics=Result_graphics, xAxis=(0,50) if len(points_LOG) <= 50 else (0,len(points_LOG)), yAxis=(LSL-(USL-LSL)/20, USL+(USL-LSL)/20))
            Trend_chart_pc.SetBackgroundColour((240,240,240))
            Trend_chart_pc.xSpec              = 50                         # 水平X轴,将用户定义的the_xAxis范围内数值分割50组
            Trend_chart_pc.ySpec              = 10                         # 竖直Y轴,将用户定义的the_yAxis范围内数值分割10组
            Trend_chart_pc.fontSizeLegend     = 10                         # 默认是7, 图例字体的大小
            Trend_chart_pc.showScrollbars     = True                       # 默认是False, 滚动条. Me: 发现这个必须设置True, 否则图不能自动适应展开!!!
            Trend_chart_pc.enableAntiAliasing = True                       # 默认是False, 抗锯齿
            Trend_chart_pc.enableLegend       = False                      # 默认是False
            Trend_chart_pc.enableTicks        = (True,True,False, False)   # 默认(bottom, left, top, right)=(False,False,False,False)
            # Trend_chart_pc.enableCenterLines = 'Horizontal'              # 默认是False(两个方向中心线的有无一起设置相同), 'Horizontal'(只有水平中心线), 'Vertical'(只有竖直中心线)
            
            # 从小到大
            ascending_points_LOG = sorted(points_LOG, key=lambda x:float(x[1]), reverse=False)
            final_points_LOG     = []
            for n, (i,j) in enumerate(ascending_points_LOG,1):
                final_points_LOG.append([n, j])
            line_LOG = wxPyPlot.PolyLine(points=final_points_LOG, colour='blue', width=2, style=wx.PENSTYLE_SOLID, legend=itemText_2)
            line_objects_list = [line_LSL, line_USL, line_LOG]
            Result_graphics = wxPyPlot.PlotGraphics(objects=line_objects_list,title=f'{itemText_2} (1st Pass Trend Chart Based on Value Ascending)',xLabel='',yLabel=f'[{LSL_str}, {USL_str}]')
            Trend_chart_pc  = wxPyPlot.PlotCanvas(self.miniFrame_PolyLine_1st_Pass, pos=(0,340), size=(1000,320)) # 此处导入绘图画布
            Trend_chart_pc.Draw(graphics=Result_graphics, xAxis=(0,30), yAxis=(LSL-(USL-LSL)/20, USL+(USL-LSL)/20))
            Trend_chart_pc.SetBackgroundColour((240,240,240))
            Trend_chart_pc.xSpec              = 30                         # 水平X轴,将用户定义的the_xAxis范围内数值分割50组
            Trend_chart_pc.ySpec              = 10                         # 竖直Y轴,将用户定义的the_yAxis范围内数值分割10组
            Trend_chart_pc.fontSizeLegend     = 10                         # 默认是7, 图例字体的大小
            Trend_chart_pc.showScrollbars     = True                       # 默认是False, 滚动条. Me: 发现这个必须设置True, 否则图不能自动适应展开!!!
            Trend_chart_pc.enableAntiAliasing = True                       # 默认是False, 抗锯齿
            Trend_chart_pc.enableLegend       = False                      # 默认是False
            Trend_chart_pc.enableTicks        = (True,True,False, False)   # 默认(bottom, left, top, right)=(False,False,False,False)
            # Trend_chart_pc.enableCenterLines = 'Horizontal'              # 默认是False(两个方向中心线的有无一起设置相同), 'Horizontal'(只有水平中心线), 'Vertical'(只有竖直中心线)
            
            
            # ------------ 创建一个表格, 显示折线图的细节数据
            var_name = wx.StaticText(self.miniFrame_PolyLine_1st_Pass, -1, label=itemText_2, pos=(1000,0), size=(400+20,20), style=wx.ALIGN_CENTER)
            DD_table = wx.ListCtrl(self.miniFrame_PolyLine_1st_Pass, -1, (1000,20),(400+20,280), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            DD_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            DD_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            DD_table.SetBackgroundColour((240,240,240))
            DD_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            DD_fieldnames = ['X_axis', login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID', 'Value']
                   
            for n, fieldname in enumerate(DD_fieldnames, 0):
                DD_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=150) # Step-1: 必须先插入列
            DD_table.SetColumnWidth(col=0, width=55)    # 修改指定的一列的宽度
            DD_table.SetColumnWidth(col=1, width=195)   # 修改指定的一列的宽度
            
            for n, row_data_list in enumerate(n_UID_Value, 0):
                index_row = DD_table.InsertItem(index=n, label=row_data_list[0])        # Step-2: 再插入行,顺便设置了此行第一列的值
                for m in range(1, len(DD_fieldnames), 1):
                    DD_table.SetItem(index=index_row, column=m, label=row_data_list[m]) # Step-3: 再设置插入行的(除了第一列)其余列的值
                    
            # 从小到大
            var_name = wx.StaticText(self.miniFrame_PolyLine_1st_Pass, -1, label=itemText_2, pos=(1000,0), size=(400+20,20), style=wx.ALIGN_CENTER)
            DD_table = wx.ListCtrl(self.miniFrame_PolyLine_1st_Pass, -1, (1000,340),(400+20,280), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
            DD_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
            DD_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            DD_table.SetBackgroundColour((240,240,240))
            DD_table.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.LIST_ITEM_ACTIVATED_Search_FCT)
            DD_fieldnames = ['X_axis', login_GUI.Index_var_custom if self.Flag_1 else 'NonUniqueUID', 'Value']
                   
            for n, fieldname in enumerate(DD_fieldnames, 0):
                DD_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=150) # Step-1: 必须先插入列
            DD_table.SetColumnWidth(col=0, width=55)    # 修改指定的一列的宽度
            DD_table.SetColumnWidth(col=1, width=195)   # 修改指定的一列的宽度
            
            ascending_n_UID_Value = sorted(n_UID_Value, key=lambda x:float(x[2]), reverse=False)
            final_n_UID_Value     = []
            for n, (i,j,k) in enumerate(ascending_n_UID_Value,1):
                final_n_UID_Value.append([str(n), j, k])
            for n, row_data_list in enumerate(final_n_UID_Value, 0):
                index_row = DD_table.InsertItem(index=n, label=row_data_list[0])        # Step-2: 再插入行,顺便设置了此行第一列的值
                for m in range(1, len(DD_fieldnames), 1):
                    DD_table.SetItem(index=index_row, column=m, label=row_data_list[m]) # Step-3: 再设置插入行的(除了第一列)其余列的值
            
            #self.miniFrame_PolyLine_1st_Pass.Centre()
            self.miniFrame_PolyLine_1st_Pass.Show()
            self.miniFrame_PolyLine_1st_Pass.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
        
        else:
            pass
    
    def OnCellRightDClick(self, evt):
        print("右双击单元格: (%d,%d)" % (evt.GetRow(), evt.GetCol()), end='\n\n')
        if self.miniFrame_summary_7d:
            self.miniFrame_summary_7d.Destroy()
        # 特别注意: self.H_grid 虽然本身已包括预留给水平滚动条20Px, 
        # 但在grid控件与wx.MiniFrame控件之间的实际磨合时, 发现 wx.MiniFrame 控件在尺寸设置上需要比grid控件额外高35Px, 宽15Px.
        this_Height = self.H_grid+35 if self.H_grid+35 < self.screen_H-50 else self.screen_H-50
        self.miniFrame_summary_7d = wx.MiniFrame(parent=self.scroller, title='Summary', pos=(0,20), size=(1480+20+15,this_Height), style=wx.CAPTION|wx.CLOSE_BOX|wx.RESIZE_BORDER)
        self.popup_summary_table  = grid.Grid(self.miniFrame_summary_7d, -1, (0,0), (1480+20,self.H_grid), style=wx.WANTS_CHARS)
        table_fieldnames = ['Item', 'LSL / USL', 'Min / Max', 'Avg.', 'Std.', 'CP', 'CA', 'CPK', 'Count', '-3d', '+3d', 'Pass', 'Fail', 'Yield']
        if self.Flag_1 and not self.Flag_2:
            self.miniFrame_summary_7d.SetSize(size=(1480+20+15+70*2,this_Height))
            self.popup_summary_table.SetSize(size=(1480+20+70*2,self.H_grid))
            table_fieldnames.append('1st Pass')
            table_fieldnames.append('1st Yield')
        table_fieldnames += ['-7','-6','-5','-4','-3','-2','-1','0','1','2','3','4','5','6','7']
        self.popup_summary_table.CreateGrid(numRows=len(self.table_data), numCols=len(table_fieldnames))
        self.popup_summary_table.EnableEditing(edit=False)
        self.popup_summary_table.Bind(grid.EVT_GRID_CELL_LEFT_DCLICK, self.OnCellLeftDClick)
        self.popup_summary_table.Bind(grid.EVT_GRID_LABEL_RIGHT_CLICK, self.OnLabelRightClick)
        
        # ---------------------------------------- 设置标签Label
        # self.popup_summary_table.SetGridLineColour((171,171,171))                                   # 设置所有单元格线的颜色,默认值是(192,192,192,255)
        self.popup_summary_table.SetColLabelSize(height=25)                                           # 设置列标签的高度, 而列标签的宽度随单元格的宽度
        self.popup_summary_table.SetRowLabelSize(width=40)                                            # 设置行标签的宽度，而行标签的高度随单元格的高度
        self.popup_summary_table.SetCornerLabelValue('No.')
        
        for n, per_fieldname in enumerate(table_fieldnames, 0):
            self.popup_summary_table.SetColLabelValue(col=n, value=per_fieldname)
        
        for per_n in range(0, len(self.table_data), 1):
            self.popup_summary_table.SetRowLabelValue(row=per_n, value='{:03d}'.format(per_n+1))   
        
        self.popup_summary_table.SetLabelBackgroundColour(colour=(248,249,250))                       # 设置标签的背景颜色
        self.popup_summary_table.SetLabelTextColour(colour='black')                                   # 设置标签的字体颜色
        self.popup_summary_table.SetCornerLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)   # 设置Corner标签左右以及上下对齐方式：左对齐，下沉
        self.popup_summary_table.SetColLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)      # 设置column标签左右以及上下对齐方式：左对齐，下沉
        self.popup_summary_table.SetRowLabelAlignment(horiz=wx.ALIGN_LEFT, vert=wx.ALIGN_BOTTOM)      # 设置row标签左右以及上下对齐方式：   右对齐，下沉
        self.popup_summary_table.SetLabelFont(font=wx.Font(pointSize=10, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_BOLD, underline=False, faceName='Microsoft JhengHei UI'))
        
        # ---------------------------------------- 设置单个单元格cell
        for per_n in range(0, len(table_fieldnames), 1):
            self.popup_summary_table.SetColSize(col=per_n, width=70)  
        self.popup_summary_table.SetColSize(col=0, width=160)
        self.popup_summary_table.SetColSize(col=1, width=90)
        self.popup_summary_table.SetColSize(col=2, width=130)
        self.popup_summary_table.SetColSize(col=13, width=60)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-15, width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-14, width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-13, width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-12, width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-11, width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-10, width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-9,  width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-8,  width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-7,  width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-6,  width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-5,  width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-4,  width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-3,  width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-2,  width=20)
        self.popup_summary_table.SetColSize(col=len(table_fieldnames)-1,  width=20)
        
        for per_n in range(0, len(self.table_data), 1):
            self.popup_summary_table.SetRowSize(row=per_n, height=21)
        
        for m, each_var_data in enumerate(self.table_data, 0):
            for n in range(len(table_fieldnames)-15):
                self.popup_summary_table.SetCellValue(row=m, col=n, s=each_var_data[n+1])
                self.popup_summary_table.SetCellBackgroundColour(row=m, col=n, colour=(227,242,253))
                self.popup_summary_table.SetCellFont(row=m, col=n, font=wx.Font(10, family=wx.FONTFAMILY_ROMAN, style=wx.FONTSTYLE_NORMAL, weight=wx.FONTWEIGHT_NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
            
            # Case1: LSL/USL都为空即没有值时的字体颜色强制设置成红色
            if each_var_data[3] == 'Empty / Empty':
                for i in range(2, len(table_fieldnames)-15):
                    self.popup_summary_table.SetCellTextColour(row=m, col=i, colour=wx.RED)
            
            # Case2: 有值时, 要考虑到 'nan', 'inf', '-inf'
            else:
                if each_var_data[5] == 'nan':
                    self.popup_summary_table.SetCellValue(row=m, col=4, s='')
                elif each_var_data[5] == 'inf':
                    self.popup_summary_table.SetCellValue(row=m, col=4, s='∞')
                elif each_var_data[5] == '-inf':
                    self.popup_summary_table.SetCellValue(row=m, col=4, s='-∞')
                    
                if each_var_data[6] == 'nan':
                    self.popup_summary_table.SetCellValue(row=m, col=5, s='')
                elif each_var_data[6] == 'inf':
                    self.popup_summary_table.SetCellValue(row=m, col=5, s='∞')
                elif each_var_data[6] == '-inf':
                    self.popup_summary_table.SetCellValue(row=m, col=5, s='-∞') 
                    
                if each_var_data[8] == 'nan':
                    self.popup_summary_table.SetCellValue(row=m, col=7, s='')
                elif each_var_data[8] == 'inf':
                    self.popup_summary_table.SetCellValue(row=m, col=7, s='∞')
                elif each_var_data[8] == '-inf':
                    self.popup_summary_table.SetCellValue(row=m, col=7, s='-∞')
                    
                if each_var_data[10] == 'nan':
                    self.popup_summary_table.SetCellValue(row=m, col=9, s='')
                elif each_var_data[10] == 'inf':
                    self.popup_summary_table.SetCellValue(row=m, col=9, s='∞')
                elif each_var_data[10] == '-inf':
                    self.popup_summary_table.SetCellValue(row=m, col=9, s='-∞')
                    
                if each_var_data[11] == 'nan':
                    self.popup_summary_table.SetCellValue(row=m, col=10, s='')
                elif each_var_data[11] == 'inf':
                    self.popup_summary_table.SetCellValue(row=m, col=10, s='∞')
                elif each_var_data[11] == '-inf':
                    self.popup_summary_table.SetCellValue(row=m, col=10, s='-∞')
                
                # Case3: 有值时, 不满足±3σ理论和Cpk<1.33的字体颜色强制设置成红色                 
                if login_GUI.mark_color_custom:
                    if float(each_var_data[10]) < float(each_var_data[2].split('/')[0]):
                        self.popup_summary_table.SetCellTextColour(row=m, col=9, colour=wx.RED)
                    if float(each_var_data[11]) > float(each_var_data[2].split('/')[1]):
                        self.popup_summary_table.SetCellTextColour(row=m, col=10, colour=wx.RED)
                    if float(each_var_data[8]) < 1.33:
                        self.popup_summary_table.SetCellTextColour(row=m, col=7, colour=wx.RED)
                        
                # Case4: 有值时, [Fail]列不等于0时的字体颜色强制设置成红色
                if each_var_data[13] != '0':
                    self.popup_summary_table.SetCellTextColour(row=m, col=12, colour=wx.RED)
                
            # 统一设定±7σ的背景颜色设置
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-15, colour=each_var_data[-15][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-14, colour=each_var_data[-14][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-13, colour=each_var_data[-13][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-12, colour=each_var_data[-12][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-11, colour=each_var_data[-11][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-10, colour=each_var_data[-10][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-9,  colour=each_var_data[-9][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-8,  colour=each_var_data[-8][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-7,  colour=each_var_data[-7][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-6,  colour=each_var_data[-6][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-5,  colour=each_var_data[-5][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-4,  colour=each_var_data[-4][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-3,  colour=each_var_data[-3][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-2,  colour=each_var_data[-2][0])
            self.popup_summary_table.SetCellBackgroundColour(row=m, col=len(table_fieldnames)-1,  colour=each_var_data[-1][0])
        
        #self.miniFrame_summary_7d.Centre()
        self.miniFrame_summary_7d.Show()
        self.miniFrame_summary_7d.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
        
    def OnLabelRightClick(self, evt):
        row_col_clicked = evt.GetRow(), evt.GetCol()
        print('右单击[标签]的行列:', row_col_clicked)

        the_object = evt.GetEventObject()
        the_row    = row_col_clicked[0]
        the_col    = row_col_clicked[1]
        
        if the_row >= 0:
            the_rowLabel = the_object.GetRowLabelValue(row=the_row)
            the_item     = the_object.GetCellValue(row=the_row, col=0)
            print('右单击(行)标签的内容为:', the_rowLabel, the_item, end='\n\n')
            dlg_delete = wx.MessageDialog(parent=the_object, message=f'Do you want to delete "{the_rowLabel}: {the_item}" row ?', caption='Tip', style=wx.YES_NO|wx.YES_DEFAULT|wx.ICON_INFORMATION)
            res = dlg_delete.ShowModal()
            if res == wx.ID_YES:
                the_object.DeleteRows(pos=the_row, numRows=1, updateLabels=True)
            elif res == wx.ID_NO:
                pass
            dlg_delete.Destroy()    
        elif the_col > 0:
            the_colLabel = the_object.GetColLabelValue(col=the_col)
            print('右单击(列)标签的内容为:', the_colLabel, end='\n\n')            
            dlg_delete = wx.MessageDialog(parent=the_object, message=f'Do you want to delete "{the_colLabel}" column ?', caption='Tip', style=wx.YES_NO|wx.YES_DEFAULT|wx.ICON_INFORMATION)
            res = dlg_delete.ShowModal()
            if res == wx.ID_YES:
                the_object.DeleteCols(pos=the_col, numCols=1, updateLabels=True)
            elif res == wx.ID_NO:
                pass
            dlg_delete.Destroy()
        else:
            pass
            
    def btn_query_group_FCT(self, evt):
        the_name = evt.GetEventObject().GetName()
        print('Group:', the_name)
        if self.miniFrame_query:
            self.miniFrame_query.Destroy()
        self.miniFrame_query = wx.MiniFrame(parent=self.scroller, title=the_name, size=(1180+10,30+21*4+15+5+25), style=wx.CAPTION|wx.CLOSE_BOX)  #|wx.STAY_ON_TOP
        # 绘制该变量分组细节的子表格
        Group_table = wx.ListCtrl(self.miniFrame_query, -1, (0,0),(1180, 30+21*4+15), style=wx.LC_REPORT|wx.LC_HRULES|wx.LC_VRULES|wx.LC_SINGLE_SEL)
        Group_table.SetHeaderAttr(attr=wx.ItemAttr(colText='blue', colBack='red', font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.BOLD, underline=False, faceName="Microsoft JhengHei UI")))
        Group_table.SetFont(font=wx.Font(pointSize=10, family=wx.DEFAULT, style=wx.NORMAL, weight=wx.NORMAL, underline=False, faceName='Microsoft JhengHei UI'))
        Group_fieldnames           = ['Group',]
        row_1, row_2, row_3, row_4 = ['Range',], ['Typical',], ['Count',], ['Percentage',]
        groups = self.all_bin_typical_count_percentage[the_name]
        counts = []
        for each_group in groups:
            counts.append(int(each_group[2]))
        max_count = max(counts)
        for i, each_range in enumerate(self.all_bin_typical_count_percentage[the_name], 0):
            Group_fieldnames.append(f'{i+1} (Peak)' if int(each_range[2])==max_count else f'{i+1}')
            row_1.append(each_range[0])
            row_2.append(each_range[1])
            row_3.append(each_range[2])
            row_4.append(each_range[3])
            
        for n, fieldname in enumerate(Group_fieldnames, 0):
            Group_table.InsertColumn(col=n, heading=fieldname, format=wx.LIST_FORMAT_LEFT, width=110) # Step-1: 必须先插入列
        Group_table.SetColumnWidth(col=0, width=80)   # 修改指定的一列的宽度
        
        Group_data = [row_1, row_2, row_3, row_4]
        for n, row_data_list in enumerate(Group_data, 0):
            index_row = Group_table.InsertItem(index=n, label=row_data_list[0])       # Step-2: 再插入行,顺便设置了此行第一列的值
            for m in range(1, len(Group_fieldnames), 1):
                Group_table.SetItem(index=index_row, column=m, label=row_data_list[m])# Step-3: 再设置插入行的(除了第一列)其余列的值
        
        self.miniFrame_query.Centre()
        self.miniFrame_query.Show()
        self.miniFrame_query.SetFocus() # 注意: 若不写这句, wx.MiniFrame 迷你框架右上角的[关闭]按钮就不显示红色背景.
        
    def PolyHistogram_FCT(self,
                        specified_hist:list,
                        specified_binspec:list,
                        specified_LSL,
                        specified_USL,
                        specified_max_group,
                        specified_title,
                        specified_xLabel,
                        specified_pos,
                        specified_xAxis:tuple):
        
        histogram = wxPyPlot.PolyHistogram(hist=specified_hist,
                                        binspec=specified_binspec,  #官方: Important len(binspec) must equal len(hist) + 1.
                                        edgecolour='black',
                                        edgewidth=0.2,
                                        edgestyle=wx.PENSTYLE_SOLID,
                                        fillcolour=(129,140,161),
                                        fillstyle=wx.BRUSHSTYLE_SOLID,
                                        legend='Histogram')
        line_LSL = wxPyPlot.PolyLine(points=[[specified_LSL,0],[specified_LSL,specified_max_group*1.05]], colour=(65,78,110), width=4, style=wx.PENSTYLE_LONG_DASH, legend='LSL')
        line_USL = wxPyPlot.PolyLine(points=[[specified_USL,0],[specified_USL,specified_max_group*1.05]], colour=(65,78,110), width=3, style=wx.PENSTYLE_LONG_DASH, legend='USL')
        graphic  = wxPyPlot.PlotGraphics(objects=[histogram, line_LSL, line_USL], title=specified_title, xLabel=specified_xLabel, yLabel='Count')
        
        pc = wxPyPlot.PlotCanvas(parent=self.scroller, pos=specified_pos, size=(self.Hist_W_custom,self.Hist_H_custom)) # 此处导入绘图面板
        pc.Draw(graphics=graphic, xAxis=specified_xAxis, yAxis=(0,specified_max_group*1.05))
        #pc.xSpec             = len(specified_binspec)-1    # X轴均匀出现多少小格子, 多少坐标点
        pc.xSpec              = self.Interval_user          # X轴均匀出现多少小格子, 多少坐标点
        pc.ySpec              = 20                          # Y轴均匀出现多少小格子, 多少坐标点
        pc.enableGrid         = (self.flag_Grid_custom, self.flag_Grid_custom)
        pc.enableAntiAliasing = True                        # 默认是False, 抗锯齿
        pc.showScrollbars     = True                        # 默认是False, 滚动条. Me: 发现这个必须设置True, 否则图不能自动适应展开!!!
        pc.enablePointLabel   = True                        # 默认是Fasle, Me: 尚不知道为啥不奏效，显示不了点的标签
        pc.enableAxes         = (True,False,True,False)    # 默认(bottom, left, top, right)=(True,True,True,True)
        pc.enableTicks        = (True,False,False,False)   # 默认(bottom, left, top, right)=(False,False,False,False)
        return {graphic.title: pc}
        
    def btn_export_images_FCT(self, evt, pdf_saved=False):
        if not os.path.isdir(self.temp_folder):
            os.mkdir(path=self.temp_folder)
        
        for i in os.listdir(path=self.temp_folder):
            the_file = os.path.join(self.temp_folder,i)
            if os.path.isfile(the_file) and os.path.splitext(the_file)[1].upper() == '.JPG':
                os.remove(path=the_file)
                
        if self.all_histogram:
            dialog = wx.ProgressDialog(title='Exporting Histogram', message=f'Completed: 0/{len(self.all_histogram)}', maximum=len(self.all_histogram), parent=None, style=wx.PD_AUTO_HIDE)
            for n, each_hist in enumerate(self.all_histogram, 1):
                for key, value in each_hist.items():
                    image_saved = os.path.join(self.temp_folder, f'{key}.jpg')
                    if self.active_algorithm_image in ['LogiNet2.0', 'LogiNet2.0(LSL~USL)']:
                        value.SaveFile(fileName=image_saved)
                    elif self.active_algorithm_image in ['Minitab(Simple)', 'Minitab(With Fit)']:
                        # value.print_jpg(filename_or_obj=image_saved)
                        value.savefig(fname=image_saved)
                dialog.Update(value=n, newmsg=f'Completed: {n}/{len(self.all_histogram)}')
            dialog.Destroy()
            abs_path = os.path.abspath(self.temp_folder)
            if not pdf_saved:
                #wx.MessageBox(message=f'[Done] Export all histograms\n\n{abs_path}', caption='Success', style=wx.ICON_INFORMATION, parent=self)
                dlg_Question = wx.MessageDialog(parent=self, message=f'Do you need view histograms pictures(*.jpg) now?\n\n{abs_path}', caption='Successfully Exported', style=wx.ICON_INFORMATION|wx.YES_NO)
                res = dlg_Question.ShowModal()
                if res == wx.ID_YES:
                    if os.path.isdir(abs_path):
                        win32api.ShellExecute(0, 'open', abs_path, '', '', 1)
                elif res == wx.ID_NO:
                    pass
                dlg_Question.Destroy()
        
        else:
            wx.MessageBox(message='Find no histogram available to save', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return
            
    def btn_export_pdf_FCT(self, evt):
        self.btn_export_images_FCT('', pdf_saved=True)
        pdf_obj = FPDF()    # 原型: FPDF(orientation='P', unit='mm', format='A4'), 注意: A4纸:210mm×297mm
        
        # ======================== 首先, 报告首页
        pdf_obj.add_page()
        flag_border = 0     # 这里, 可以设置PDF的每个cell的边框是否显示
        pdf_obj.add_font(family='Arial', style='', fname='c:/windows/fonts/arial.ttf', uni=True)
        pdf_obj.set_font(family='Arial', style='B', size=18)
        pdf_obj.cell(w=100, h=10, txt='Analytics & Reports', border=flag_border, ln=1, align='', fill=0, link='')

        pdf_obj.set_font(family='Arial', style='', size=10)
        pdf_obj.cell(w=190, h=5, txt=f'Reporter: {current_username}', border=flag_border, ln=1, align='R', fill=0, link='')
        pdf_obj.cell(w=190, h=5, txt=f'{datetime.datetime.now().strftime("%Y/%m/%d %H:%M")}', border=flag_border, ln=1, align='R', fill=0, link='')
        
        pdf_obj.ln(h=10)
        pdf_obj.set_font(family='Arial', style='', size=14)
        pdf_obj.cell(w=100, h=5, txt='Project Specs', border=flag_border, ln=1, align='', fill=0, link='')
        pdf_obj.set_font(family='Arial', style='', size=5)
        pdf_obj.cell(w=190, h=4, txt='_'*190, border=flag_border, ln=1, align='', fill=0, link='')
        pdf_obj.set_font(family='Arial', style='B', size=10)
        pdf_obj.cell(w=60, h=8, txt='Date range',    border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=8, txt='Data source',   border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=8, txt='Business unit', border=flag_border, ln=1, align='', fill=0, link='')
        pdf_obj.set_font(family='Arial', style='', size=10)
        pdf_obj.cell(w=60, h=5, txt=', '.join(sorted(list(set(self.Date_range_report)))), border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=5, txt=', '.join(list(set(self.Data_source_report))),        border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=5, txt=', '.join(list(set(self.Business_unit_report))),      border=flag_border, ln=1, align='', fill=0, link='')
        
        pdf_obj.ln(h=5)
        pdf_obj.set_font(family='Arial', style='B', size=10)    
        pdf_obj.cell(w=60, h=8, txt='Project', border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=8, txt='Stage',   border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=8, txt='Station', border=flag_border, ln=1, align='', fill=0, link='')
        pdf_obj.set_font(family='Arial', style='', size=10)
        pdf_obj.cell(w=60, h=5, txt=', '.join(list(set(self.Project_report))), border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=5, txt=', '.join(list(set(self.Stage_report))),   border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=5, txt=', '.join(list(set(self.Station_report))), border=flag_border, ln=1, align='', fill=0, link='')
        
        pdf_obj.ln(h=5)
        pdf_obj.set_font(family='Arial', style='B', size=10)
        pdf_obj.cell(w=100, h=8, txt='File', border=flag_border, ln=1, align='', fill=0, link='')
        pdf_obj.set_font(family='Arial', style='', size=10)
        for each_file_name in [os.path.split(per_file)[1] for per_file in self.original_csv]:
            pdf_obj.cell(w=100, h=5, txt=each_file_name, border=flag_border, ln=1, align='', fill=0, link='')
        
        pdf_obj.ln(h=20)
        pdf_obj.set_font(family='Arial', style='', size=14)
        pdf_obj.cell(w=100, h=5, txt='Station Summary', border=flag_border, ln=1, align='', fill=0, link='')
        pdf_obj.set_font(family='Arial', style='', size=5)
        pdf_obj.cell(w=190, h=4, txt='_'*190, border=flag_border, ln=1, align='', fill=0, link='')
        pdf_obj.set_font(family='Arial', style='B', size=10)
        pdf_obj.cell(w=60, h=8, txt='Total',      border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=8, txt='Fail',       border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=8, txt='Yield rate', border=flag_border, ln=1, align='', fill=0, link='')
        pdf_obj.set_font(family='Arial', style='', size=10)
        
        # ============ 这里必须基于DUT Level来设计专门算法, 计算出在pdf报告中的Total, Fail, Yield rate这3个值
        if not os.path.isfile(self.dashboard_csv):
            wx.MessageBox(message=f'Find no {self.dashboard_csv}', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return
        
        if self.Flag_1 and not self.Flag_2:
            # Total:        ①只看'Status'是'P'的行, ②且不重复的UID的个数
            # Pass:         强制等于Total
            # Fail:         强制等于0
            # Yield rate:   强制等于100%
            UID_Status = {}
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    if row['Status'] == 'P':
                        UID_Status[row[login_GUI.Index_var_custom]] = row['Status'] # 这里顺利实现重复UID的迭代更新
            
            self.Total_report      = len(UID_Status)
            pass_count             = self.Total_report
            self.Fail_report       = 0
            self.Yield_rate_report = '100%'
            
        elif self.Flag_1 and self.Flag_2:
            # Total:         看不重复的UID的个数
            # Pass：         UID的'Status'(即'P' or 'F')进行不断覆盖, 最终UID的'Status'为'P'的UID的个数
            # Fail：         Total - Pass
            # Yield rate:    Pass / Total
            UID_Status = {}
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    UID_Status[row[login_GUI.Index_var_custom]] = row['Status'] # 这里顺利实现重复UID的迭代更新
            
            self.Total_report      = len(UID_Status)
            pass_count             = list(UID_Status.values()).count('P')
            self.Fail_report       = self.Total_report - pass_count
            the_Yield              = pass_count/self.Total_report
            self.Yield_rate_report = reserved_percent[login_GUI.n_digit_custom].format(the_Yield).replace('.'+'0'*login_GUI.n_digit_custom,'')
        
        elif not self.Flag_1 and not self.Flag_2:
            # Total:        只看UID的'Status'为'P'的行数
            # Pass:         强制等于Total
            # Fail:         强制等于0
            # Yield rate:   强制等于100%
            pass_count = 0
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    if row['Status'] == 'P':
                        pass_count += 1
            
            self.Total_report      = pass_count
            pass_count             = self.Total_report
            self.Fail_report       = 0
            self.Yield_rate_report = '100%'
        
        elif not self.Flag_1 and self.Flag_2:
            # Total:        看UID的'Status'为'P'和'F'的总行数
            # Pass:         看UID的'Status'为'P'的行数
            # Fail:         看UID的'Status'为'F'的行数
            # Yield rate:   Pass / Total
            pass_count = 0
            fail_count = 0
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    if row['Status'] == 'P':
                        pass_count += 1
                    elif row['Status'] == 'F':
                        fail_count += 1
            self.Total_report      = pass_count + fail_count
            self.Fail_report       = fail_count
            the_Yield              = pass_count/self.Total_report
            self.Yield_rate_report = reserved_percent[login_GUI.n_digit_custom].format(the_Yield).replace('.'+'0'*login_GUI.n_digit_custom,'')
            
        pdf_obj.cell(w=60, h=5, txt=str(self.Total_report),      border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=5, txt=str(self.Fail_report),       border=flag_border, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=60, h=5, txt=str(self.Yield_rate_report), border=flag_border, ln=0, align='', fill=0, link='')
        
        # ======================== 然后, 另起一页，放入汇总的表格
        pdf_obj.add_page()
        pdf_obj.set_font(family='Arial', style='B', size=10)
        pdf_obj.cell(w=10, h=6, txt='No.',       border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=40, h=6, txt='Item',      border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=25, h=6, txt='LSL / USL', border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=30, h=6, txt='Min / Max', border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=15, h=6, txt='Avg.',      border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=15, h=6, txt='Std.',      border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=15, h=6, txt='CP',        border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=15, h=6, txt='CA',        border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=15, h=6, txt='CPK',       border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=15, h=6, txt='Count',     border=1, ln=1, align='', fill=0, link='')
        
        # 注意: 这里此时, 必须把字体设置成不加粗, 否则会报如下错误。 根因是数值中若有无穷大符号(∞),不支持加粗编码。
        # UnicodeEncodeError: 'latin-1' codec can't encode character '\u221e' in position 1173: ordinal not in range(256)
        pdf_obj.set_font(family='Arial', style='', size=8)
        for m, one_item_result in enumerate(self.table_data, 1):
            pdf_obj.cell(w=10, h=6, txt=one_item_result[0], border=1, ln=0, align='', fill=0, link='')
            pdf_obj.cell(w=40, h=6, txt=one_item_result[1], border=1, ln=0, align='', fill=0, link='')
            pdf_obj.cell(w=25, h=6, txt=one_item_result[2], border=1, ln=0, align='', fill=0, link='')
            pdf_obj.cell(w=30, h=6, txt=one_item_result[3], border=1, ln=0, align='', fill=0, link='')
            pdf_obj.cell(w=15, h=6, txt=one_item_result[4], border=1, ln=0, align='', fill=0, link='')
            
            final_Std = one_item_result[5]
            if final_Std == 'nan':
                final_Std = ''
            elif final_Std == 'inf':
                final_Std = '∞'
            elif final_Std == '-inf':
                final_Std = '-∞'
            pdf_obj.cell(w=15, h=6, txt=final_Std,          border=1, ln=0, align='', fill=0, link='')
            
            final_Cp = one_item_result[6]
            if final_Cp == 'nan':
                final_Cp = ''
            elif final_Cp == 'inf':
                final_Cp = '∞'
            elif final_Cp == '-inf':
                final_Cp = '-∞'
            pdf_obj.cell(w=15, h=6, txt=final_Cp,           border=1, ln=0, align='', fill=0, link='')
            
            pdf_obj.cell(w=15, h=6, txt=one_item_result[7], border=1, ln=0, align='', fill=0, link='')
            
            final_Cpk = one_item_result[8]
            if final_Cpk == 'nan':                          # float('nan') < 1.33, ==> False
                final_Cpk = ''                              # 特别注意: float('') < 1.33, ==> 报错: ValueError: could not convert string to float: ''
            elif final_Cpk == 'inf':                        # float('inf') < 1.33, ==> False
                final_Cpk = '∞'                             # 特别注意: float('∞') < 1.33, ==> 报错: ValueError: could not convert string to float: '∞'
            elif final_Cpk == '-inf':                       # float('-inf') < 1.33, ==> True
                final_Cpk = '-∞'                            # 特别注意: float('-∞') < 1.33, ==> 报错: ValueError: could not convert string to float: '-∞'
            if login_GUI.mark_color_custom and final_Cpk != 'Empty':
                if float(one_item_result[8]) < 1.33:
                    pdf_obj.set_text_color(r=255, g=0, b=0)
                    pdf_obj.cell(w=15, h=6, txt=final_Cpk,      border=1, ln=0, align='', fill=0, link='')
                    pdf_obj.set_text_color(r=0, g=0, b=0)
                else:
                    pdf_obj.cell(w=15, h=6, txt=final_Cpk,      border=1, ln=0, align='', fill=0, link='')
            else:
                pdf_obj.cell(w=15, h=6, txt=final_Cpk,      border=1, ln=0, align='', fill=0, link='')
                
            pdf_obj.cell(w=15, h=6, txt=one_item_result[9], border=1, ln=1, align='', fill=0, link='')            
            
        # ======================== 接着, 另起一页，放入汇总的 ±7σ
        pdf_obj.add_page()
        pdf_obj.set_font(family='Arial', style='B', size=10)
        pdf_obj.cell(w=10, h=6, txt='No.',  border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=40, h=6, txt='Item', border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='-7',   border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='-6',   border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='-5',   border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='-4',   border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='-3',   border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='-2',   border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='-1',   border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='0',    border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='1',    border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='2',    border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='3',    border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='4',    border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='5',    border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='6',    border=1, ln=0, align='', fill=0, link='')
        pdf_obj.cell(w=9,  h=6, txt='7',    border=1, ln=1, align='', fill=0, link='')
        
        pdf_obj.set_font(family='Arial', style='', size=8)
        for m, one_item_result in enumerate(self.table_data, 1):
            pdf_obj.cell(w=10, h=6, txt=one_item_result[0], border=1, ln=0, align='', fill=0, link='')
            pdf_obj.cell(w=40, h=6, txt=one_item_result[1], border=1, ln=0, align='', fill=0, link='')
            if one_item_result[3] == 'Empty / Empty':
                pdf_obj.set_fill_color(r=220, g=53, b=69)
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=1, align='', fill=1, link='') 
            else:
                # -7
                pdf_obj.set_fill_color(r=int(one_item_result[-15][0][1:3],16), g=int(one_item_result[-15][0][3:5],16), b=int(one_item_result[-15][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # -6
                pdf_obj.set_fill_color(r=int(one_item_result[-14][0][1:3],16), g=int(one_item_result[-14][0][3:5],16), b=int(one_item_result[-14][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # -5
                pdf_obj.set_fill_color(r=int(one_item_result[-13][0][1:3],16), g=int(one_item_result[-13][0][3:5],16), b=int(one_item_result[-13][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # -4
                pdf_obj.set_fill_color(r=int(one_item_result[-12][0][1:3],16), g=int(one_item_result[-12][0][3:5],16), b=int(one_item_result[-12][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # -3
                pdf_obj.set_fill_color(r=int(one_item_result[-11][0][1:3],16), g=int(one_item_result[-11][0][3:5],16), b=int(one_item_result[-11][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # -2
                pdf_obj.set_fill_color(r=int(one_item_result[-10][0][1:3],16), g=int(one_item_result[-10][0][3:5],16), b=int(one_item_result[-10][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # -1
                pdf_obj.set_fill_color(r=int(one_item_result[-9][0][1:3],16), g=int(one_item_result[-9][0][3:5],16), b=int(one_item_result[-9][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # 0
                pdf_obj.set_fill_color(r=int(one_item_result[-8][0][1:3],16), g=int(one_item_result[-8][0][3:5],16), b=int(one_item_result[-8][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # 1
                pdf_obj.set_fill_color(r=int(one_item_result[-7][0][1:3],16), g=int(one_item_result[-7][0][3:5],16), b=int(one_item_result[-7][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # 2
                pdf_obj.set_fill_color(r=int(one_item_result[-6][0][1:3],16), g=int(one_item_result[-6][0][3:5],16), b=int(one_item_result[-6][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # 3
                pdf_obj.set_fill_color(r=int(one_item_result[-5][0][1:3],16), g=int(one_item_result[-5][0][3:5],16), b=int(one_item_result[-5][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # 4
                pdf_obj.set_fill_color(r=int(one_item_result[-4][0][1:3],16), g=int(one_item_result[-4][0][3:5],16), b=int(one_item_result[-4][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # 5
                pdf_obj.set_fill_color(r=int(one_item_result[-3][0][1:3],16), g=int(one_item_result[-3][0][3:5],16), b=int(one_item_result[-3][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # 6
                pdf_obj.set_fill_color(r=int(one_item_result[-2][0][1:3],16), g=int(one_item_result[-2][0][3:5],16), b=int(one_item_result[-2][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=0, align='', fill=1, link='')
                
                # 7
                pdf_obj.set_fill_color(r=int(one_item_result[-1][0][1:3],16), g=int(one_item_result[-1][0][3:5],16), b=int(one_item_result[-1][0][5:7],16))
                pdf_obj.cell(w=9, h=6, txt='', border=1, ln=1, align='', fill=1, link='')
                
        # ======================== 最后, 另起一页，放入每个测项的子结果和子直方图
        pdf_obj.set_fill_color(r=62, g=79, b=111)
        for n, each_hist in enumerate(self.all_histogram, 0):
            if n%2 == 0:
                pdf_obj.add_page()
            for key, value in each_hist.items():
                image_saved = os.path.join(self.temp_folder, f'{key}.jpg')
                if os.path.isfile(image_saved):
                    if n%2 != 0: # 空出40mm的高度, A4纸:210mm×297mm
                        pdf_obj.ln(h=40)
                    pdf_obj.set_font(family='Arial', style='B', size=16)
                    pdf_obj.set_text_color(r=255, g=255, b=255)
                    pdf_obj.cell(w=190, h=12, txt=key, border=0, ln=1, align='', fill=1, link='')
                    pdf_obj.ln(h=3)
                    pdf_obj.set_text_color(r=0, g=0, b=0)
                    pdf_obj.set_font(family='Arial', style='B', size=14)
                    pdf_obj.cell(w=50, h=10, txt='Spec', border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.set_font(family='Arial', style='', size=12)
                    pdf_obj.cell(w=50, h=5, txt=f'LSL:{12*" "}{self.table_data[n][2].split("/")[0].strip()}',border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.cell(w=50, h=5, txt=f'USL:{12*" "}{self.table_data[n][2].split("/")[1].strip()}',border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.set_font(family='Arial', style='B', size=14)
                    pdf_obj.cell(w=50, h=10, txt='Result', border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.set_font(family='Arial', style='', size=12)
                    pdf_obj.cell(w=50, h=5, txt=f'Min:{12*" "}{self.table_data[n][3].split("/")[0].strip()}',border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.cell(w=50, h=5, txt=f'Max:{11*" "}{self.table_data[n][3].split("/")[1].strip()}',border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.cell(w=50, h=5, txt=f'Avg:{12*" "}{self.table_data[n][4]}',border=0, ln=1, align='', fill=0, link='')
                    this_Std = self.table_data[n][5]
                    if this_Std == 'nan':
                        this_Std = ''
                    elif this_Std == 'inf':
                        this_Std = '∞'
                    elif this_Std == '-inf':
                        this_Std = '-∞'
                    pdf_obj.cell(w=50, h=5, txt=f'Std:{12*" "}{this_Std}', border=0, ln=1, align='', fill=0, link='')
                    this_ld = self.table_data[n][10]
                    if this_ld == 'nan':
                        this_ld = ''
                    elif this_ld == 'inf':
                        this_ld = '∞'
                    elif this_ld == '-inf':
                        this_ld = '-∞'
                    pdf_obj.cell(w=50, h=5, txt=f'-3d:{12*" "}{this_ld}', border=0, ln=1, align='', fill=0, link='')
                    this_rd = self.table_data[n][11]
                    if this_rd == 'nan':
                        this_rd = ''
                    elif this_rd == 'inf':
                        this_rd = '∞'
                    elif this_rd == '-inf':
                        this_rd = '-∞'
                    pdf_obj.cell(w=50, h=5, txt=f'+3d:{11*" "}{this_rd}', border=0, ln=1, align='', fill=0, link='')
                    this_Cp = self.table_data[n][6]
                    if this_Cp == 'nan':
                        this_Cp = ''
                    elif this_Cp == 'inf':
                        this_Cp = '∞'
                    elif this_Cp == '-inf':
                        this_Cp = '-∞'
                    pdf_obj.cell(w=50, h=5, txt=f'Cp:{13*" "}{this_Cp}',              border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.cell(w=50, h=5, txt=f'Ca:{13*" "}{self.table_data[n][7]}',border=0, ln=1, align='', fill=0, link='')
                    this_Cpk = self.table_data[n][8]
                    if this_Cpk == 'nan':
                        this_Cpk = ''
                    elif this_Cpk == 'inf':
                        this_Cpk = '∞'
                    elif this_Cpk == '-inf':
                        this_Cpk = '-∞'
                    pdf_obj.cell(w=50, h=5, txt=f'Cpk:{11*" "}{this_Cpk}',               border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.cell(w=50, h=5, txt=f'Pass:{10*" "}{self.table_data[n][12]}',border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.cell(w=50, h=5, txt=f'Fail:{12*" "}{self.table_data[n][13]}',border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.cell(w=50, h=5, txt=f'Yield Rate: {self.table_data[n][14]}',border=0, ln=1, align='', fill=0, link='')
                    pdf_obj.image(name=image_saved, x=55, y=25 if n%2 == 0 else 170, w=150, h=100)
        pdf_obj.ln(h=10)
        pdf_obj.cell(w=190, h=5, txt=f"{'-'*24} LOGITECH CONFIDENTIAL {'-'*24}", border=0, ln=0, align='C', fill=0, link='https://www.logitech.com')
        now_time    = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        pdf_file    = f'Analytics_Report_{list(set(self.Project_report))[0]}_{list(set(self.Station_report))[0]}_{list(set(self.Stage_report))[0]}_{now_time}.pdf'
        report_file = os.path.join(script_abspath, pdf_file)
        pdf_obj.output(name=report_file, dest='')
        pdf_obj.close() # Terminate document
        #wx.MessageBox(message=f'[Done] Export pdf file\n\n{report_file}', caption='Success', style=wx.ICON_INFORMATION, parent=self)
        dlg_Question = wx.MessageDialog(parent=self, message=f'Do you need view pdf file now?\n\n{report_file}', caption='Successfully Exported', style=wx.ICON_INFORMATION|wx.YES_NO)
        res = dlg_Question.ShowModal()
        if res == wx.ID_YES:
            if os.path.isfile(report_file):
                win32api.ShellExecute(0, 'open', report_file, '', '', 1)
        elif res == wx.ID_NO:
            pass
        dlg_Question.Destroy()
        
    def check_box_1_FCT(self, event):
        print('Flag_1:', self.check_box_1.GetValue())
        
    def check_box_2_FCT(self, event):
        print('Flag_2:', self.check_box_2.GetValue())
        
    def slider_FCT(self, event):
        print('Interval_user:', self.slider.GetValue())
    
    def CheckBox_all_FCT(self, event):
        self.checkBox_special.SetValue(state=False)
        now_value = self.checkBox_all.GetValue()
        if now_value:
            self.var_options.SetCheckedItems(indexes=[i for i in range(self.var_options.GetCount())])
            self.final_var_options = self.var_options.GetCheckedStrings()
            print('User Clicked [Select all], final_var_options:', self.final_var_options, sep='\n', end='\n\n')
        else:
            for i in range(self.var_options.GetCount()):
                self.var_options.Check(item=i, check=False)
            self.final_var_options = self.var_options.GetCheckedStrings()
            print('User unclicked [Select all], final_var_options:', self.final_var_options, sep='\n', end='\n\n')
            
    def CheckBox_special_FCT(self, event):
        self.checkBox_all.SetValue(state=False)
        now_value = self.checkBox_special.GetValue()
        if now_value:
            for i in range(self.var_options.GetCount()):
                if self.var_options.GetString(n=i).startswith('#'):
                    self.var_options.Check(item=i, check=True)
                else:
                    self.var_options.Check(item=i, check=False)
            self.final_var_options = self.var_options.GetCheckedStrings()
            print('User Clicked [Select #var only], final_var_options:', self.final_var_options, sep='\n', end='\n\n')
        else:
            for i in range(self.var_options.GetCount()):
                if self.var_options.GetString(n=i).startswith('#'):
                    self.var_options.Check(item=i, check=False)
            self.final_var_options = self.var_options.GetCheckedStrings()
            print('User unclicked [Select #var only], final_var_options:', self.final_var_options, sep='\n', end='\n\n')
            
    def checkListBox_click_box(self, event):     # 只有手动用鼠标点击方框, 才会触发.
        self.final_var_options = self.var_options.GetCheckedStrings()
        print('User clicked [Box], final_var_options:', self.final_var_options, sep='\n', end='\n\n')
        if len(self.final_var_options) == len(self.vars_with_L_U):
            self.checkBox_all.SetValue(state=True)
        else:
            self.checkBox_all.SetValue(state=False)
        
        for each_item in self.final_var_options:
            if not each_item.startswith('#'):
                self.checkBox_special.SetValue(state=False)
                break
            
    def checkListBox_click_text(self, event):   # 只有手动用鼠标点击文本, 才会触发.
        this_n    = self.var_options.GetSelection()
        this_flag = self.var_options.IsChecked(item=this_n)
        if this_flag:
            self.var_options.Check(item=this_n, check=False)
        else:
            self.var_options.Check(item=this_n, check=True)
        self.var_options.Deselect(n=this_n) # 让文本永远不会有选中的痕迹
        
        self.final_var_options = self.var_options.GetCheckedStrings()
        print('User clicked [Text], final_var_options:', self.final_var_options, sep='\n', end='\n\n')
        if len(self.final_var_options) == len(self.vars_with_L_U):
            self.checkBox_all.SetValue(state=True)
        else:
            self.checkBox_all.SetValue(state=False)
            
        for each_item in self.final_var_options:
            if not each_item.startswith('#'):
                self.checkBox_special.SetValue(state=False)
                break
                
    def get_vars_with_latest_LSL_USL(self, LOG_folder, LOG_csv:list, specfied_var): 
        # 返回示例：True, {'S_Force_L': ('-3', '3'), '#OP_Force_L': ('35', '85'), ...}
        # 注意理解: 通过这个函数得到的 full_vars_with_limits 来源于原csv文件的最后一次出现的眉头(fieldnames)
        
        # ------------------------ 处理 LOG_csv 的所有原始文件, 生成若干个干净的子csv
        full_vars_with_limits = {} # 漂亮, {var1:(L,U), var2:(L,U), ...},其实这就是新生成的干净的子csv的fieldnames
        final_vars_with_limits      = {}
        self.errorCode_fieldName = {'E-00000':'process fail'}
        
        # 注意理解: 如下, 若parent=self, 会导致两个Bug:
        # (1) wx.MessageBox 变成"非模态的弹窗"
        # (2)可能滞后出现时被用户点击[OK]的Bug
        dlg_extract = wx.ProgressDialog(title='Reading Original CSV File(s)', message=f'Reading original *.csv: 0/{len(LOG_csv)}', maximum=len(LOG_csv), parent=None, style=wx.PD_AUTO_HIDE)
        
        # ------------------------ 正式读取每一个原本的csv文件
        for x, each_subCSV in enumerate(LOG_csv, 1):
            dlg_extract.Update(value=x-1, newmsg=f'Reading original *.csv: {x}/{len(LOG_csv)}\n\n{os.path.split(each_subCSV)[1]}')
            if len(LOG_csv) == 1:
                dlg_extract.Pulse() #进度条不确定模式
            base_name         = os.path.basename(each_subCSV)
            csv_name          = os.path.splitext(base_name)[0]
            LOG_temp_data     = []
            count_pure_subCSV = 0
            
            # 特别注意：下面的 reader 是一个iterator, 若是标准的空csv文件,则结果是[[]], 若是完全的空文件,则结果是[]; 若不为空, 则结果是[['R1C1', 'R1C2', 'R1C3'],['R2C1', 'R2C2', 'R2C3'], ...]
            try:
                with open(file=each_subCSV, mode='r', encoding=get_encoding(each_subCSV)) as f_obj:
                    reader      = csv.reader(f_obj)
                    reader_list = list(reader)
            except:
                dlg_extract.Destroy()
                try_crash_error = traceback.format_exc()
                self.Extracting.SetLabel(f'Warning: Error occurs when reading original csv file,\n{base_name}')
                wx.MessageBox(message=f'{base_name}\n\n{try_crash_error}', caption='myWarning', style=wx.ICON_WARNING, parent=self)
                return False, {}    # 提前终止
            
            # print('reader_list:', reader_list)
            print(f'{"="*20}> [Read Original CSV Done]: {base_name}')

            if reader_list in ([], [[]]): # 注意: 这是含有两个元素的元组
                dlg_extract.Destroy()
                self.Extracting.SetLabel('')
                self.Extracting.SetLabel(f'Warning: Find it empty.')
                wx.MessageBox(message=f'Find it empty in below file\n\n{each_subCSV}', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return False, {} # 提前终止
            
            # 检查每个原始csv文件的第一行是否符合UTS1或UTS2的标准"列名"格式
            fieldnameLine = reader_list[0]
            if any([','.join(fieldnameLine).startswith(self.UTS1_format_str),
                    ','.join(fieldnameLine).startswith(self.UTS1_format_str_old),
                    ','.join(fieldnameLine).startswith(self.UTS2_format_str)]):
                pass
            else:
                dlg_extract.Destroy()
                self.UTS_standard_format.SetLabel(f'UTS1 standard fieldnames format:\n{self.UTS1_format_str}\n\nUTS2 standard fieldnames format:\n{self.UTS2_format_str}')
                self.Extracting.SetLabel(f'Warning: Find the fieldnames in line-1,\nmeet neither UTS1 nor UTS2 standard format.')
                wx.MessageBox(message=f'Find the fieldnames in line-1 meet neither UTS1 nor UTS2 standard format in below csv file\n\n{each_subCSV}', caption='Warning', style=wx.ICON_WARNING, parent=self)
                return False, {} # 提前终止
                
            # ------------------------ 不允许用户同时导入UTS1和UTS2两种格式的csv文件
            if reader_list[0][4] == 'ErrorCode': # 这里兼容UTS1, 其眉头没有'ErrorCode'这个fieldname
                if self.UTS2_format == None:
                    self.UTS2_format = True
                else:
                    if not self.UTS2_format:
                        dlg_extract.Destroy()
                        self.Extracting.SetLabel(f'Warning: Different format of *.csv detected')
                        wx.MessageBox(message='Different format of *.csv detected\n\nYou are not allowed to import different format of *.csv at the same time', caption='Warning', style=wx.ICON_WARNING, parent=self)
                        return False, {}   # 提前终止
            else:
                if self.UTS2_format == None:
                    self.UTS2_format = False
                else:
                    if self.UTS2_format:
                        dlg_extract.Destroy()
                        self.Extracting.SetLabel(f'Warning: Different format of *.csv detected')
                        wx.MessageBox(message='Different format of *.csv detected\n\nYou are not allowed to import different format of *.csv at the same time', caption='Warning', style=wx.ICON_WARNING, parent=self)
                        return False, {}   # 提前终止
            
            # ------------------------ 正式读取一个原本csv的每一行
            for n, each_row in enumerate(reader_list,0):
                if each_row[0] == 'SeqNum': # each_row => 每一行数据的列表
                    if self.UTS2_format:    # 检查当前这一个原始csv文件以'SeqNum'打头的每一行是否符合UTS2的标准"列名"格式
                        if ','.join(each_row).startswith(self.UTS2_format_str):
                            pass
                        else:
                            dlg_extract.Destroy()
                            self.UTS_standard_format.SetLabel(f'UTS2 standard fieldnames format:\n{self.UTS2_format_str}')
                            self.Extracting.SetLabel(f'Warning: Find the fieldnames in line-{n+1},\ndo not meet UTS2 standard format.')
                            wx.MessageBox(message=f'Find the fieldnames in line-{n+1} do not meet UTS2 standard format in below csv file\n\n{each_subCSV}', caption='Warning', style=wx.ICON_WARNING, parent=self)
                            return False, {} # 提前终止
                    else:   # 检查当前这一个原始csv文件以'SeqNum'打头的每一行是否符合UTS1的标准"列名"格式
                        if any([','.join(fieldnameLine).startswith(self.UTS1_format_str),
                                ','.join(fieldnameLine).startswith(self.UTS1_format_str_old)]):
                            pass
                        else:
                            dlg_extract.Destroy()
                            self.UTS_standard_format.SetLabel(f'UTS1 standard fieldnames format:\n{self.UTS1_format_str}')
                            self.Extracting.SetLabel(f'Warning: Find the fieldnames in line-{n+1},\ndo not meet UTS1 standard format.')
                            wx.MessageBox(message=f'Find the fieldnames in line-{n+1} do not meet UTS1 standard format in below csv file\n\n{each_subCSV}', caption='Warning', style=wx.ICON_WARNING, parent=self)
                            return False, {} # 提前终止
                    
                    if count_pure_subCSV == 0:  #'SeqNum' 在第一次出现时, 不执行保存.
                        pass
                    else:
                        #the_num = f'0{count_pure_subCSV}' if count_pure_subCSV < 10 else count_pure_subCSV
                        the_num = '{:02d}'.format(count_pure_subCSV)
                        saved_file = os.path.join(LOG_folder, f'{csv_name}_pure_{the_num}.csv')
                        # ------------ 特别注意: 这里当且仅当 'SeqNum' 在第二次出现时, 才会执行, 它将上一次的log保存起来在 pure 文件里
                        with open(file=saved_file, mode='w', encoding='utf-8', newline='') as csvfile:
                            writer = csv.writer(csvfile)
                            fieldname_pure = LOG_temp_data[0]
                            if not self.UTS2_format:            # 这里兼容UTS1, 老版本UTS1眉头有空格:['SeqNum',' Status',' Comment',' Test_Start_Time',' Test_Duration',' Failed_Tests']
                                for x in range(1,6,1):
                                    fieldname_pure[x] = fieldname_pure[x].lstrip()
                            writer.writerow(fieldname_pure)     # 注意: 这里是 writerow
                            writer.writerows(LOG_temp_data[1:]) # 注意: 这里是 writerows
                    LOG_temp_data = []
                    LOG_temp_data.append(each_row)
                    count_pure_subCSV += 1
                    # ------------ 顺便每次覆盖更新 full_vars_with_limits 这个字典
                    L_row = reader_list[n+3]
                    L_row.append('')            # 这里兼容UTS1, 其生成在本地盘的*csv的 L 行比眉头行少了一个逗号. 若这里不添加则下面的第2660行就会报错: IndexError: list index out of range
                    U_row = reader_list[n+2]
                    U_row.append('')            # 这里兼容UTS1, 其生成在本地盘的*csv的 U 行比眉头行少了一个逗号. 若这里不添加则下面的第2660行就会报错: IndexError: list index out of range
                    
                    # ------------ 提取 full_vars_with_limits, errorCode_fieldName
                    for i, j in enumerate(each_row, 0):
                        full_vars_with_limits[j] = (L_row[i], U_row[i])         # UTS1和UTS2, 都会提取full_vars_with_limits.
                        if self.UTS2_format:                                    # UTS2, 会统计errorCode对应的fieldName, 服务于Dasgboard上的"Top 5 error code".
                            E_row = reader_list[n+4]
                            if len(E_row) >= len(each_row):    
                                self.errorCode_fieldName[E_row[i]] = j          # 非常精彩
                                
                    # ------------ 提取数据为[项目概览] Overview 的面板
                    if len(reader_list[n+1]) >= 3:                                          # UTS1和UTS2, 只要存放"日期"的那个单元格不为空, 都会把"日期"提取出来. 
                        if len(reader_list[n+1][2].split()) >= 1:                           # 特别注意: len(''.split()) = 0, 而''.split()[0]会报错: IndexError: list index out of range.
                            self.Date_range_report.append(reader_list[n+1][2].split()[0])   # 一个csv文件每出现一次眉头, 这个值就会叠加到列表里, 最终用set集合来去重。
                    if self.UTS2_format:
                        if len(reader_list[n+7]) >= 7:    
                            self.Business_unit_report.append(reader_list[n+7][2])           # 一个csv文件每出现一次眉头, 这个值就会叠加到列表里, 最终用set集合来去重。
                            self.Project_report.append(reader_list[n+7][3])                 # 一个csv文件每出现一次眉头, 这个值就会叠加到列表里, 最终用set集合来去重。
                            self.Station_report.append(reader_list[n+7][4])                 # 一个csv文件每出现一次眉头, 这个值就会叠加到列表里, 最终用set集合来去重。
                            self.Stage_report.append(reader_list[n+7][5])                   # 一个csv文件每出现一次眉头, 这个值就会叠加到列表里, 最终用set集合来去重。
                            self.Data_source_report.append(reader_list[n+7][6])             # 一个csv文件每出现一次眉头, 这个值就会叠加到列表里, 最终用set集合来去重。
                    else:
                        self.Business_unit_report.append('NA')  # UTS1, Not Applicable.此项强制为不适用.
                        self.Project_report.append('NA')        # UTS1, Not Applicable.此项强制为不适用.
                        self.Station_report.append('NA')        # UTS1, Not Applicable.此项强制为不适用.
                        self.Stage_report.append('NA')          # UTS1, Not Applicable.此项强制为不适用.
                        self.Data_source_report.append('NA')    # UTS1, Not Applicable.此项强制为不适用.
                else:
                    LOG_temp_data.append(each_row)
            # ------------ 特别注意: (对于每个原本的子csv log)这里一共仅仅执行了一次, 是将最后一次的log保存起来在 pure 文件里
            if LOG_temp_data:
                #the_num = f'0{count_pure_subCSV}' if count_pure_subCSV < 10 else count_pure_subCSV
                the_num = '{:02d}'.format(count_pure_subCSV)
                saved_file = os.path.join(LOG_folder, f'{csv_name}_pure_{the_num}.csv')
                with open(file=saved_file, mode='w', encoding='utf-8', newline='') as csvfile:
                    writer = csv.writer(csvfile)
                    fieldname_pure = LOG_temp_data[0]
                    if not self.UTS2_format:            # 这里兼容UTS1, 老版本UTS1眉头有空格:['SeqNum',' Status',' Comment',' Test_Start_Time',' Test_Duration',' Failed_Tests']
                        for x in range(1,6,1):
                            fieldname_pure[x] = fieldname_pure[x].lstrip()
                    writer.writerow(fieldname_pure)     # 注意: 这里是 writerow
                    writer.writerows(LOG_temp_data[1:]) # 注意: 这里是 writerows
        dlg_extract.Destroy()
        print('') # 换行
        print(full_vars_with_limits)
        print('====================> [Above]: full_vars_with_limits', end='\n\n')
        
        if '' in self.errorCode_fieldName:  # 注意:'Status'列的'E'行, 这行开头的有8个空格.
            del self.errorCode_fieldName['']
            
        # ======> 确保存在"UID" (即 specfied_var)列
        # 注意:由于变量取的是并集的效果,下方这句话只能确保LOG中所有的子csv汇总后, 是有 "UID" (即 specfied_var)列
        if not specfied_var in full_vars_with_limits.keys():
            self.Extracting.SetLabel(f'Warning: Find no field name "{specfied_var}"')
            while 1:
                dlg = wx.SingleChoiceDialog(self, message=f'Find no field name "{specfied_var}" in all original csv file(s).\n\nNow you can try the following variable:', caption='Single Choice', choices=login_GUI.var_choices)
                res = dlg.ShowModal()
                dlg.Destroy()
                if res == wx.ID_OK:
                    specfied_var = dlg.GetStringSelection()
                    print(specfied_var)
                    if specfied_var in full_vars_with_limits.keys():
                        self.Extracting.SetLabel(f'Congratulation: Now find field name "{specfied_var}"')
                        login_GUI.Index_var_custom = specfied_var   # 强制改变一开始默认的自定义索引变量
                        self.SetTitle(f'{app_name}({latest_ver})    Algorithm: {login_GUI.algorithm_Hist_custom}    Index: {login_GUI.Index_var_custom}')
                        break
                    else:
                        self.Extracting.SetLabel(f'Warning: Find no field name "{specfied_var}"')
                        wx.MessageBox(message=f'Sorry, still find no field name "{specfied_var}" in all original csv file(s)\n\n' + '\n\n'.join(LOG_csv), caption='Warning', style=wx.ICON_WARNING, parent=self)
                        # return False, {}    # 提前终止 
                elif res == wx.ID_CANCEL:
                    # print(res, 'User pressed button [取消]|[关闭]')
                    return False, {}    # 提前终止
            
        # ======> 这里筛选出带有双边Limit且LSL和USL不相等的测试变量
        for key, value in full_vars_with_limits.items():
            if all([value[0], value[1]]) and value[0]!= value[1]:
                final_vars_with_limits[key] = value
        
        # ======> 这里给编程开发者便利, 在列表['Status', ' Status',]可以自由添加若干需要规避的变量
        for invalid_var in ['Status', ' Status',]:
            if invalid_var in final_vars_with_limits:
                del final_vars_with_limits[invalid_var]
                                       
        # ======> 这里捕捉异常: 
        # (1)UTS2, 用户用Excel强制更改产生的csv, 会出现上下限提取异常:{'#RF_P_2G402': ('E-EEFEE', '-20'), '#Offset_2G402': ('E-2B83A', '-28'),...}
        # (2)UTS1, csv里的变量带有虽然不相等但非全数字的双边Limit, 列如 Lantau-Mouse_BON, RCV_FWVer: [F013, 9999].
        var_to_del = {}
        for per_var, per_limit in final_vars_with_limits.items():
            try:
                limit_L = float(per_limit[0])
                limit_U = float(per_limit[1])
            except ValueError:
                try_crash_error = traceback.format_exc()
                self.Extracting.SetLabel(f'Warning:\n{try_crash_error}')
                var_to_del[per_var] = f'[{per_limit[0]}, {per_limit[1]}]'
        
        if var_to_del:
            show_str = ''
            for key, value in var_to_del.items():
                show_str += f'{key}: {value}\n' 
                
            wx.MessageBox(message=f'Below suspected variable with its limits found and will be ignored:\n\n{show_str}', caption='myWarning: ValueError', style=wx.ICON_WARNING, parent=self)
                
        for per_var in var_to_del:      # 2025.07.28 修改
            del final_vars_with_limits[per_var]
        
        # ======> 这里确认可以支持数据分析的最终变量不为空
        if final_vars_with_limits:
            print(final_vars_with_limits)
            print('====================> [Above]: final_vars_with_limits (vars with latest unequal_L_U limits)', end='\n\n')
            if self.UTS2_format:
                self.SetTitle(f'{app_name}({latest_ver})    Algorithm: {login_GUI.algorithm_Hist_custom}    Index: {login_GUI.Index_var_custom}    Current_CSV_Format: UTS2')
            else:
                self.SetTitle(f'{app_name}({latest_ver})    Algorithm: {login_GUI.algorithm_Hist_custom}    Index: {login_GUI.Index_var_custom}    Current_CSV_Format: UTS1')
            return True, final_vars_with_limits
        else:
            self.Extracting.SetLabel('Warning: Extract no valid variable')
            wx.MessageBox(message='Extract no valid variable in all original csv file(s)\n\n' + '\n\n'.join(LOG_csv), caption='myWarning', style=wx.ICON_WARNING, parent=self) # wx.ICON_WARNING 警告
            return False, {}
            
    def get_data_UniqueUID_ExcludeDefect(self, LOG_folder, known_vars_with_limits, specfied_var, savedCSV='UniqueUID_ExcludeDefect.csv'):
        """执行此函数后，将生成文件夹: 03_LOG_filter"""
        # 返回示例：True, {'UID1': {'S_Force_L': '0.063', '#OP_Force_L': '65.827'}, 'UID2': {'S_Force_L': '0.315', '#OP_Force_L': '61.224'}}
        
        # ------------------------ 重读 01_LOG_pure 文件夹下每个干净的子csv
        data_LOG = {}
        all_pure_subCSV = os.listdir(LOG_folder)
        all_pure_subCSV.sort()
        dlg_pure = wx.ProgressDialog(title='Reading Pure CSV File(s)', message=f'Reading pure *.csv: 0/{len(all_pure_subCSV)}', maximum=len(all_pure_subCSV), parent=None, style=wx.PD_AUTO_HIDE)
        for m, each_pure_subCSV in enumerate(all_pure_subCSV, 1):
            dlg_pure.Update(value=m, newmsg=f'Reading pure *.csv: {m}/{len(all_pure_subCSV)}\n\n{each_pure_subCSV}')
            the_file = os.path.join(LOG_folder, each_pure_subCSV)
            print('读取:', the_file)
            with open(file=the_file, mode='r', encoding='utf-8') as preread_obj:
                reader = csv.reader(preread_obj)
                read_1 = list(reader)
            # 注意: 这里必须确保当前这个干净的子csv里有 "UID" (即 specfied_var)列, 向下继续执行才是有意义的.
            if specfied_var in read_1[0]:
                with open(file=the_file, mode='r', encoding='utf-8') as read_obj:
                    rows = csv.DictReader(read_obj)
                    for each_row in rows:
                        UID_row = each_row[specfied_var]
                        
                        if not login_GUI.empty_UID_included:
                            if not UID_row:
                                continue
                        
                        DUT_Status = each_row['Status']
                        if DUT_Status in ['P','F']:                                         # 只关注在当前这个干净子csv文件里Status列为['P','F']
                            if UID_row not in data_LOG: data_LOG[UID_row] = {}              # e.g. {'UID1':{}, 'UID2':{}, ...}, 这里顺便实现了重复UID的覆盖.
                            data_LOG[UID_row]['Status'] = DUT_Status
                            for each_var in known_vars_with_limits.keys():                  # 只关注已知的变量
                                each_var_L = known_vars_with_limits[each_var][0]            # str
                                each_var_U = known_vars_with_limits[each_var][1]            # str
                                if each_var not in data_LOG[UID_row]:
                                    data_LOG[UID_row][each_var] = ''                        # 先预设, 造出来key
                                    data_LOG[UID_row][each_var+'_Status'] = 'OMIT'          # 先预设为'OMIT'                   
                                if each_var in each_row.keys():                             # 特别注意: 这个已知的变量在当前这个干净子csv文件里可能没有
                                    latest_value = each_row[each_var]
                                    # 继续向下, 因为是ExcludeDefect, 所以只有是在[LSL, USL]范围内的值才会被记录更新, 否则就保持预先默认写入的空值。
                                    if latest_value:                                        # 若当前最新的值是非空的
                                        try:
                                            value_float = float(latest_value)               # 则进一步确保测试保存的值是数字
                                        except ValueError:                                  # 排除是非空的字符串
                                            try_crash_error = traceback.format_exc()
                                            wx.MessageBox(message=f'{each_pure_subCSV}\n\nVariable: {each_var}\nLSL / USL: {each_var_L} / {each_var_U}\nData: {latest_value}\n\n{try_crash_error}', caption='myWarning: ValueError', style=wx.ICON_WARNING, parent=self)
                                            return False, {}    # 提前终止
                                        else:   
                                            if float(each_var_L) <= float(latest_value) <= float(each_var_U):
                                                data_LOG[UID_row][each_var] = latest_value                  # e.g.{'UID1':{'var1':'', 'var2':''}, 'UID2':{}, ...}
                                                if data_LOG[UID_row][each_var+'_Status'] == 'OMIT':
                                                    data_LOG[UID_row][each_var+'_Status'] = '1st Pass'
                                                else:
                                                    if data_LOG[UID_row][each_var+'_Status'] != '1st Pass': # 也就是说, 这里可能已经是['PASS','FAIL']
                                                        data_LOG[UID_row][each_var+'_Status'] = 'PASS'
                                            else:
                                                if data_LOG[UID_row][each_var+'_Status'] == 'OMIT':
                                                    data_LOG[UID_row][each_var+'_Status'] = 'FAIL'          # 这句话, 必须有, 'FAIL'以帮助确定第一次是否第一次是PASS的.
        dlg_pure.Destroy()
        
        if data_LOG:
            #print('data_LOG:', data_LOG, sep='\n')       
            temp_saved = os.path.join(self.filter_LOG_folder, savedCSV)
            known_vars = list(known_vars_with_limits.keys())
            fieldnames_csv = []
            for each_known_var in known_vars:
                fieldnames_csv.append(each_known_var)
                fieldnames_csv.append(each_known_var + '_Status')
            fieldnames_csv.insert(0,specfied_var)               # 漂亮: 在列表的开头插入一个元素
            fieldnames_csv.insert(1,'Status')                   # 漂亮: 在列表的开头插入一个元素
            with open(file=temp_saved, mode='w', encoding='utf-8', newline='') as write_obj:
                writer_csv = csv.DictWriter(write_obj, fieldnames=fieldnames_csv)
                writer_csv.writeheader()
                for the_key, the_dict in data_LOG.items():      # 这里的写法很好哦 ！！！
                    the_dict[specfied_var] = the_key            # 漂亮: the_dict
                    writer_csv.writerow(the_dict)               # 理解: 这里的the_dict是data_LOG的Value，而data_LOG的Value是一个字典.
            print(f'{"="*50}> [End]: data_LOG', end='\n\n')
            return True, data_LOG
        else:
            wx.MessageBox(message=f'Find no valid "UniqueUID & ExcludeDefect" data in csv file(s)', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return False, {}
    
    def get_data_UniqueUID_IncludeDefect(self, LOG_folder, known_vars_with_limits, specfied_var, savedCSV='UniqueUID_IncludeDefect.csv'):
        """执行此函数后，将生成文件夹: 03_LOG_filter"""
        # 返回示例：True, {'UID1': {'S_Force_L': '0.063', '#OP_Force_L': '65.827'}, 'UID2': {'S_Force_L': '0.315', '#OP_Force_L': '61.224'}}
        
        # ------------------------ 重读 LOG_folder 文件夹下每个干净的子csv, 只抓取每个csv中有共有变量的列而且数据PASS的行, 生成干净的 LOG?_commonVars_PASS.csv
        data_LOG = {}
        all_pure_subCSV = os.listdir(LOG_folder)
        for per_subCSV in all_pure_subCSV:
            if os.path.splitext(per_subCSV)[1].upper() != '.CSV': # 过滤掉LOG_pure目录下非.csv格式的非法缓存文件
                all_pure_subCSV.remove(per_subCSV)
        all_pure_subCSV.sort()
        dlg_pure = wx.ProgressDialog(title='Reading Pure CSV File(s)', message=f'Reading pure *.csv: 0/{len(all_pure_subCSV)}', maximum=len(all_pure_subCSV), parent=None, style=wx.PD_AUTO_HIDE)
        for m, each_pure_subCSV in enumerate(all_pure_subCSV, 1):
            dlg_pure.Update(value=m, newmsg=f'Reading pure *.csv: {m}/{len(all_pure_subCSV)}\n\n{each_pure_subCSV}')
            the_file = os.path.join(LOG_folder, each_pure_subCSV)
            print('读取:', the_file)
            with open(file=the_file, mode='r', encoding='utf-8') as preread_obj:
                reader = csv.reader(preread_obj)
                read_1 = list(reader)
            # 注意: 这里必须确保当前这个干净的子csv里有 "UID" (即 specfied_var)列, 向下继续执行才是有意义的.
            if specfied_var in read_1[0]:
                with open(file=the_file, mode='r', encoding='utf-8') as read_obj:
                    rows = csv.DictReader(read_obj)
                    for each_row in rows:
                        UID_row = each_row[specfied_var]
                        
                        if not login_GUI.empty_UID_included:
                            if not UID_row:
                                continue
                        
                        DUT_Status = each_row['Status']
                        if DUT_Status in ['P','F']:                                         # 只关注在当前这个干净子csv文件里Status列为['P','F']
                            if UID_row not in data_LOG: data_LOG[UID_row] = {}              # e.g. {'UID1':{}, 'UID2':{}, ...}, 这里顺便实现了重复UID的覆盖.
                            data_LOG[UID_row]['Status'] = DUT_Status
                            for each_var in known_vars_with_limits.keys():                  # 只关注已知的变量
                                each_var_L = known_vars_with_limits[each_var][0]            # str
                                each_var_U = known_vars_with_limits[each_var][1]            # str
                                if each_var not in data_LOG[UID_row]:
                                    data_LOG[UID_row][each_var] = ''                        # 先预设, 造出来key
                                    data_LOG[UID_row][each_var+'_Status'] = 'OMIT'          # 先预设为'OMIT'                            
                                if each_var in each_row.keys():                             # 特别注意: 这个已知的变量在当前这个干净子csv文件里可能没有
                                    latest_value = each_row[each_var]
                                    # 继续向下, 只有是数字的值才会被记录更新, 否则就保持预先默认写入的空值。
                                    if latest_value:                                        # 若当前最新的值是非空的
                                        try:
                                            value_float = float(latest_value)               # 则进一步确保测试保存的值是数字
                                        except ValueError:                                  # 排除是非空的字符串
                                            try_crash_error = traceback.format_exc()
                                            wx.MessageBox(message=f'{each_pure_subCSV}\n\nVariable: {each_var}\nLSL / USL: {each_var_L} / {each_var_U}\nData: {latest_value}\n\n{try_crash_error}', caption='myWarning: ValueError', style=wx.ICON_WARNING, parent=self)
                                            return False, {}    # 提前终止
                                        else:
                                            data_LOG[UID_row][each_var] = latest_value      # e.g.{'UID1':{'var1':'', 'var2':''}, 'UID2':{}, ...}
                                            if float(each_var_L) <= float(latest_value) <= float(each_var_U):
                                                data_LOG[UID_row][each_var+'_Status'] = 'PASS'
                                            else:
                                                data_LOG[UID_row][each_var+'_Status'] = 'FAIL'
        dlg_pure.Destroy()
        
        if data_LOG:
            #print('data_LOG:', data_LOG, sep='\n')
            temp_saved = os.path.join(self.filter_LOG_folder, savedCSV)
            known_vars = list(known_vars_with_limits.keys())
            fieldnames_csv = []
            for each_known_var in known_vars:
                fieldnames_csv.append(each_known_var)
                fieldnames_csv.append(each_known_var + '_Status')
            fieldnames_csv.insert(0,specfied_var)               # 漂亮: 在列表的开头插入一个元素
            fieldnames_csv.insert(1,'Status')                   # 漂亮: 在列表的开头插入一个元素
            with open(file=temp_saved, mode='w', encoding='utf-8', newline='') as write_obj:
                writer_csv = csv.DictWriter(write_obj, fieldnames=fieldnames_csv)
                writer_csv.writeheader()
                for the_key, the_dict in data_LOG.items():      # 这里的写法很好哦 ！！！
                    the_dict[specfied_var] = the_key            # 漂亮: the_dict
                    writer_csv.writerow(the_dict)               # 理解: 这里的the_dict是data_LOG的Value，而data_LOG的Value是一个字典.
            print(f'{"="*50}> [End]: data_LOG', end='\n\n')
            return True, data_LOG
        else:
            wx.MessageBox(message=f'Find no valid "UniqueUID & IncludeDefect" data in csv file(s)', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return False, {}

    def get_data_NonUniqueUID_ExcludeDefect(self, LOG_folder, known_vars_with_limits, specfied_var, savedCSV='NonUniqueUID_ExcludeDefect.csv'):
        """执行此函数后，将生成文件夹: 03_LOG_filter"""
        # 返回示例：True, {'UID1': {'S_Force_L': '0.063', '#OP_Force_L': '65.827'}, 'UID2': {'S_Force_L': '0.315', '#OP_Force_L': '61.224'}}
        
        # ------------------------ 重读 LOG_folder 文件夹下每个干净的子csv, 只抓取每个csv中有共有变量的列而且数据PASS的行, 生成干净的 LOG?_commonVars_PASS.csv
        data_LOG = {}
        all_pure_subCSV = os.listdir(LOG_folder)
        all_pure_subCSV.sort()
        dlg_pure = wx.ProgressDialog(title='Reading Pure CSV File(s)', message=f'Reading pure *.csv: 0/{len(all_pure_subCSV)}', maximum=len(all_pure_subCSV), parent=None, style=wx.PD_AUTO_HIDE)
        for m, each_pure_subCSV in enumerate(all_pure_subCSV, 1):
            dlg_pure.Update(value=m, newmsg=f'Reading pure *.csv: {m}/{len(all_pure_subCSV)}\n\n{each_pure_subCSV}')
            the_file = os.path.join(LOG_folder, each_pure_subCSV)
            print('读取:', the_file)
            with open(file=the_file, mode='r', encoding='utf-8') as preread_obj:
                reader = csv.reader(preread_obj)
                read_1 = list(reader)
            # 注意: 这里必须确保当前这个干净的子csv里有 "UID" (即 specfied_var)列, 向下继续执行才是有意义的.
            if specfied_var in read_1[0]:
                with open(file=the_file, mode='r', encoding='utf-8') as read_obj:
                    rows = csv.DictReader(read_obj)
                    for n, each_row in enumerate(rows, 1):
                        UID_row = each_row[specfied_var]
                        
                        if not login_GUI.empty_UID_included:
                            if not UID_row:
                                continue
                        
                        DUT_Status = each_row['Status']
                        if DUT_Status in ['P', 'F']:                                        # 只关注在当前这个干净子csv文件里Status列为['P','F']
                            NonUniqueUID = f'{str(m)}_{str(n)}_{UID_row}'
                            if NonUniqueUID not in data_LOG: data_LOG[NonUniqueUID] = {}    # e.g. {'UID1':{}, 'UID2':{}, ...}, 这里顺便实现了重复UID的覆盖.
                            data_LOG[NonUniqueUID]['Status'] = DUT_Status
                            for each_var in known_vars_with_limits.keys():                  # 只关注已知的变量
                                each_var_L = known_vars_with_limits[each_var][0]            # str
                                each_var_U = known_vars_with_limits[each_var][1]            # str
                                if each_var not in data_LOG[NonUniqueUID]:
                                    data_LOG[NonUniqueUID][each_var] = ''                   # 先预设, 造出来key
                                    data_LOG[NonUniqueUID][each_var+'_Status'] = 'OMIT'     # 先预设为'OMIT'                      
                                if each_var in each_row.keys():                             # 特别注意: 这个已知的变量在当前这个干净子csv文件里可能没有
                                    latest_value = each_row[each_var]
                                    # 继续向下, 因为是ExcludeDefect, 所以只有是在[LSL, USL]范围内的值才会被记录更新, 否则就保持预先默认写入的空值。
                                    if latest_value:                                        # 若当前最新的值是非空的
                                        try:
                                            value_float = float(latest_value)               # 则进一步确保测试保存的值是数字
                                        except ValueError:                                  # 排除是非空的字符串
                                            try_crash_error = traceback.format_exc()
                                            wx.MessageBox(message=f'{each_pure_subCSV}\n\nVariable: {each_var}\nLSL / USL: {each_var_L} / {each_var_U}\nData: {latest_value}\n\n{try_crash_error}', caption='myWarning: ValueError', style=wx.ICON_WARNING, parent=self)
                                            return False, {}    # 提前终止
                                        else:
                                            if float(each_var_L) <= float(latest_value) <= float(each_var_U):
                                                data_LOG[NonUniqueUID][each_var] = latest_value # e.g.{'UID1':{'var1':'', 'var2':''}, 'UID2':{}, ...}
                                                data_LOG[NonUniqueUID][each_var+'_Status'] = 'PASS'
        dlg_pure.Destroy()
        
        if data_LOG:
            #print('data_LOG:', data_LOG, sep='\n')
            temp_saved = os.path.join(self.filter_LOG_folder, savedCSV)
            known_vars = list(known_vars_with_limits.keys())
            fieldnames_csv = []
            for each_known_var in known_vars:
                fieldnames_csv.append(each_known_var)
                fieldnames_csv.append(each_known_var + '_Status')
            fieldnames_csv.insert(0,'NonUniqueUID')             # 漂亮: 在列表的开头插入一个元素
            fieldnames_csv.insert(1,'Status')                   # 漂亮: 在列表的开头插入一个元素
            with open(file=temp_saved, mode='w', encoding='utf-8', newline='') as write_obj:
                writer_csv = csv.DictWriter(write_obj, fieldnames=fieldnames_csv)
                writer_csv.writeheader()
                for the_key, the_dict in data_LOG.items():      # 这里的写法很好哦 ！！！
                    the_dict['NonUniqueUID'] = the_key          # 漂亮: the_dict
                    writer_csv.writerow(the_dict)               # 理解: 这里的the_dict是data_LOG的Value，而data_LOG的Value是一个字典.
            print(f'{"="*50}> [End]: data_LOG', end='\n\n')
            return True, data_LOG
        else:
            wx.MessageBox(message=f'Find no valid "NonUniqueUID & ExcludeDefect" data in csv file(s)', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return False, {}
    
    def get_data_NonUniqueUID_IncludeDefect(self, LOG_folder, known_vars_with_limits, specfied_var, savedCSV='NonUniqueUID_IncludeDefect.csv'):
        """执行此函数后，将生成文件夹: 03_LOG_filter"""
        # 返回示例：True, {'UID1': {'S_Force_L': '0.063', '#OP_Force_L': '65.827'}, 'UID2': {'S_Force_L': '0.315', '#OP_Force_L': '61.224'}}
        
        # ------------------------ 重读 LOG_folder 文件夹下每个干净的子csv, 只抓取每个csv中有共有变量的列而且数据PASS的行, 生成干净的 LOG?_commonVars_PASS.csv
        data_LOG = {}
        all_pure_subCSV = os.listdir(LOG_folder)
        all_pure_subCSV.sort()
        dlg_pure = wx.ProgressDialog(title='Reading Pure CSV File(s)', message=f'Reading pure *.csv: 0/{len(all_pure_subCSV)}', maximum=len(all_pure_subCSV), parent=None, style=wx.PD_AUTO_HIDE)
        for m, each_pure_subCSV in enumerate(all_pure_subCSV, 1):
            dlg_pure.Update(value=m, newmsg=f'Reading pure *.csv: {m}/{len(all_pure_subCSV)}\n\n{each_pure_subCSV}')
            the_file = os.path.join(LOG_folder, each_pure_subCSV)
            print('读取:', the_file)
            with open(file=the_file, mode='r', encoding='utf-8') as preread_obj:
                reader = csv.reader(preread_obj)
                read_1 = list(reader)
            # 注意: 这里必须确保当前这个干净的子csv里有 "UID" (即 specfied_var)列, 向下继续执行才是有意义的.
            if specfied_var in read_1[0]:
                with open(file=the_file, mode='r', encoding='utf-8') as read_obj:
                    rows = csv.DictReader(read_obj)
                    for n, each_row in enumerate(rows, 1):
                        UID_row = each_row[specfied_var]
                        
                        if not login_GUI.empty_UID_included:
                            if not UID_row:
                                continue
                        
                        DUT_Status = each_row['Status']
                        if DUT_Status in ['P', 'F']:                                        # 只关注在当前这个干净子csv文件里Status列为['P','F']
                            NonUniqueUID = f'{str(m)}_{str(n)}_{UID_row}'                   # e.g. 5_93_ABCDEFGHIJKLMNOP,即UID=ABCDEFGHIJKLMNOP出现在*_pure_05.csv的94行
                            if NonUniqueUID not in data_LOG: data_LOG[NonUniqueUID] = {}    # e.g. {'UID1':{}, 'UID2':{}, ...}, 这里顺便实现了重复UID的覆盖.
                            data_LOG[NonUniqueUID]['Status'] = DUT_Status
                            for each_var in known_vars_with_limits.keys():                  # 只关注已知的变量
                                each_var_L = known_vars_with_limits[each_var][0]            # str
                                each_var_U = known_vars_with_limits[each_var][1]            # str
                                if each_var not in data_LOG[NonUniqueUID]:
                                    data_LOG[NonUniqueUID][each_var] = ''                   # 先预设, 造出来key
                                    data_LOG[NonUniqueUID][each_var+'_Status'] = 'OMIT'     # 先预设为'OMIT'                         
                                if each_var in each_row.keys():                             # 特别注意: 这个已知的变量在当前这个干净子csv文件里可能没有
                                    latest_value = each_row[each_var]
                                    # 继续向下, 只有是数字的值才会被记录更新, 否则就保持预先默认写入的空值。
                                    if latest_value:                                        # 若当前最新的值是非空的
                                        try:
                                            value_float = float(latest_value)               # 则进一步确保测试保存的值是数字
                                        except ValueError:                                  # 排除是非空的字符串
                                            try_crash_error = traceback.format_exc()
                                            wx.MessageBox(message=f'{each_pure_subCSV}\n\nVariable: {each_var}\nLSL / USL: {each_var_L} / {each_var_U}\nData: {latest_value}\n\n{try_crash_error}', caption='myWarning: ValueError', style=wx.ICON_WARNING, parent=self)
                                            return False, {}    # 提前终止
                                        else:
                                            data_LOG[NonUniqueUID][each_var] = latest_value     # e.g.{'UID1':{'var1':'', 'var2':''}, 'UID2':{}, ...}
                                            if float(each_var_L) <= float(latest_value) <= float(each_var_U):
                                                data_LOG[NonUniqueUID][each_var+'_Status'] = 'PASS'
                                            else:
                                                data_LOG[NonUniqueUID][each_var+'_Status'] = 'FAIL'
        dlg_pure.Destroy()
        
        if data_LOG:
            #print('data_LOG:', data_LOG, sep='\n')
            temp_saved = os.path.join(self.filter_LOG_folder, savedCSV)
            known_vars = list(known_vars_with_limits.keys())
            fieldnames_csv = []
            for each_known_var in known_vars:
                fieldnames_csv.append(each_known_var)
                fieldnames_csv.append(each_known_var + '_Status')
            fieldnames_csv.insert(0,'NonUniqueUID')             # 漂亮: 在列表的开头插入一个元素
            fieldnames_csv.insert(1,'Status')                   # 漂亮: 在列表的开头插入一个元素
            with open(file=temp_saved, mode='w', encoding='utf-8', newline='') as write_obj:
                writer_csv = csv.DictWriter(write_obj, fieldnames=fieldnames_csv)
                writer_csv.writeheader()
                for the_key, the_dict in data_LOG.items():      # 这里的写法很好哦 ！！！
                    the_dict['NonUniqueUID'] = the_key          # 漂亮: the_dict
                    writer_csv.writerow(the_dict)               # 理解: 这里的the_dict是data_LOG的Value，而data_LOG的Value是一个字典.
            print(f'{"="*50}> [End]: data_LOG', end='\n\n')
            return True, data_LOG
        else:
            wx.MessageBox(message=f'Find no valid "NonUniqueUID & IncludeDefect" data in csv file(s)', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return False, {}
    
    def cb_1_1_FCT(self, evt):
        self.cb_1_2.SetValue(False)                 # 注意: 这里是特意制造互斥
        # 清除上次的可能的缓存
        if self.miniFrame_total_dashboard:
            self.miniFrame_total_dashboard.Destroy()
        if self.miniFrame_fail_dashboard:
            self.miniFrame_fail_dashboard.Destroy()
            
    def cb_1_2_FCT(self, evt):
        self.cb_1_1.SetValue(False)                 # 注意: 这里是特意制造互斥
        # 清除上次的可能的缓存
        if self.miniFrame_total_dashboard:
            self.miniFrame_total_dashboard.Destroy()
        if self.miniFrame_fail_dashboard:
            self.miniFrame_fail_dashboard.Destroy()
            
    def btn_Apply_1_FCT(self, evt):
        # 注意: 'YieldRate_Top5Reason_Top5ErrorCode_Top5ErrorLine.csv',若在初始化界面勾选了"Include DUT with empty UID",则UID列就包含空的UID.
        
        # 清除上次的可能的缓存
        if self.miniFrame_total_dashboard:
            self.miniFrame_total_dashboard.Destroy()
        if self.miniFrame_fail_dashboard:
            self.miniFrame_fail_dashboard.Destroy()
        
        # 确认已存在的文档
        if not os.path.isfile(self.dashboard_csv):
            wx.MessageBox(message=f'Find no {self.dashboard_csv}', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return False, []
        
        # 获取用户最新的选择
        flag_cb_1_1 = self.cb_1_1.GetValue()
        flag_cb_1_2 = self.cb_1_2.GetValue()
        
        # 预设变量
        UID_Status       = {}    # {'4383F89D6CF0AC30': 'F',...}
        detail_UID_Total = {}
        ret_UID_Total    = []
        detail_UID_Pass  = {}
        ret_UID_Pass     = []
        detail_UID_Fail  = {}    # {'4383F89D6CF0AC30': ['F', 'I_DeadMode', '290', 'E-2927B', '216.685', '17:04:25', '1684746265', '2023-05-22  17:04:25', '*.csv'],...}
        ret_UID_Fail     = []    # [['4383F89D6CF0AC30', 'F', 'I_DeadMode', '290', 'E-2927B', '216.685', '17:04:25', '1684746265', '2023-05-22  17:04:25', '*.csv'],...]
        if flag_cb_1_1 and not flag_cb_1_2:
            # 算法1: 计算得到的Total, Pass, Fail
            # Total: 看不重复的UID的个数
            # Pass： UID的'Status'(即'P' or 'F')进行不断覆盖, 最终UID的'Status'为'P'的UID的个数
            # Fail： Total - Pass
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    the_UID             = row[login_GUI.Index_var_custom]
                    the_Status          = row['Status']
                    the_Comment         = row['Comment']
                    the_ErrorLine       = row['ErrorLine']
                    the_ErrorCode       = row['ErrorCode']
                    the_FailValue       = row['FailValue']
                    the_Test_Start_Time = row['Test_Start_Time']
                    the_UnixTime        = row['UnixTime']
                    the_BeijingTime     = row['BeijingTime']
                    the_OriginalCSV     = row['OriginalCSV']
                    UID_Status[the_UID] = the_Status
                    
                    detail_UID_Total[the_UID] = [the_Status, the_Comment, the_ErrorLine, the_ErrorCode, the_FailValue, the_Test_Start_Time, the_UnixTime, the_BeijingTime, the_OriginalCSV]
                    # 这里的条件很严谨, 注意理解: 只记录最终Status为Fail/Pass的UID,持续覆盖成最后最新的Fail/Pass数据
                    if the_Status == 'F':
                        if the_UID in detail_UID_Pass: del detail_UID_Pass[the_UID]
                        detail_UID_Fail[the_UID] = ['F', the_Comment, the_ErrorLine, the_ErrorCode, the_FailValue, the_Test_Start_Time, the_UnixTime, the_BeijingTime, the_OriginalCSV]
                    elif the_Status == 'P':
                        if the_UID in detail_UID_Fail: del detail_UID_Fail[the_UID]
                        detail_UID_Pass[the_UID] = ['P', the_Comment, the_ErrorLine, the_ErrorCode, the_FailValue, the_Test_Start_Time, the_UnixTime, the_BeijingTime, the_OriginalCSV]
            
            for key, value in detail_UID_Total.items():
                ret_UID_Total.append([key,value[0],value[1],value[2],value[3],value[4],value[5],value[6],value[7],value[8]])
            for key, value in detail_UID_Pass.items():
                ret_UID_Pass.append([key,value[0],value[1],value[2],value[3],value[4],value[5],value[6],value[7],value[8]])
            for key, value in detail_UID_Fail.items():
                ret_UID_Fail.append([key,value[0],value[1],value[2],value[3],value[4],value[5],value[6],value[7],value[8]])  # 算法2, 得到的Fail DUT数量
            
            total_count = len(UID_Status)
            pass_count  = list(UID_Status.values()).count('P')
            fail_count  = total_count - pass_count              # 算法1, 得到的Fail DUT数量
            yield_rate  = '{:.2%}'.format(pass_count/total_count).replace('.00','')
            
        elif not flag_cb_1_1 and flag_cb_1_2:
            # 算法1: 计算得到的Total, Pass, Fail
            # Total: 看不重复的UID的个数
            # Pass： UID的'Status' 只记录第一次的状态, 而且UID的'Status'为'P'的UID的个数
            # Fail： Total - Pass
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    the_UID             = row[login_GUI.Index_var_custom]
                    the_Status          = row['Status']
                    the_Comment         = row['Comment']
                    the_ErrorLine       = row['ErrorLine']
                    the_ErrorCode       = row['ErrorCode']
                    the_FailValue       = row['FailValue']
                    the_Test_Start_Time = row['Test_Start_Time']
                    the_UnixTime        = row['UnixTime']
                    the_BeijingTime     = row['BeijingTime']
                    the_OriginalCSV     = row['OriginalCSV']
                    
                    if the_UID not in UID_Status:
                        detail_UID_Total[the_UID] = [the_Status, the_Comment, the_ErrorLine, the_ErrorCode, the_FailValue, the_Test_Start_Time, the_UnixTime, the_BeijingTime, the_OriginalCSV]
                        # 这里的条件很严谨, 注意理解: 只记录第一次Fail的数据行
                        if the_Status == 'F':
                            detail_UID_Fail[the_UID] = ['F', the_Comment, the_ErrorLine, the_ErrorCode, the_FailValue, the_Test_Start_Time, the_UnixTime, the_BeijingTime, the_OriginalCSV]
                        elif the_Status == 'P':
                            detail_UID_Pass[the_UID] = ['P', the_Comment, the_ErrorLine, the_ErrorCode, the_FailValue, the_Test_Start_Time, the_UnixTime, the_BeijingTime, the_OriginalCSV]
                        UID_Status[the_UID] = the_Status
                        
            for key, value in detail_UID_Total.items():
                ret_UID_Total.append([key,value[0],value[1],value[2],value[3],value[4],value[5],value[6],value[7],value[8]])          
            for key, value in detail_UID_Pass.items():
                ret_UID_Pass.append([key,value[0],value[1],value[2],value[3],value[4],value[5],value[6],value[7],value[8]])          
            for key, value in detail_UID_Fail.items():
                ret_UID_Fail.append([key,value[0],value[1],value[2],value[3],value[4],value[5],value[6],value[7],value[8]])   # 算法2, 得到的Fail DUT数量
                
            total_count = len(UID_Status)
            pass_count  = list(UID_Status.values()).count('P')
            fail_count  = total_count - pass_count                          # 算法1, 得到的Fail DUT数量
            yield_rate  = '{:.2%}'.format(pass_count/total_count).replace('.00','')
            
        elif not flag_cb_1_1 and not flag_cb_1_2:
            # 算法1: 计算得到的Total, Pass, Fail
            # Total: 看UID的'Status'为'P'和'F'的总行数
            # Pass： 看UID的'Status'为'P'的行数
            # Fail： 看UID的'Status'为'F'的行数
            pass_count = 0
            fail_count = 0
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    the_UID             = row[login_GUI.Index_var_custom]
                    the_Status          = row['Status']
                    the_Comment         = row['Comment']
                    the_ErrorLine       = row['ErrorLine']
                    the_ErrorCode       = row['ErrorCode']
                    the_FailValue       = row['FailValue']
                    the_Test_Start_Time = row['Test_Start_Time']
                    the_UnixTime        = row['UnixTime']
                    the_BeijingTime     = row['BeijingTime']
                    the_OriginalCSV     = row['OriginalCSV']
                    
                    ret_UID_Total.append([the_UID, the_Status, the_Comment, the_ErrorLine, the_ErrorCode, the_FailValue, the_Test_Start_Time, the_UnixTime, the_BeijingTime, the_OriginalCSV])
                    if the_Status == 'P':
                        pass_count += 1
                        ret_UID_Pass.append([the_UID,'P',the_Comment,the_ErrorLine,the_ErrorCode,the_FailValue,the_Test_Start_Time,the_UnixTime,the_BeijingTime, the_OriginalCSV])
                    elif the_Status == 'F':
                        fail_count += 1    # 算法1, 得到的Fail DUT数量
                        ret_UID_Fail.append([the_UID,'F',the_Comment,the_ErrorLine,the_ErrorCode,the_FailValue,the_Test_Start_Time,the_UnixTime,the_BeijingTime, the_OriginalCSV])  # 算法2, 得到的Fail DUT数量
            total_count = pass_count + fail_count
            yield_rate  = '{:.2%}'.format(pass_count/total_count).replace('.00','')
        
        # 更新最新的数据至 Dashboard 面板
        self.speed.SetMiddleText(yield_rate)
        self.speed.SetSpeedValue(float(yield_rate.rstrip('%')))    
        
        # 更新最新的数据至 table_1
        for i, each_count in enumerate([total_count, pass_count, fail_count, yield_rate],0):
            self.table_1.SetItem(index=i, column=1, label=str(each_count))
        self.table_1.SetItemTextColour(item=2, col='red')
               
        # 刷新一下    
        self.speed.Refresh()
        self.table_1.Refresh()
        
        return True, ret_UID_Total, ret_UID_Pass, ret_UID_Fail
        
    def btn_Apply_2_FCT(self, evt):
        # 注意: 'YieldRate_Top5Reason_Top5ErrorCode_Top5ErrorLine.csv',若在初始化界面勾选了"Include DUT with empty UID",则UID列就包含空的UID.
        
        # 确认已存在的文档
        if not os.path.isfile(self.dashboard_csv):
            wx.MessageBox(message=f'Find no {self.dashboard_csv}', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return
        
        # 获取用户最新的选择
        flag_cb_2 = self.cb_2.GetValue()
        
        # 预设变量
        final_top5reason = []
        
        if flag_cb_2:
            # Total: 看不重复的UID的个数
            # Pass： UID的'Status'(即'P' or 'F')进行不断覆盖, 最终UID的'Status'为'P'的UID的个数
            # Fail： Total - Pass
            UID_Status_Comment = {}
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    UID_Status_Comment[row[login_GUI.Index_var_custom]] = [row['Status'], row['Comment']]
            total_count = len(UID_Status_Comment)
            pass_count  = [i[0] for i in list(UID_Status_Comment.values())].count('P')
            fail_count  = total_count - pass_count
            yield_rate  = '{:.2%}'.format(pass_count/total_count).replace('.00','')
            all_reason  = [i[1] for i in list(UID_Status_Comment.values()) if i[0]=='F']
            reason_list = list(set(all_reason))
            # if '' in reason_list:reason_list.remove('')
            reason_qty  = {}
            for each_reason in reason_list:
                reason_qty[each_reason] = all_reason.count(each_reason)
            # key 使用lambda匿名函数取value进行从大到小排序
            final_top5reason = sorted(reason_qty.items(), key=lambda x:x[1], reverse=True)  # 字典变成了列表, [('AA', 4), ('BB', 2), ('CC', 1)...]
        else:
            # Total: 看UID的'Status'为'P'和'F'的总行数
            # Pass： 看UID的'Status'为'P'的行数
            # Fail： 看UID的'Status'为'F'的行数
            Status_Comment = {'P':[], 'F':[]}
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    if row['Status'] == 'P':
                        Status_Comment['P'].append(row['Comment'])
                    elif row['Status'] == 'F':
                        Status_Comment['F'].append(row['Comment'])
            pass_count  = len(Status_Comment['P'])
            fail_count  = len(Status_Comment['F'])
            total_count = pass_count + fail_count
            yield_rate  = '{:.2%}'.format(pass_count/total_count).replace('.00','')
            all_reason  = Status_Comment['F']
            reason_list = list(set(Status_Comment['F']))
            reason_qty  = {}
            for each_reason in reason_list:
                reason_qty[each_reason] = all_reason.count(each_reason)
            # key 使用lambda匿名函数取value进行从大到小排序
            final_top5reason = sorted(reason_qty.items(), key=lambda x:x[1], reverse=True)  # 字典变成了列表, [('AA', 4), ('BB', 2), ('CC', 1)...]
                       
        # 然后,正式更新最新的5组数据至Top5Reason_table
        self.Top5Reason_table.DeleteAllItems()  # 删除所有的行
        for i, reason_count in enumerate(final_top5reason,0):
            index_row = self.Top5Reason_table.InsertItem(index=i, label=str(reason_count[0]))    # 插入行,顺便设置了此行第一列的值
            self.Top5Reason_table.SetItem(index=index_row, column=1, label=str(reason_count[1]))
            if i >= 4:
                break
                
        # 刷新一下    
        self.Top5Reason_table.Refresh()
        
    def btn_Apply_3_FCT(self, evt):
        # 注意: 'YieldRate_Top5Reason_Top5ErrorCode_Top5ErrorLine.csv',若在初始化界面勾选了"Include DUT with empty UID",则UID列就包含空的UID.
        
        # 确认已存在的文档
        if not os.path.isfile(self.dashboard_csv):
            wx.MessageBox(message=f'Find no {self.dashboard_csv}', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return
        
        # 获取用户最新的选择
        flag_cb_3 = self.cb_3.GetValue()
        
        # 预设变量
        final_top5errorcode = []
        
        if flag_cb_3:
            # Total: 看不重复的UID的个数
            # Pass： UID的'Status'(即'P' or 'F')进行不断覆盖, 最终UID的'Status'为'P'的UID的个数
            # Fail： Total - Pass
            UID_Status_ErrorCode = {}
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    UID_Status_ErrorCode[row[login_GUI.Index_var_custom]] = [row['Status'], row['ErrorCode']]
            total_count    = len(UID_Status_ErrorCode)
            pass_count     = [i[0] for i in list(UID_Status_ErrorCode.values())].count('P')
            fail_count     = total_count - pass_count
            yield_rate     = '{:.2%}'.format(pass_count/total_count).replace('.00','')
            all_errorcode  = [i[1] for i in list(UID_Status_ErrorCode.values()) if i[0]=='F']
            errorcode_list = list(set(all_errorcode))
            # if '' in errorcode_list:errorcode_list.remove('')
            errorcode_qty = {}
            for each_errorcode in errorcode_list:
                errorcode_qty[each_errorcode] = all_errorcode.count(each_errorcode)
            # key 使用lambda匿名函数取value进行从大到小排序
            final_top5errorcode = sorted(errorcode_qty.items(), key=lambda x:x[1], reverse=True)  # 字典变成了列表, [('AA', 4), ('BB', 2), ('CC', 1)...]
        else:
            # Total: 看UID的'Status'为'P'和'F'的总行数
            # Pass： 看UID的'Status'为'P'的行数
            # Fail： 看UID的'Status'为'F'的行数
            Status_Comment = {'P':[], 'F':[]}
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    if row['Status'] == 'P':
                        Status_Comment['P'].append(row['ErrorCode'])
                    elif row['Status'] == 'F':
                        Status_Comment['F'].append(row['ErrorCode'])
            pass_count     = len(Status_Comment['P'])
            fail_count     = len(Status_Comment['F'])
            total_count    = pass_count + fail_count
            yield_rate     = '{:.2%}'.format(pass_count/total_count).replace('.00','')
            all_errorcode  = Status_Comment['F']
            errorcode_list = list(set(Status_Comment['F']))
            errorcode_qty  = {}
            for each_errorcode in errorcode_list:
                errorcode_qty[each_errorcode] = all_errorcode.count(each_errorcode)
            # key 使用lambda匿名函数取value进行从大到小排序
            final_top5errorcode = sorted(errorcode_qty.items(), key=lambda x:x[1], reverse=True)  # 字典变成了列表, [('AA', 4), ('BB', 2), ('CC', 1)...]
        
        # 注意: 这里需要区分 UTS2 和 UTS1      
        the_qty = len(final_top5errorcode)
        if self.UTS2_format:
            pass
        else:   # 这里兼容UTS1, 其眉头有的是'Failed_Tests'
            if the_qty == 0:
                pass
            else:
                final_top5errorcode = [(':',fail_count)]
                
        # 然后,正式更新最新的5组数据至Top5ErrorCode_table
        self.Top5ErrorCode_table.DeleteAllItems()  # 删除所有的行
        if self.UTS2_format:
            for i, errorcode_count in enumerate(final_top5errorcode,0):
                if errorcode_count[0] in self.errorCode_fieldName:
                    errCode_fldName = errorcode_count[0] + ': ' + self.errorCode_fieldName[errorcode_count[0]]
                    index_row = self.Top5ErrorCode_table.InsertItem(index=i, label=errCode_fldName)    # 插入行,顺便设置了此行第一列的值
                else:
                    errCode_fldName = errorcode_count[0] + ': ' + 'Unknown Variable Name'
                    index_row = self.Top5ErrorCode_table.InsertItem(index=i, label=errCode_fldName)    # 插入行,顺便设置了此行第一列的值
                    self.Top5ErrorCode_table.SetItemTextColour(item=index_row, col='red')    
                self.Top5ErrorCode_table.SetItem(index=index_row, column=1, label=str(errorcode_count[1]))
                if i >= 4:
                    break
        else:   # 这里兼容UTS1
            for i, errorcode_count in enumerate(final_top5errorcode,0):
                index_row = self.Top5ErrorCode_table.InsertItem(index=i, label=errorcode_count[0])    # 插入行,顺便设置了此行第一列的值    
                self.Top5ErrorCode_table.SetItem(index=index_row, column=1, label=str(errorcode_count[1]))
                
        # 刷新一下
        self.Top5ErrorCode_table.Refresh()
    
    def btn_Apply_4_FCT(self, evt):
        # 注意: 'YieldRate_Top5Reason_Top5ErrorCode_Top5ErrorLine.csv',若在初始化界面勾选了"Include DUT with empty UID",则UID列就包含空的UID.
        
        # 确认已存在的文档
        if not os.path.isfile(self.dashboard_csv):
            wx.MessageBox(message=f'Find no {self.dashboard_csv}', caption='Warning', style=wx.ICON_WARNING, parent=self)
            return
        
        # 获取用户最新的选择
        flag_cb_4 = self.cb_4.GetValue()
        
        # 预设变量
        final_top5errorline = []
        
        if flag_cb_4:
            # Total: 看不重复的UID的个数
            # Pass： UID的'Status'(即'P' or 'F')进行不断覆盖, 最终UID的'Status'为'P'的UID的个数
            # Fail： Total - Pass
            UID_Status_ErrorLine = {}
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    UID_Status_ErrorLine[row[login_GUI.Index_var_custom]] = [row['Status'], row['ErrorLine']+': '+row['Comment']]
            total_count    = len(UID_Status_ErrorLine)
            pass_count     = [i[0] for i in list(UID_Status_ErrorLine.values())].count('P')
            fail_count     = total_count - pass_count
            yield_rate     = '{:.2%}'.format(pass_count/total_count).replace('.00','')
            all_errorline  = [i[1] for i in list(UID_Status_ErrorLine.values()) if i[0]=='F']
            errorline_list = list(set(all_errorline))
            # if '' in errorline_list:errorline_list.remove('')
            errorline_qty  = {}
            for each_errorline in errorline_list:
                errorline_qty[each_errorline] = all_errorline.count(each_errorline)
            # key 使用lambda匿名函数取value进行从大到小排序
            final_top5errorline = sorted(errorline_qty.items(), key=lambda x:x[1], reverse=True)  # 字典变成了列表, [('AA', 4), ('BB', 2), ('CC', 1)...]
        else:
            # Total: 看UID的'Status'为'P'和'F'的总行数
            # Pass： 看UID的'Status'为'P'的行数
            # Fail： 看UID的'Status'为'F'的行数
            Status_ErrorLine = {'P':[], 'F':[]}
            with open(file=self.dashboard_csv, mode='r', encoding='utf-8') as f_obj:
                rows = csv.DictReader(f_obj)
                for row in rows:
                    if row['Status'] == 'P':
                        Status_ErrorLine['P'].append(row['ErrorLine']+': '+row['Comment'])
                    elif row['Status'] == 'F':
                        Status_ErrorLine['F'].append(row['ErrorLine']+': '+row['Comment'])
            pass_count  = len(Status_ErrorLine['P'])
            fail_count  = len(Status_ErrorLine['F'])
            total_count = pass_count + fail_count
            yield_rate  = '{:.2%}'.format(pass_count/total_count).replace('.00','')
            all_errorline  = Status_ErrorLine['F']
            errorline_list = list(set(Status_ErrorLine['F']))
            errorline_qty  = {}
            for each_errorline in errorline_list:
                errorline_qty[each_errorline] = all_errorline.count(each_errorline)
            # key 使用lambda匿名函数取value进行从大到小排序
            final_top5errorline = sorted(errorline_qty.items(), key=lambda x:x[1], reverse=True)  # 字典变成了列表, [('AA', 4), ('BB', 2), ('CC', 1)...]
        
        # 注意: 这里需要区分 UTS2 和 UTS1      
        the_qty = len(final_top5errorline)
        if self.UTS2_format:
            pass
        else:   # 这里兼容UTS1, 其眉头有的是'Failed_Tests'
            if the_qty == 0:
                pass
            else:
                final_top5errorline = [(':',fail_count)]
                
        # 然后,正式更新最新的5组数据至Top5ErrorLine_table
        self.Top5ErrorLine_table.DeleteAllItems()  # 删除所有的行
        if self.UTS2_format:
            for i, errorline_count in enumerate(final_top5errorline,0):
                index_row = self.Top5ErrorLine_table.InsertItem(index=i, label=str(errorline_count[0]))    # 插入行,顺便设置了此行第一列的值
                self.Top5ErrorLine_table.SetItem(index=index_row, column=1, label=str(errorline_count[1]))
                if i >= 4:
                    break
        else:   # 这里兼容UTS1
            for i, errorline_count in enumerate(final_top5errorline,0):
                index_row = self.Top5ErrorLine_table.InsertItem(index=i, label=errorline_count[0])    # 插入行,顺便设置了此行第一列的值    
                self.Top5ErrorLine_table.SetItem(index=index_row, column=1, label=str(errorline_count[1]))
                
        # 刷新一下    
        self.Top5ErrorLine_table.Refresh()
    
    def OnExit_GUI(self, event):
        self.Destroy()
        sys.exit()
        
if __name__ == '__main__':
    
    script_abspath   = os.path.abspath('')
    Debug_login_file = os.path.join(script_abspath, 'Debug_Login.log')
    Debug_gui_file   = os.path.join(script_abspath, 'Debug_GUI.log')
    if os.path.isfile(Debug_login_file):os.remove(path=Debug_login_file)
    if os.path.isfile(Debug_gui_file):os.remove(path=Debug_gui_file) 
    
    # 注意: The wx.App object must be created first!
    app_login = wx.App(redirect=False, filename=Debug_login_file)
    

               
    # 正式开启程序的登入界面
    login_GUI = MyLogin(None, title=f'Data Analysis Assistant\tUser: {current_username}', size=(705,750), style=wx.CAPTION|wx.CLOSE_BOX|wx.SIMPLE_BORDER) #wx.MINIMIZE_BOX|wx.STAY_ON_TOP
    app_login.MainLoop()
    app_login.Destroy()
    
    # 正式开启程序的主界面
    gui_W, gui_H = 1360, -1
    app = wx.App(redirect=True if login_GUI.debug_mode_custom else False, filename=Debug_gui_file)
    gui = MyGUI(None, title=f'{app_name}({latest_ver})    Algorithm: {login_GUI.algorithm_Hist_custom}    Index: {login_GUI.Index_var_custom}', size=(gui_W,gui_H), style=wx.DEFAULT_FRAME_STYLE)#|wx.STAY_ON_TOP
    app.SetTopWindow(gui)
    app.MainLoop()
    